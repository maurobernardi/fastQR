# Reproducible experiments; source from the guide root.
# Full mode: options(fastQR.guide.benchmark_mode="full").
source("scripts/lapack-baseline.R")
load_guide_lapack()
mode <- getOption("fastQR.guide.benchmark_mode","quick")
stopifnot(mode %in% c("quick","full"))
cfg <- if(mode=="full") list(n=c(1000L,2000L,5000L),p=c(100L,300L,800L),
  reps=10L,batch=10L,steps=100L) else list(n=c(300L,600L),p=c(20L,60L),
  reps=5L,batch=3L,steps=30L)
set.seed(20261116)
dir.create("results",showWarnings=FALSE)
rel <- function(a,b) norm(as.matrix(a-b),"F")/max(norm(as.matrix(b),"F"),.Machine$double.xmin)
positive_R <- function(r) { s<-sign(diag(r));s[s==0]<-1; r*s }
# Adaptive batching produces seconds/call. Allocation and R-interface costs
# are included; data generation, compilation, reference checks are excluded.
time_calls <- function(methods,metadata) {
  invisible(lapply(methods,function(f)f()))
  batches<-vapply(methods,function(f){b<-1L;repeat{
    t<-system.time(for(i in seq_len(b)) z<-f())[["elapsed"]]
    if(t>=.03 || b>=2048L)break
    b<-b*2L
  };b},integer(1))
  do.call(rbind,lapply(seq_len(cfg$reps),function(rep){
    order<-sample(names(methods)); do.call(rbind,lapply(order,function(name){
      gc(); b<-batches[[name]]
      t<-system.time(for(i in seq_len(b)) z<-methods[[name]]())[["elapsed"]]/b
      cbind(metadata,data.frame(repetition=rep,method=name,batch_calls=b,seconds=t))
    }))
  }))
}
base_factors <- function(X,lapack) {
  z<-base::qr(X,LAPACK=lapack)
  list(Q=base::qr.Q(z),R=base::qr.R(z),pivot=z$pivot)
}
# Four workloads; never aggregate across different output representations.
initial_times<-list();returned_storage<-list();j<-0L
for(n in cfg$n) for(p in cfg$p) if(n>p) {
  X<-matrix(rnorm(n*p),n,p)
  workloads<-list(
    compact=list("fastQR LAPACK compact"=function()fastQR::qr_lapack(X,"compact"),
      "LAPACK DGEQRF"=function()guide_lapack(X,"compact"),
      "fastQR compact unpivoted"=function()fastQR::qr_fast(X,pivot=FALSE),
      "base LINPACK"=function()base::qr(X,LAPACK=FALSE),
      "base LAPACK pivoted"=function()base::qr(X,LAPACK=TRUE)),
    thin_unpivoted=list("fastQR LAPACK thin"=function()fastQR::qr_lapack(X,"thin"),
      "LAPACK DGEQRF + DORGQR"=function()guide_lapack(X),
      "fastQR thin Householder"=function()fastQR::qr(X,complete=FALSE),
      "fastQR thin internal LAPACK"=function()fastQR::qr_thin(X),
      "fastQR thin recursive"=function()fastQR::qr(X,nb=8L,complete=FALSE),
      "fastQR thin Givens"=function()fastQR::qr(X,type="givens",complete=FALSE)),
    thin_pivoted=list("base LAPACK + explicit Q,R"=function()base_factors(X,TRUE)),
    R_unpivoted=list("fastQR LAPACK R"=function()fastQR::qr_lapack(X,"R"),
      "LAPACK DGEQRF + extract R"=function()guide_lapack(X,"R"),
      "fastQR qrchol"=function()fastQR::qrchol(X),
      "fastQR rchol"=function()fastQR::rchol(X)))
  for(w in names(workloads)){
    j<-j+1L;meta<-data.frame(n=n,p=p,workload=w)
    initial_times[[j]]<-time_calls(workloads[[w]],meta)
    returned_storage[[j]]<-do.call(rbind,lapply(names(workloads[[w]]),function(k)
      cbind(meta,data.frame(method=k,returned_bytes=as.numeric(object.size(workloads[[w]][[k]]()))))))
  }
}
initial_times<-do.call(rbind,initial_times);returned_storage<-do.call(rbind,returned_storage)
# Single modifications start from identical, precomputed factors. Full Q is
# used only because these fastQR update interfaces require that representation.
n<-max(cfg$n);p<-max(cfg$p);m<-cfg$batch
X<-matrix(rnorm(n*p),n,p);U<-matrix(rnorm(p*m),p,m);V<-matrix(rnorm(n*m),n,m)
full<-guide_lapack(X,"full");r0<-guide_lapack(X,"R")
operations<-list(
  add_rows=list(target=rbind(X,t(U)),r=function()fastQR::rupdate(X,r0,U=U,type="row",fast=FALSE),
    qr=function()fastQR::qrupdate(full$Q,full$R,k=n+1L,U=U,type="row",fast=FALSE,complete=FALSE)),
  delete_rows=list(target=X[-seq_len(m),,drop=FALSE],r=function()fastQR::rdowndate(r0,U=t(X[seq_len(m),,drop=FALSE]),type="row",fast=FALSE),
    qr=function()fastQR::qrdowndate(full$Q,full$R,k=1L,m=m,type="row",fast=FALSE,complete=FALSE)),
  add_columns=list(target=cbind(X,V),r=function()fastQR::rupdate(X,r0,U=V,type="column",fast=FALSE),
    qr=function()fastQR::qrupdate(full$Q,full$R,k=p+1L,U=V,type="column",fast=FALSE,complete=FALSE)),
  delete_columns=list(target=X[,-seq_len(m),drop=FALSE],r=function()fastQR::rdowndate(r0,k=1L,m=m,type="column",fast=FALSE),
    qr=function()fastQR::qrdowndate(full$Q,full$R,k=1L,m=m,type="column",fast=FALSE,complete=FALSE)))
mod_times<-list();mod_checks<-list()
for(op in names(operations)){
  a<-operations[[op]];target<-a$target;ref<-guide_lapack(target,"R")
  ru<-a$r();qu<-a$qr();qq<-ncol(target)
  mod_checks[[op]]<-data.frame(operation=op,
    R_gram_error=rel(crossprod(ru),crossprod(target)),
    R_factor_error=rel(positive_R(ru),positive_R(ref)),
    QR_reconstruction=rel(qu$Q%*%qu$R,target),
    QR_orthogonality=norm(crossprod(qu$Q)-diag(ncol(qu$Q)),"F")/sqrt(ncol(qu$Q)))
  mod_times[[paste0(op,"r")]]<-time_calls(list(
    "R update"=a$r,"LAPACK recompute R"=function()guide_lapack(target,"R")),
    data.frame(n=n,p=p,operation=op,workload="R only"))
  mod_times[[paste0(op,"q")]]<-time_calls(list(
    "Thin QR update"=a$qr,"LAPACK recompute thin QR"=function()guide_lapack(target,"thin")),
    data.frame(n=n,p=p,operation=op,workload="Thin QR"))
}
mod_times<-do.call(rbind,mod_times);mod_checks<-do.call(rbind,mod_checks)
stopifnot(max(as.matrix(mod_checks[,-1]))<1e-9)
# Prescribed singular values isolate conditioning from random matrix size.
# A consistent system has known solution; the residual-based backward error
# below is for Xb=y, not a general inconsistent least-squares backward error.
accuracy_rows<-list();id<-0L
for(kappa in c(1,1e2,1e4,1e6,1e8)) {
  n<-160L;p<-12L
  l<-base::qr.Q(base::qr(matrix(rnorm(n*p),n,p),LAPACK=TRUE))
  v<-base::qr.Q(base::qr(matrix(rnorm(p*p),p,p),LAPACK=TRUE))
  X<-sweep(l,2,exp(seq(0,-log(kappa),length.out=p)),"*")%*%t(v)
  truth<-seq_len(p)/p;y<-drop(X%*%truth)
  methods<-list("LAPACK unpivoted"=function()guide_lapack(X),
    "LAPACK pivoted"=function()base_factors(X,TRUE),
    "fastQR thin"=function()fastQR::qr(X,complete=FALSE),
    "fastQR R + seminormal solve"=function()list(R=fastQR::qrchol(X)))
  for(name in names(methods)) {
    id<-id+1L
    accuracy_rows[[id]]<-tryCatch({
      f<-methods[[name]]();r<-f$R;Q<-f$Q
      perm<-if(is.null(f$pivot))seq_len(p)else f$pivot
      xp<-X[,perm,drop=FALSE]
      if(is.null(Q)) b<-backsolve(r,forwardsolve(t(r),crossprod(X,y))) else {
        bp<-backsolve(r,crossprod(Q,y));b<-numeric(p);b[perm]<-bp
      }
      residual<-drop(y-X%*%b)
      data.frame(kappa=kappa,method=name,status="finite",
        reconstruction=if(is.null(Q))NA_real_ else rel(Q%*%r,xp),
        orthogonality=if(is.null(Q))NA_real_ else norm(crossprod(Q)-diag(p),"F")/sqrt(p),
        gram_error=rel(crossprod(r),crossprod(xp)),
        coefficient_forward=norm(as.matrix(b-truth),"F")/norm(as.matrix(truth),"F"),
        consistent_backward=norm(as.matrix(residual),"F")/(norm(X,"2")*norm(as.matrix(b),"F")+norm(as.matrix(y),"F")))
    },error=function(e)data.frame(kappa=kappa,method=name,status=conditionMessage(e),
      reconstruction=NA,orthogonality=NA,gram_error=NA,coefficient_forward=NA,consistent_backward=NA))
  }
}
accuracy_rows<-do.call(rbind,accuracy_rows)
# Column addition close to span(X) tests the delicate R-only extension.
near_rows<-list();id<-0L
for(delta in c(1e-1,1e-3,1e-5,1e-7)) {
  n<-160L;p<-12L;X<-matrix(rnorm(n*p),n,p)
  f<-guide_lapack(X);a<-rep(1/sqrt(p),p);z<-rnorm(n)
  z<-z-drop(f$Q%*%crossprod(f$Q,z));z<-z/sqrt(sum(z^2))
  u<-drop(X%*%a);u<-u/sqrt(sum(u^2))+delta*z;target<-cbind(X,u)
  ref<-guide_lapack(target,"R")
  rr<-tryCatch(fastQR::rupdate(X,f$R,U=matrix(u,n,1),type="column",fast=FALSE),error=function(e)e)
  id<-id+1L
  near_rows[[id]]<-data.frame(delta=delta,kappa=kappa(target,exact=TRUE),
    status=if(inherits(rr,"error"))conditionMessage(rr)else if(all(is.finite(rr)))"finite"else "nonfinite",
    gram_error=if(inherits(rr,"error"))NA else rel(crossprod(rr),crossprod(target)),
    factor_error=if(inherits(rr,"error"))NA else rel(positive_R(rr),positive_R(ref)),
    last_diagonal_relative=if(inherits(rr,"error"))NA else abs(abs(tail(diag(rr),1))-abs(tail(diag(ref),1)))/abs(tail(diag(ref),1)))
}
near_rows<-do.call(rbind,near_rows)
# Downdating toward rank loss, while the exact target stays full rank.
down_rows<-lapply(c(1,1e-2,1e-4,1e-6),function(delta){
 p<-8L
 left<-base::qr.Q(base::qr(matrix(rnorm(2*p*p),2*p,p),LAPACK=TRUE))
 right<-base::qr.Q(base::qr(matrix(rnorm(p*p),p,p),LAPACK=TRUE))
 target<-sweep(left,2,c(rep(1,p-1),delta),"*")%*%t(right)
 removed<-matrix(right[,p],1,p)
 X<-rbind(target,removed);r<-guide_lapack(X,"R");ref<-guide_lapack(target,"R")
 rr<-tryCatch(fastQR::rdowndate(r,U=t(removed),type="row",fast=FALSE),error=function(e)e)
 data.frame(delta=delta,status=if(inherits(rr,"error"))conditionMessage(rr)else if(all(is.finite(rr)))"finite"else "nonfinite",
   last_diagonal_relative=if(inherits(rr,"error"))NA else abs(abs(tail(diag(rr),1))-abs(tail(diag(ref),1)))/abs(tail(diag(ref),1)),
   gram_error=if(inherits(rr,"error"))NA else rel(crossprod(rr),crossprod(target)))
});down_rows<-do.call(rbind,down_rows)
# Long paths start from one factorization; each step adds then deletes a row.
# Include the initial factorization in the cumulative end-to-end total.
set.seed(20261117);n<-200L;p<-12L
stream<-matrix(rnorm((n+cfg$steps)*p),n+cfg$steps,p);X<-stream[seq_len(n),,drop=FALSE]
beta<-seq_len(p)/p;yall<-drop(stream%*%beta+rnorm(nrow(stream),sd=.1));y<-yall[seq_len(n)]
t0<-proc.time()[["elapsed"]];r<-guide_lapack(X,"R");h<-crossprod(X,y);b<-backsolve(r,forwardsolve(t(r),h))
initial_R_seconds<-proc.time()[["elapsed"]]-t0
t0<-proc.time()[["elapsed"]];f<-guide_lapack(X);bref<-backsolve(f$R,crossprod(f$Q,y))
initial_Q_seconds<-proc.time()[["elapsed"]]-t0
path_rows<-vector("list",cfg$steps);tR<-initial_R_seconds;tF<-initial_Q_seconds
for(s in seq_len(cfg$steps)){
 old<-X[1,,drop=FALSE];new<-stream[n+s,,drop=FALSE];yn<-yall[n+s]
 target<-rbind(X[-1,,drop=FALSE],new);yt<-c(y[-1],yn)
 t0<-proc.time()[["elapsed"]]
 radd<-fastQR::rupdate(X,r,U=t(new),type="row",fast=FALSE)
 r<-fastQR::rdowndate(radd,U=t(old),type="row",fast=FALSE)
 h<-h-crossprod(old,y[1])+crossprod(new,yn)
 b<-drop(backsolve(r,forwardsolve(t(r),h)));dtR<-proc.time()[["elapsed"]]-t0
 t0<-proc.time()[["elapsed"]];f<-guide_lapack(target);bref<-drop(backsolve(f$R,crossprod(f$Q,yt)))
 dtF<-proc.time()[["elapsed"]]-t0;tR<-tR+dtR;tF<-tF+dtF
 path_rows[[s]]<-data.frame(step=s,gram_error=rel(crossprod(r),crossprod(target)),
   coefficient_error=rel(b,bref),R_cumulative=tR,refactor_cumulative=tF)
 X<-target;y<-yt
}
path_rows<-do.call(rbind,path_rows)
stopifnot(max(path_rows$coefficient_error)<1e-9)
objects<-list(bench_initial=initial_times,bench_storage=returned_storage,bench_modifications=mod_times,
  bench_update_checks=mod_checks,bench_conditioning=accuracy_rows,bench_near_columns=near_rows,
  bench_near_downdate=down_rows,bench_path=path_rows)
for(name in names(objects))write.csv(objects[[name]],paste0("results/",name,".csv"),row.names=FALSE)
metadata<-c(paste("Mode:",mode),paste("Seed:",20261116),paste("UTC:",format(Sys.time(),tz="UTC")),
 paste("R:",R.version.string),paste("fastQR:",utils::packageVersion("fastQR")),
 paste("Machine:",paste(Sys.info(),collapse="; ")),capture.output(extSoftVersion()),
 paste(names(Sys.getenv(c("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","VECLIB_MAXIMUM_THREADS"))),
       Sys.getenv(c("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","VECLIB_MAXIMUM_THREADS")),sep="="),
 capture.output(sessionInfo()))
writeLines(metadata,"results/benchmark-environment.txt")
saveRDS(cfg,"results/benchmark-settings.rds")
message("Reproducible benchmark suite completed: ",mode)
