# Run from the guide root after sourcing scripts/ridge-evidence.R.
set.seed(147)
for(d in list(c(35L,10L),c(12L,20L),c(8L,8L))){
 X<-matrix(rnorm(prod(d)),d[1],d[2]);X[,ncol(X)]<-X[,1];y<-rnorm(nrow(X));p<-ridge_evidence_prepare(X,y)
 for(lambda in c(1e-4,.1,10)){
  C<-diag(nrow(X))+tcrossprod(X)/(nrow(X)*lambda);u<-chol(C)
  q<-sum(forwardsolve(t(u),y)^2);ld<-2*sum(log(diag(u)));t<-ridge_evidence_terms(p,log(lambda))
  stopifnot(abs(q-t$q)/max(1,q)<1e-9,abs(ld-t$logdet)/max(1,abs(ld))<1e-9)
 }
}
X<-matrix(0,10,4);y<-rnorm(10);f<-ridge_evidence_fit(X,y)
stopifnot(is.infinite(f$lambda),all(f$coeff==0),f$status=='null-model limit')
X<-matrix(rnorm(40*10),40,10);y<-drop(X%*%rep(1,10)+rnorm(40))
a<-ridge_evidence_fit(X,y);b<-ridge_evidence_fit(X,3*y)
stopifnot(is.finite(a$lambda),abs(log(a$lambda/b$lambda))<1e-5,
 abs(b$sigma2/(9*a$sigma2)-1)<1e-6)
for(fun in list(function()ridge_evidence_fit(X,rep(0,40)),
 function()ridge_evidence_fit(X,y,grid_length=2L),
 function()ridge_evidence_fit(X,y,log_bounds=c(1,0))))
 stopifnot(inherits(try(fun(),silent=TRUE),'try-error'))
cat('Evidence checks passed: tall/wide/rank-deficient designs, covariance references, null limit, scale invariance and invalid inputs.\n')
