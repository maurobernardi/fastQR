# Small local adapter to the LAPACK linked to R; not a reimplementation of QR.
# Run from the guide root. Compilation is outside every timed region.
load_guide_lapack <- function() {
  if (exists("guide_geqrf", mode="function", envir=.GlobalEnv)) return(invisible(NULL))
  stopifnot(requireNamespace("Rcpp",quietly=TRUE))
  rbin <- file.path(R.home("bin"),"R")
  libs <- vapply(c("LAPACK_LIBS","BLAS_LIBS","FLIBS"), function(x)
    paste(system2(rbin,c("CMD","config",x),stdout=TRUE),collapse=" "), character(1))
  old <- Sys.getenv("PKG_LIBS",unset=NA_character_)
  on.exit(if(is.na(old)) Sys.unsetenv("PKG_LIBS") else Sys.setenv(PKG_LIBS=old))
  Sys.setenv(PKG_LIBS=paste(libs,collapse=" "))
  Rcpp::sourceCpp("scripts/lapack/qr-unpivoted.cpp",env=.GlobalEnv,
                  cacheDir=file.path(tempdir(),"fastqr-lapack-cache"),showOutput=FALSE)
}
guide_R <- function(f) {
  p <- ncol(f$qr); r <- f$qr[seq_len(p),,drop=FALSE]
  r[lower.tri(r)] <- 0; r
}
guide_lapack <- function(X, output=c("thin","compact","R","full")) {
  output <- match.arg(output); f <- guide_geqrf(X)
  if(output=="compact") return(f)
  r <- guide_R(f)
  if(output=="R") return(r)
  q <- guide_orgqr(f,complete=output=="full")
  if(output=="full") r <- rbind(r,matrix(0,nrow(X)-ncol(X),ncol(X)))
  list(Q=q,R=r)
}
