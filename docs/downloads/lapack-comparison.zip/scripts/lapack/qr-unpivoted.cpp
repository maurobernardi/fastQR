#include <Rcpp.h>
#include <R_ext/Lapack.h>
#include <climits>
#include <cmath>
using namespace Rcpp;
static int workspace_size(double x) {
  if (!R_FINITE(x) || x < 1 || x > INT_MAX) stop("Invalid LAPACK workspace size");
  return (int)std::ceil(x);
}
// [[Rcpp::export]]
List guide_geqrf(NumericMatrix X) {
  int m=X.nrow(), n=X.ncol(), k=std::min(m,n), lda=std::max(1,m), info=0;
  if (m<n || n<1) stop("A nonempty tall or square matrix is required");
  NumericMatrix a=clone(X); NumericVector tau(k); double query; int lwork=-1;
  F77_CALL(dgeqrf)(&m,&n,a.begin(),&lda,tau.begin(),&query,&lwork,&info);
  if(info) stop("DGEQRF workspace query failed");
  lwork=workspace_size(query); NumericVector work(lwork);
  F77_CALL(dgeqrf)(&m,&n,a.begin(),&lda,tau.begin(),work.begin(),&lwork,&info);
  if(info) stop("DGEQRF failed");
  return List::create(_["qr"]=a,_["tau"]=tau);
}
// [[Rcpp::export]]
NumericMatrix guide_orgqr(List factor, bool complete=false) {
  NumericMatrix packed=factor["qr"]; NumericVector tau=factor["tau"];
  int m=packed.nrow(), k=packed.ncol(), n=complete?m:k;
  int lda=std::max(1,m), info=0, lwork=-1; double query;
  NumericMatrix q(m,n);
  for(int j=0;j<k;++j) for(int i=0;i<m;++i) q(i,j)=packed(i,j);
  F77_CALL(dorgqr)(&m,&n,&k,q.begin(),&lda,tau.begin(),&query,&lwork,&info);
  if(info) stop("DORGQR workspace query failed");
  lwork=workspace_size(query); NumericVector work(lwork);
  F77_CALL(dorgqr)(&m,&n,&k,q.begin(),&lda,tau.begin(),work.begin(),&lwork,&info);
  if(info) stop("DORGQR failed");
  return q;
}
