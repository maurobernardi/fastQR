# Checks for the quick/full experiment output, independent of rendering.
read <- function(name) read.csv(paste0("results/",name,".csv"))
z<-read("bench_initial");m<-read("bench_modifications")
stopifnot(all(is.finite(z$seconds)),all(z$seconds>0),all(m$seconds>0),
 all(c("LAPACK DGEQRF","base LAPACK pivoted","base LINPACK")%in%z$method),
 all(c("add_rows","delete_rows","add_columns","delete_columns")%in%m$operation))
u<-read("bench_update_checks");stopifnot(nrow(u)==4,max(as.matrix(u[,-1]))<1e-9)
a<-read("bench_conditioning");stopifnot(nrow(a)==20,
 all(is.finite(a$coefficient_forward[a$status=="finite"])),
 max(a$reconstruction,na.rm=TRUE)<1e-10,
 max(a$orthogonality,na.rm=TRUE)<1e-10)
p<-read("bench_path");stopifnot(max(p$coefficient_error)<1e-9)
source("scripts/lapack-baseline.R");load_guide_lapack()
set.seed(19);X<-matrix(rnorm(90),30,3);saved<-X
for(output in c("thin","full")){
 f<-guide_lapack(X,output)
 stopifnot(identical(X,saved),norm(X-f$Q%*%f$R,"F")/norm(X,"F")<1e-12,
  norm(crossprod(f$Q)-diag(ncol(f$Q)),"F")<1e-12)
}
# Different column scales make a nontrivial pivot likely and test its handling.
X<-sweep(X,2,c(1,1e3,10),"*");f<-base::qr(X,LAPACK=TRUE)
stopifnot(norm(base::qr.Q(f)%*%base::qr.R(f)-X[,f$pivot],"F")/norm(X,"F")<1e-12)
cat("Benchmark outputs and LAPACK reconstruction/pivot checks passed.\n")

for(n in c(300L,600L))for(p in c(20L,60L)){
 set.seed(n+p);X<-matrix(rnorm(n*p),n,p)
 for(method in c("householder","givens","eigen","recursive")){
  f<-switch(method,eigen=fastQR::qr_thin(X),recursive=fastQR::qr(X,nb=8L),
     fastQR::qr(X,type=method))
  stopifnot(norm(f$Q%*%f$R-X,"F")/norm(X,"F")<1e-10,
    norm(crossprod(f$Q)-diag(p),"F")<1e-10)
 }
 r<-fastQR::rchol(X)
 stopifnot(norm(crossprod(r)-crossprod(X),"F")/norm(crossprod(X),"F")<1e-10)
}
cat("All additional thin and R-only methods passed the matched-shape checks.\n")
