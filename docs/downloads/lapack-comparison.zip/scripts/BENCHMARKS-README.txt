From the guide root in R:
  install.packages(c("fastQR", "Rcpp"))
  options(fastQR.guide.benchmark_mode="quick")
  source("scripts/reproducible-benchmarks.R")
For a larger grid, set the mode to "full". A working C++ toolchain is required
by Rcpp::sourceCpp. The adapter links to R's configured LAPACK and BLAS.
DGEQRF computes unpivoted factors; DORGQR explicitly forms Q when needed.
Compilation and data generation are excluded from every timing region.
Results are new guide experiments, not replicas of historical paper tables.
CSV files contain raw timings and errors, including stress-test failures.
Full QR update comparisons require O(n^2) storage. Adjust the grid for RAM.
Thread settings are recorded rather than silently changed. To enforce a thread
count, configure the BLAS before starting R and record the verified setting.
