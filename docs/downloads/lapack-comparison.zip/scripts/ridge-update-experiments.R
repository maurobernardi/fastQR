# Positive-penalty ridge experiments. Source from the guide or vignette root.
ridge_root <- if (dir.exists('../results')) '..' else '.'
ridge_rel <- function(a,b) norm(as.matrix(a-b),'F')/max(1,norm(as.matrix(b),'F'))
ridge_aug <- function(X,alpha) rbind(X,sqrt(alpha)*diag(ncol(X)))
ridge_solve <- function(R,h) backsolve(R,forwardsolve(t(R),h))
ridge_reference <- function(X,Y,alpha) {
 f<-fastQR::qr_lapack(ridge_aug(X,alpha),'thin')
 backsolve(f$R,crossprod(f$Q,rbind(Y,matrix(0,ncol(X),ncol(Y)))))
}
ridge_rows <- function(X,Y,R,h,newX,newY,alpha,lambda_fixed=FALSE) {
 n<-nrow(X);p<-ncol(X);m<-nrow(newX)
 extra<-if(lambda_fixed)rbind(newX,sqrt(m*alpha/n)*diag(p)) else newX
 ru<-fastQR::rupdate(ridge_aug(X,alpha),R,U=t(extra),type='row',fast=FALSE)
 ridge_solve(ru,h+crossprod(newX,newY))
}
ridge_columns <- function(X,Y,R,h,V,alpha,return_state=FALSE) {
 p<-ncol(X);k<-ncol(V)
 Aplus<-rbind(ridge_aug(X,alpha),matrix(0,k,p))
 Vplus<-rbind(V,matrix(0,p,k),sqrt(alpha)*diag(k))
 ru<-fastQR::rupdate(Aplus,R,U=Vplus,type='column',fast=FALSE)
 hu<-rbind(h,crossprod(V,Y));coef<-ridge_solve(ru,hu)
 if(return_state)list(R=ru,h=hu,coeff=coef) else coef
}
ridge_measure <- function(fun,reps=5L) {
 invisible(fun());calls<-1L
 repeat{tt<-system.time(for(i in seq_len(calls))z<-fun())[['elapsed']]
  if(tt>=.03||calls>=256L)break;calls<-2L*calls}
 v<-numeric(reps)
 for(j in seq_len(reps)){gc();v[j]<-system.time(for(i in seq_len(calls))z<-fun())[['elapsed']]/calls}
 v
}
set.seed(20261116)
ridge_bench<-list();ridge_validation<-list();idx<-0L
for(shape in list(c(120L,60L),c(120L,240L),c(300L,450L))){
 n<-shape[1];p<-shape[2];m<-10L;k<-5L;alpha<-n*.2
 X<-matrix(rnorm(n*p),n,p);Y<-matrix(rnorm(n*2),n,2)
 newX<-matrix(rnorm(m*p),m,p);newY<-matrix(rnorm(m*2),m,2);V<-matrix(rnorm(n*k),n,k)
 R<-fastQR::qr_lapack(ridge_aug(X,alpha),'R');h<-crossprod(X,Y)
 for(operation in c('rows_fixed_alpha','rows_fixed_lambda','columns_fixed_alpha')){
  columns<-operation=='columns_fixed_alpha';fixed_lambda<-operation=='rows_fixed_lambda'
  targetX<-if(columns)cbind(X,V) else rbind(X,newX)
  targetY<-if(columns)Y else rbind(Y,newY)
  target_alpha<-if(fixed_lambda)alpha*(n+m)/n else alpha
  update<-if(columns)function()ridge_columns(X,Y,R,h,V,alpha) else
   function()ridge_rows(X,Y,R,h,newX,newY,alpha,fixed_lambda)
  recompute<-function(){
   # Same R-only solve and response cross-product as the update workflow.
   xx<-if(columns)cbind(X,V) else rbind(X,newX)
   yy<-if(columns)Y else rbind(Y,newY)
   rr<-fastQR::qr_lapack(ridge_aug(xx,target_alpha),'R')
   ridge_solve(rr,crossprod(xx,yy))
  }
  ref<-ridge_reference(targetX,targetY,target_alpha)
  bu<-update();br<-recompute();fit<-fastQR::qrmridge(targetY,targetX,target_alpha/nrow(targetX),type='R')
  idx<-idx+1L
  ridge_validation[[idx]]<-data.frame(n=n,p=p,operation=operation,
   coefficient_error=ridge_rel(bu,ref),prediction_error=ridge_rel(targetX%*%bu,targetX%*%ref),
   recompute_error=ridge_rel(br,ref),public_fit_error=ridge_rel(fit$coeff,ref))
  # Alternate order between settings, with warm-up and calibrated calls.
  methods<-list(update=update,recompute=recompute)
  if(idx%%2L==0L)methods<-rev(methods)
  ridge_bench[[idx]]<-do.call(rbind,lapply(names(methods),function(name)
   data.frame(n=n,p=p,operation=operation,method=name,repetition=1:5,seconds=ridge_measure(methods[[name]]))))
 }
}
ridge_bench<-do.call(rbind,ridge_bench);ridge_validation<-do.call(rbind,ridge_validation)
stopifnot(max(as.matrix(ridge_validation[,4:7]))<1e-9)
ridge_medians<-aggregate(seconds~n+p+operation+method,ridge_bench,median)
ridge_comparison<-do.call(rbind,lapply(split(ridge_medians,interaction(ridge_medians$n,ridge_medians$p,ridge_medians$operation,drop=TRUE)),function(z)
 data.frame(n=z$n[1],p=z$p[1],operation=z$operation[1],
 update_ms=1000*z$seconds[z$method=='update'],recompute_ms=1000*z$seconds[z$method=='recompute'],
 speedup=z$seconds[z$method=='recompute']/z$seconds[z$method=='update'])))
# Growing predictor set: transition through p=n at fixed total penalty.
set.seed(744);n<-100L;p0<-60L;steps<-10L;batch<-10L;alpha<-20
Xall<-matrix(rnorm(n*(p0+steps*batch)),n,p0+steps*batch);Y<-matrix(rnorm(n*2),n,2)
X<-Xall[,seq_len(p0),drop=FALSE]
t0<-proc.time()[['elapsed']];R<-fastQR::qr_lapack(ridge_aug(X,alpha),'R');h<-crossprod(X,Y)
initial_time<-proc.time()[['elapsed']]-t0;tu<-tr<-initial_time
ridge_path<-vector('list',steps)
for(s in seq_len(steps)){
 V<-Xall[,ncol(X)+seq_len(batch),drop=FALSE]
 t0<-proc.time()[['elapsed']];z<-ridge_columns(X,Y,R,h,V,alpha,TRUE);tu<-tu+proc.time()[['elapsed']]-t0
 target<-cbind(X,V)
 t0<-proc.time()[['elapsed']];rr<-fastQR::qr_lapack(ridge_aug(target,alpha),'R');br<-ridge_solve(rr,crossprod(target,Y));tr<-tr+proc.time()[['elapsed']]-t0
 ref<-ridge_reference(target,Y,alpha)
 ridge_path[[s]]<-data.frame(step=s,n=n,p=ncol(target),update_cumulative=tu,recompute_cumulative=tr,
 coefficient_error=ridge_rel(z$coeff,ref),prediction_error=ridge_rel(target%*%z$coeff,target%*%ref))
 X<-target;R<-z$R;h<-z$h
}
ridge_path<-do.call(rbind,ridge_path)
ridge_path$operation<-'Add columns'
set.seed(745);n0<-60L;p<-100L;steps<-10L;batch<-10L;alpha<-20
Xall<-matrix(rnorm((n0+steps*batch)*p),n0+steps*batch,p)
Yall<-matrix(rnorm((n0+steps*batch)*2),n0+steps*batch,2)
X<-Xall[seq_len(n0),,drop=FALSE];Y<-Yall[seq_len(n0),,drop=FALSE]
t0<-proc.time()[['elapsed']];R<-fastQR::qr_lapack(ridge_aug(X,alpha),'R');h<-crossprod(X,Y)
initial_time<-proc.time()[['elapsed']]-t0;tu<-tr<-initial_time
row_path<-vector('list',steps)
for(s in seq_len(steps)){
 ids<-nrow(X)+seq_len(batch);newX<-Xall[ids,,drop=FALSE];newY<-Yall[ids,,drop=FALSE]
 t0<-proc.time()[['elapsed']]
 R<-fastQR::rupdate(ridge_aug(X,alpha),R,U=t(newX),type='row',fast=FALSE)
 h<-h+crossprod(newX,newY);bu<-ridge_solve(R,h);tu<-tu+proc.time()[['elapsed']]-t0
 xx<-rbind(X,newX);yy<-rbind(Y,newY)
 t0<-proc.time()[['elapsed']];rr<-fastQR::qr_lapack(ridge_aug(xx,alpha),'R');br<-ridge_solve(rr,crossprod(xx,yy));tr<-tr+proc.time()[['elapsed']]-t0
 ref<-ridge_reference(xx,yy,alpha)
 row_path[[s]]<-data.frame(step=s,n=nrow(xx),p=p,update_cumulative=tu,recompute_cumulative=tr,
 coefficient_error=ridge_rel(bu,ref),prediction_error=ridge_rel(xx%*%bu,xx%*%ref),operation='Add rows')
 X<-xx;Y<-yy
}
ridge_path<-rbind(ridge_path,do.call(rbind,row_path))
stopifnot(max(ridge_path$coefficient_error)<1e-9)
write.csv(ridge_bench,file.path(ridge_root,'results/bench_ridge_timings.csv'),row.names=FALSE)
write.csv(ridge_validation,file.path(ridge_root,'results/bench_ridge_validation.csv'),row.names=FALSE)
write.csv(ridge_comparison,file.path(ridge_root,'results/bench_ridge_summary.csv'),row.names=FALSE)
write.csv(ridge_path,file.path(ridge_root,'results/bench_ridge_path.csv'),row.names=FALSE)
writeLines(c(paste('fastQR',utils::packageVersion('fastQR')),paste('library',find.package('fastQR')),capture.output(sessionInfo())),file.path(ridge_root,'results/bench_ridge_environment.txt'))
