library(fastQR)
ref<-function(X,Y,lambda){
 n<-nrow(X);p<-ncol(X);Y<-as.matrix(Y)
 unname(base::qr.coef(base::qr(rbind(X,sqrt(n*lambda)*diag(p))),rbind(Y,matrix(0,p,ncol(Y)))))
}
close<-function(a,b,tol=1e-8)stopifnot(length(a)==length(b),max(abs(a-b))<tol*max(1,max(abs(b))))
expect_error<-function(expr){stopifnot(inherits(tryCatch({force(expr);NULL},error=identity),'error'))}
cases<-0L
for(d in list(c(1L,1L),c(6L,6L),c(20L,4L),c(31L,5L))){
 n<-d[1];p<-d[2];set.seed(901+n);X<-matrix(rnorm(n*p),n,p)
 if(n>p)X[,1]<-1
 Y<-matrix(rnorm(n*3),n,3);test<-X[seq_len(min(2,n)),,drop=FALSE]
 for(lambda in c(0,1e-8,.1,4))for(type in c('QR','R'))for(pred in c(FALSE,TRUE)){
  expected<-ref(X,Y,lambda)
  a<-fastQR::qrmridge(Y,X,lambda,type=type,X_test=if(pred)test else NULL)
  b<-fastQR::qrridge(Y[,1],X,lambda,type=type,X_test=if(pred)test else NULL)
  close(a$coeff,expected);close(b$coeff,expected[,1]);close(a$fitted,X%*%expected)
  close(a$XTX,crossprod(X));close(a$XTY,crossprod(X,Y));close(a$XTy,a$XTY)
  close(b$XTy,crossprod(X,Y[,1]));close(b$XTX,crossprod(X))
  err<-Y-X%*%expected;sse<-sum(err[,1]^2);total<-sum((Y[,1]-mean(Y[,1]))^2)
  close(b$residuals_norm2,sse)
  if(total>0)close(b$R2,1-sse/total)else stopifnot(is.na(b$R2))
  if(n>p){close(a$Sigma_hat,crossprod(err)/(n-p));close(b$sigma2_hat,sse/(n-p))}
  else stopifnot(all(is.na(a$Sigma_hat)),is.na(b$sigma2_hat))
  if(type=='QR'){
   close(a$Q%*%a$R,crossprod(X)/n+lambda*diag(p));close(crossprod(a$Q),diag(p))
  }else close(crossprod(a$R),crossprod(X)+n*lambda*diag(p))
  stopifnot(!anyDuplicated(names(a)),!anyDuplicated(names(b)))
  if(pred){close(a$predicted,test%*%expected);close(b$predicted,test%*%expected[,1])}
  cases<-cases+1L
 }
}
# Positive penalties handle dependent/zero columns; lambda=0 rejects singular fits.
for(X in list(matrix(0,12,3),cbind(1,1:12,1:12))){
 Y<-cbind(1:12,12:1)
 for(type in c('QR','R')){
  a<-fastQR::qrmridge(Y,X,.5,type=type);close(a$coeff,ref(X,Y,.5))
  expect_error(fastQR::qrridge(Y[,1],X,0,type=type))
  expect_error(fastQR::qrmridge(Y,X,0,type=type))
 }
}
X<-matrix(rnorm(20*4),20,4);y<-rnorm(20)
for(lambda in c(-1,NA_real_,Inf))expect_error(fastQR::qrridge(y,X,lambda))
expect_error(fastQR::qrridge(y[-1],X,.1));expect_error(fastQR::qrridge(y,X,.1,type='typo'))
expect_error(fastQR::qrmridge(cbind(y,y),X,.1,X_test=matrix(1,2,5)))
cat(cases,'ridge fits match independent augmented-QR references; edge checks passed\n')
# Normalized loss is invariant under replication of the same observations.
set.seed(914);X<-matrix(rnorm(16*3),16,3);y<-rnorm(16)
for(type in c('QR','R')){
 a<-fastQR::qrridge(y,X,.4,type=type)
 b<-fastQR::qrridge(rep(y,3),X[rep(seq_len(16),3),,drop=FALSE],.4,type=type)
 close(a$coeff,b$coeff)
 one<-fastQR::qrmridge(matrix(y,ncol=1),X,.4,type=type)
 close(one$coeff,a$coeff);stopifnot(identical(dim(one$coeff),c(3L,1L)))
}
