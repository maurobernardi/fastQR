library(fastQR)
metrics <- list()
check_completion <- function(q,label){
 original<-serialize(q,NULL)
 out<-fastQR::qr_Q_reduced2full(q)
 n<-nrow(q);p<-ncol(q)
 stopifnot(is.matrix(out),typeof(out)=="double",identical(dim(out),c(n,n)),
   all(is.finite(out)),identical(serialize(q,NULL),original),
   identical(unname(out[,seq_len(p),drop=FALSE]),unname(q)))
 err<-norm(crossprod(out)-diag(n),"F")/sqrt(n)
 err2<-norm(tcrossprod(out)-diag(n),"F")/sqrt(n)
 cross<-if(p==0L)0 else norm(crossprod(q,out[,-seq_len(p),drop=FALSE]),"F")
 stopifnot(err<1e-10,err2<1e-10,cross<1e-10)
 metrics[[length(metrics)+1L]]<<-data.frame(label=label,n=n,p=p,orthogonality=err,cross=cross)
 invisible(out)
}
# The reported counterexample and every coordinate subspace of dimension 3 in R^8.
for(cols in combn(8L,3L,simplify=FALSE)){
 q<-diag(8)[,cols,drop=FALSE]
 check_completion(q,paste0("coordinate/",paste(cols,collapse="-")))
 check_completion(sweep(q,2,c(-1,1,-1),"*"),paste0("signed/",paste(cols,collapse="-")))
}
# Random bases, including codimension 1 and one-column input.
for(seed in c(7L,17L,37L,67L))for(d in list(c(2L,1L),c(5L,4L),c(12L,5L),c(100L,1L),c(100L,90L))){
 set.seed(seed);q<-base::qr.Q(base::qr(matrix(rnorm(prod(d)),d[1],d[2]),LAPACK=TRUE))
 check_completion(q,paste("random",seed,paste(d,collapse="x"),sep="/"))
}
# A rotation within the given subspace must not alter the preserved columns.
q<-diag(8)[,c(4,6,8)]
rot<-base::qr.Q(base::qr(matrix(seq_len(9)+c(0,1,0,0,0,1,1,0,0),3,3),LAPACK=TRUE))
check_completion(q%*%rot,"rotated_coordinate")
for(eps in c(1e-4,1e-8,1e-12)){
 set.seed(81);a<-q+eps*matrix(rnorm(24),8,3)
 check_completion(base::qr.Q(base::qr(a,LAPACK=TRUE)),paste("near_coordinate",eps))
}
# Zero columns are the empty orthonormal basis; the established result is I_n.
for(n in c(1L,8L)){
 q<-matrix(numeric(),n,0)
 out<-check_completion(q,paste("empty_basis",n))
 stopifnot(identical(out,diag(n)))
}
# Round-trip ownership on the R side and reuse by QR updates/downdates.
set.seed(91);X<-matrix(rnorm(25*6),25,6);thin<-fastQR::qr(X,complete=FALSE)
qfull<-check_completion(thin$Q,"thin_Q_from_fastQR")
qfull<-unserialize(serialize(qfull,NULL));gc()
rfull<-rbind(thin$R,matrix(0,25-6,6))
stopifnot(norm(qfull%*%rfull-X,"F")/norm(X,"F")<1e-10)
u<-matrix(rnorm(25*2),25,2)
a<-fastQR::qrupdate(qfull,rfull,k=7L,U=u,type="column",complete=TRUE)
stopifnot(norm(a$Q%*%a$R-cbind(X,u),"F")/norm(cbind(X,u),"F")<1e-10,
 norm(crossprod(a$Q)-diag(25),"F")/5<1e-10)
d<-fastQR::qrdowndate(qfull,rfull,k=3L,m=2L,type="column",complete=TRUE)
stopifnot(norm(d$Q%*%d$R-X[,-(3:4)],"F")/norm(X[,-(3:4)],"F")<1e-10,
 norm(crossprod(d$Q)-diag(25),"F")/5<1e-10)
# Invalid input must fail in R, rather than returning a false completion.
expect_error<-function(q,pattern){
 msg<-tryCatch({fastQR::qr_Q_reduced2full(q);NULL},error=function(e)conditionMessage(e))
 stopifnot(!is.null(msg),grepl(pattern,msg,fixed=TRUE))
}
expect_error(diag(3),"n x n") # Preserve the pre-existing square-input contract.
expect_error(matrix(1,2,3),"ncol(Q)")
expect_error(matrix(numeric(),0,1),"ncol(Q)")
expect_error(matrix(0,4,2),"orthonormal")
expect_error(cbind(c(1,0,0),c(1,0,0)),"orthonormal")
expect_error(2*diag(4)[,1:2],"orthonormal")
for(value in c(NA_real_,NaN,Inf,-Inf)){
 q<-diag(4)[,1:2];q[1,1]<-value;expect_error(q,"finite")
}
report<-do.call(rbind,metrics)
path<-Sys.getenv("FASTQR_COMPLETION_REPORT",unset="")
if(nzchar(path))write.csv(report,path,row.names=FALSE)
cat(nrow(report),"valid orthogonal completions plus ownership/reuse and invalid-input checks passed.\n")
