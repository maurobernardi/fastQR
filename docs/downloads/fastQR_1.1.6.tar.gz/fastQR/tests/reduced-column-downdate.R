library(fastQR)
metrics<-list()
check_red<-function(q,r,target,k,m,fast=FALSE,label=""){
 before<-serialize(list(q,r),NULL)
 d<-fastQR::qrdowndate(q,r,k=k,m=m,type="column",complete=FALSE,fast=fast)
 n<-nrow(target);p<-ncol(target)
 stopifnot(is.list(d),identical(names(d),c("Q","R")),
   is.matrix(d$Q),is.matrix(d$R),typeof(d$Q)=="double",typeof(d$R)=="double",
   identical(dim(d$Q),c(n,p)),identical(dim(d$R),c(p,p)),
   all(is.finite(d$Q)),all(is.finite(d$R)),
   identical(before,serialize(list(q,r),NULL)))
 rec<-norm(d$Q%*%d$R-target,"F")/norm(target,"F")
 ort<-norm(crossprod(d$Q)-diag(p),"F")/sqrt(p)
 stopifnot(rec<1e-10,ort<1e-10,all(d$R[lower.tri(d$R)]==0))
 metrics[[length(metrics)+1L]]<<-data.frame(label=label,n=n,p=p,k=k,m=m,
      fast=fast,reconstruction=rec,orthogonality=ort)
 invisible(d)
}
# All blocks at all positions, including right-boundary and p-1 deletions.
# Accept each factor in full or thin form independently.
for(seed in c(11L,43L))for(dims in list(c(25L,6L),c(17L,7L),c(8L,8L))){
 set.seed(seed);n<-dims[1];p<-dims[2];X<-matrix(rnorm(n*p),n,p)
 f<-fastQR::qr(X,complete=TRUE)
 for(m in seq_len(p-1L))for(k in seq_len(p-m+1L)){
  target<-X[,-seq.int(k,length.out=m),drop=FALSE]
  for(qthin in c(FALSE,TRUE))for(rthin in c(FALSE,TRUE))for(fast in c(FALSE,TRUE)){
   q<-if(qthin)f$Q[,seq_len(p),drop=FALSE]else f$Q
   r<-if(rthin)f$R[seq_len(p),,drop=FALSE]else f$R
   check_red(q,r,target,k,m,fast,paste(seed,n,p,qthin,rthin,sep="/"))
  }
 }
}
# Repeated calls use only the reduced output of the preceding deletion.
for(pattern in c("first","middle","last"))for(start_full in c(FALSE,TRUE)){
 set.seed(59);X<-matrix(rnorm(60*12),60,12);f<-fastQR::qr(X,complete=start_full)
 iteration<-0L
 while(ncol(X)>1L){
  iteration<-iteration+1L;p<-ncol(X);m<-min(if(iteration%%2L)1L else 2L,p-1L)
  k<-switch(pattern,first=1L,middle=max(1L,(p-m+2L)%/%2L),last=p-m+1L)
  target<-X[,-seq.int(k,length.out=m),drop=FALSE]
  f<-check_red(f$Q,f$R,target,k,m,FALSE,paste("chain",pattern,start_full))
  X<-target
 }
}
# Public defaults also dispatch to the reduced column path.
set.seed(71);X<-matrix(rnorm(20*5),20,5);f<-fastQR::qr(X,complete=FALSE)
a<-fastQR::qrdowndate(f$Q,f$R,k=2L)
stopifnot(norm(a$Q%*%a$R-X[,-2],"F")/norm(X[,-2],"F")<1e-10,
 identical(dim(a$Q),c(20L,4L)))
# Integer matrices are coerced, without modifying their R inputs.
q<-matrix(as.integer(diag(8)),8,8)
r<-matrix(0L,8,3);r[1:3,]<-matrix(c(4L,0L,0L,2L,5L,0L,1L,3L,6L),3,3)
X<-q%*%r
check_red(q,r,X[,-1,drop=FALSE],1L,1L,FALSE,"integer/full")
check_red(q[,1:3],r[1:3,],X[,-3,drop=FALSE],3L,1L,FALSE,"integer/thin")
z<-fastQR::qrdowndate(q,r,k=1L,m=1L,type="column",complete=TRUE)
stopifnot(identical(dim(z$Q),c(8L,8L)),norm(crossprod(z$Q)-diag(8),"F")<1e-10)
# Ownership of concrete R outputs survives serialization and garbage collection.
a<-unserialize(serialize(a,NULL));gc()
stopifnot(norm(crossprod(a$Q)-diag(4),"F")<1e-10)
# Shape and index safety checks remain active even in fast mode.
expect_error<-function(expr){
 msg<-tryCatch({force(expr);NULL},error=function(e)conditionMessage(e))
 stopifnot(!is.null(msg))
}
q<-f$Q;r<-f$R;p<-ncol(r)
for(fast in c(FALSE,TRUE)){
 for(k in c(0L,-1L,p+1L,NA_integer_))
  expect_error(fastQR::qrdowndate(q,r,k=k,m=1L,type="column",complete=FALSE,fast=fast))
 for(m in c(0L,-1L,p,p+1L,NA_integer_))
  expect_error(fastQR::qrdowndate(q,r,k=1L,m=m,type="column",complete=FALSE,fast=fast))
 expect_error(fastQR::qrdowndate(q[,-1],r,k=1L,type="column",complete=FALSE,fast=fast))
 expect_error(fastQR::qrdowndate(q,r[-1,],k=1L,type="column",complete=FALSE,fast=fast))
 expect_error(fastQR::qrdowndate(q,r,k=p,m=2L,type="column",complete=FALSE,fast=fast))
}
for(value in c(NA_real_,NaN,Inf,-Inf)){
 badq<-q;badq[1,1]<-value
 expect_error(fastQR::qrdowndate(badq,r,k=1L,type="column",complete=FALSE,fast=FALSE))
 badr<-r;badr[1,1]<-value
 expect_error(fastQR::qrdowndate(q,badr,k=1L,type="column",complete=FALSE,fast=FALSE))
}
# These helpers remain C++ internals, not additional R functions.
stopifnot(!exists("qrdeletecol_red",asNamespace("fastQR"),inherits=FALSE),
 !exists("qrdeletemcols_adj_red",asNamespace("fastQR"),inherits=FALSE))
report<-do.call(rbind,metrics)
path<-Sys.getenv("FASTQR_REDUCED_REPORT",unset="")
if(nzchar(path))write.csv(report,path,row.names=FALSE)
cat(nrow(report),"reduced column-deletion cases plus defaults, ownership and invalid-input checks passed.\n")
