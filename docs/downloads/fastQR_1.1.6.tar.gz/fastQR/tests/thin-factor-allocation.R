library(fastQR)
records<-list()
for(d in list(c(9L,1L),c(20L,5L),c(51L,8L),c(10L,10L))){
 n<-d[1];p<-d[2]
 set.seed(600+n)
 regular<-matrix(rnorm(n*p),n,p)
 deficient<-regular;if(p>1)deficient[,p]<-deficient[,1]
 matrices<-list(regular=regular,zero=matrix(0,n,p),deficient=deficient,
   coordinate=diag(n)[,seq_len(p),drop=FALSE],scaled=regular*1e-8)
 for(label in names(matrices))for(method in c('householder','givens')){
  X<-matrices[[label]];before<-serialize(X,NULL)
  a<-fastQR::qr(X,type=method,complete=FALSE)
  b<-fastQR::qr(X,type=method,complete=TRUE)
  rec<-norm(a$Q%*%a$R-X,'F')/max(1,norm(X,'F'))
  ort<-norm(crossprod(a$Q)-diag(p),'F')/sqrt(p)
  delta<-norm(a$Q-b$Q[,seq_len(p),drop=FALSE],'F')/sqrt(p)
  stopifnot(identical(dim(a$Q),c(n,p)),identical(dim(a$R),c(p,p)),
   rec<1e-10,ort<1e-10,delta<1e-10,
   identical(a$R,b$R[seq_len(p),,drop=FALSE]),identical(before,serialize(X,NULL)))
  if(label=='regular'){
   z<-fastQR::qrsolve(X,seq_len(n));stopifnot(norm(X%*%z-X%*%lm.fit(X,seq_len(n))$coefficients,'F')<1e-8)
   stopifnot(norm(crossprod(fastQR::qrchol(X))-crossprod(X),'F')/max(1,norm(crossprod(X),'F'))<1e-10)
  }
  records[[length(records)+1L]]<-data.frame(n=n,p=p,label=label,method=method,reconstruction=rec,orthogonality=ort,Q_difference=delta)
 }
}
# Empty column input retains the same thin dimensions.
for(method in c('householder','givens')){
 a<-fastQR::qr(matrix(numeric(),12,0),type=method,complete=FALSE)
 stopifnot(identical(dim(a$Q),c(12L,0L)),identical(dim(a$R),c(0L,0L)))
}
report<-do.call(rbind,records);path<-Sys.getenv('FASTQR_THIN_REPORT')
if(nzchar(path))write.csv(report,path,row.names=FALSE)
cat(nrow(report),'thin/full factor comparisons passed, plus solve/chol and empty-column checks\n')
