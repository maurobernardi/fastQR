library(fastQR);set.seed(664)
X<-matrix(rnorm(18*5),18,5);f<-fastQR::qr(X,complete=TRUE);out<-list()
for(type in c('row','column'))for(m in c(1L,2L,4L)){
 U<-matrix(rnorm(if(type=='row')5*m else 18*m),if(type=='row')5 else 18,m)
 for(k in seq_len(if(type=='row')19L else 6L))for(full in c(FALSE,TRUE))for(fast in c(FALSE,TRUE)){
  a<-fastQR::qrupdate(f$Q,f$R,k=k,U=U,type=type,complete=full,fast=fast)
  target<-if(type=='row')rbind(X[seq_len(k-1L),,drop=FALSE],t(U),X[seq.int(k,length.out=19L-k),,drop=FALSE])else cbind(X[,seq_len(k-1L),drop=FALSE],U,X[,seq.int(k,length.out=6L-k),drop=FALSE])
  stopifnot(norm(a$Q%*%a$R-target,'F')/norm(target,'F')<1e-10,
    norm(crossprod(a$Q)-diag(ncol(a$Q)),'F')<1e-10)
  out[[length(out)+1L]]<-a
 }
}
cat(length(out), 'update cases passed after removing wrapper scratch allocations\n')
