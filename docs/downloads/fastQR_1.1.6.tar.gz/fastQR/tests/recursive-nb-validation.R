library(fastQR)
set.seed(301)
cases <- 0L
for (dims in list(c(12L,1L),c(12L,5L),c(5L,5L))) {
 X <- matrix(rnorm(prod(dims)), dims[1], dims[2]); y <- rnorm(dims[1])
 for (nb in c(1L,-1L,-5L,NA_integer_)) {
  for (call in list(function() fastQR::qr(X,nb=nb,complete=FALSE),
                    function() fastQR::qrchol(X,nb=nb),
                    function() fastQR::qrsolve(X,y,nb=nb))) {
   err <- tryCatch(call(),error=identity)
   stopifnot(inherits(err,'error'),grepl('recursive reduced QR requires nb >= 2',conditionMessage(err),fixed=TRUE))
   cases <- cases+1L
  }
 }
 for (nb in c(2L,3L,4L,12L)) {
  f <- fastQR::qr(X,nb=nb,complete=FALSE)
  stopifnot(norm(f$Q%*%f$R-X,'F')/max(1,norm(X,'F'))<1e-10,
            norm(crossprod(f$Q)-diag(ncol(X)),'F')<1e-10)
  cases <- cases+1L
 }
 f <- fastQR::qr(X,nb=1L,complete=TRUE)
 stopifnot(norm(f$Q%*%f$R-X,'F')/max(1,norm(X,'F'))<1e-10,
           norm(crossprod(f$Q)-diag(nrow(X)),'F')<1e-10)
 cases <- cases+1L
}
cat(cases,'recursive nb validation cases passed\n')
