library(fastQR)
set.seed(71)
for (d in list(c(30L, 6L), c(6L, 6L), c(6L, 12L), c(1L, 1L), c(1L, 5L), c(8L, 1L))) {
 for (kind in c("random", "zero", "deficient")) {
  X <- matrix(rnorm(prod(d)), d[1], d[2])
  if (kind == "zero") X[] <- 0
  if (kind == "deficient" && d[2] > 1) X[,d[2]] <- X[,1]
  before <- serialize(X, NULL)
  for (out in c("thin", "full")) {
   f <- qr_lapack(X, out)
   q <- if (out == "full") d[1] else min(d)
   stopifnot(identical(dim(f$Q), c(d[1], q)),
             identical(dim(f$R), c(q, d[2])),
             norm(f$Q %*% f$R-X,"F")/max(1,norm(X,"F")) < 1e-12,
             norm(crossprod(f$Q)-diag(q),"F") < 1e-12,
             identical(serialize(X,NULL),before))
  }
  r <- qr_lapack(X, "R")
  stopifnot(identical(r, qr_lapack(X)$R))
  z <- qr_lapack(X,"compact")
  stopifnot(identical(dim(z$qr), d), length(z$tau) == min(d))
  # Reconstruct the packed factor independently through Householder reflectors.
  Q <- diag(d[1])
  for (j in seq_len(min(d))) {
   v <- numeric(d[1]); v[j] <- 1
   if (j < d[1]) v[(j+1):d[1]] <- z$qr[(j+1):d[1],j]
   Q <- Q - z$tau[j] * tcrossprod(drop(Q %*% v), v)
  }
  stopifnot(norm(Q[,seq_len(min(d)),drop=FALSE] %*% r-X,"F")/max(1,norm(X,"F")) < 1e-12)
  # Compare R with R's pivoted LAPACK factorization after applying its permutation.
  b <- base::qr(X,LAPACK=TRUE)
  rr <- qr_lapack(X[,b$pivot,drop=FALSE],"R")
  br <- base::qr.R(b)
  stopifnot(norm(abs(rr)-abs(br),"F")/max(1,norm(br,"F")) < 1e-12)
 }
}
for (X in list(matrix(NA_real_,2,2), matrix(Inf,2,2), matrix(numeric(),0,2),
               matrix(1+1i,2,2), data.frame(x=1:2), matrix("a",2,2)))
 stopifnot(inherits(try(qr_lapack(X),silent=TRUE),"try-error"))
stopifnot(inherits(try(qr_lapack(matrix(1,2,2),"invalid"),silent=TRUE),"try-error"))
stopifnot(norm(qr_lapack(matrix(1:12,4,3))$Q %*% qr_lapack(matrix(1:12,4,3))$R - matrix(1:12,4,3),"F") < 1e-12)
# Reuse full LAPACK factors in existing update/downdate interfaces.
X <- matrix(rnorm(150),30,5); f <- qr_lapack(X,"full")
U <- matrix(rnorm(30),30,1)
a <- fastQR::qrupdate(f$Q,f$R,k=6L,U=U,type="column",complete=FALSE)
stopifnot(norm(a$Q %*% a$R-cbind(X,U),"F") < 1e-10)
b <- fastQR::qrdowndate(f$Q,f$R,k=2L,m=1L,type="column",complete=TRUE)
stopifnot(norm(b$Q %*% b$R-X[,-2],"F") < 1e-10,
          norm(crossprod(b$Q)-diag(30),"F") < 1e-10)
