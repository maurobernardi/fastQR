library(fastQR)
capture <- function(expr) {
 warnings<-character()
 value<-withCallingHandlers(expr,warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')})
 list(value=value,warnings=warnings)
}
set.seed(404); cases<-0L
for(d in list(c(14L,5L),c(5L,5L),c(7L,1L)))for(r in 0:d[2]){
 n<-d[1];p<-d[2]
 X<-if(r==0)matrix(0,n,p)else matrix(rnorm(n*r),n,r)%*%cbind(diag(r),matrix(rnorm(r*(p-r)),r,p-r))
 for(pivot in c(FALSE,TRUE)){
  f<-fastQR::qr_fast(X,pivot=pivot,tol=1e-10)
  # Without pivoting use matrices with independent leading columns.
  stopifnot(f$rank==r)
  snapshot<-serialize(f,NULL)
  for(full in c(FALSE,TRUE)){
   q<-capture(fastQR::qr_Q(f$qr,f$qraux,rank=r,complete=full))
   a<-capture(fastQR::qr_R(f$qr,rank=r,complete=full))
   width<-if(full && r==p)n else r
   stopifnot(identical(dim(q$value),c(n,width)),identical(dim(a$value),c(width,p)),
      length(q$warnings)==as.integer(full && r<p),length(a$warnings)==as.integer(full && r<p))
   if(full && r<p)stopifnot(grepl("'complete' has been set to FALSE",q$warnings,fixed=TRUE),grepl("'complete' has been set to FALSE",a$warnings,fixed=TRUE))
   target<-if(pivot)X[,f$pivot,drop=FALSE]else X
   stopifnot(norm(q$value%*%a$value-target,'F')/max(1,norm(target,'F'))<1e-10,
      norm(crossprod(q$value)-diag(width),'F')<1e-10,
      identical(snapshot,serialize(f,NULL)))
   if(pivot){
    unpivoted<-capture(fastQR::qr_R(f$qr,rank=r,pivot=f$pivot,complete=full))
    stopifnot(norm(q$value%*%unpivoted$value-X,'F')/max(1,norm(X,'F'))<1e-10)
   }
   cases<-cases+1L
  }
  qdefault<-capture(fastQR::qr_Q(f$qr,f$qraux,rank=r))
  rdefault<-capture(fastQR::qr_R(f$qr,rank=r))
  stopifnot(length(qdefault$warnings)==0L,length(rdefault$warnings)==0L)
 }
}
for(r in c(-1L,NA_integer_,6L)){
 e<-tryCatch(fastQR::qr_R(matrix(0,10,5),rank=r),error=identity)
 stopifnot(inherits(e,'error'))
}
cat(cases,'complete/rank policy cases passed, plus default and invalid-rank checks\n')
