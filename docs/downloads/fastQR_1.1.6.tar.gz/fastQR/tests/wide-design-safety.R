library(fastQR)
checks<-0L
expect_error<-function(expr){
 e<-suppressWarnings(tryCatch({force(expr);NULL},error=identity))
 stopifnot(inherits(e,'error'),!grepl('bad_alloc|segfault|C stack',conditionMessage(e)))
 checks<<-checks+1L
}
for(d in list(c(1L,3L),c(2L,5L),c(4L,6L))){
 n<-d[1];p<-d[2];set.seed(700+n);original<-matrix(rnorm(n*p),n,p)
 for(X in list(original,matrix(0,n,p))){
  y<-seq_len(n);snapshot<-serialize(X,NULL)
  for(method in c('householder','givens'))for(full in c(FALSE,TRUE)){
   a<-fastQR::qr(X,type=method,complete=full)
   stopifnot(identical(dim(a$Q),c(n,n)),identical(dim(a$R),c(n,p)),
    norm(a$Q%*%a$R-X,'F')/max(1,norm(X,'F'))<1e-10,
    norm(crossprod(a$Q)-diag(n),'F')<1e-10)
   checks<-checks+1L
  }
  expect_error(fastQR::qr_thin(X))
  a<-fastQR::qr(X,complete=TRUE)
  for(full in c(FALSE,TRUE)){
   b<-suppressWarnings(fastQR::qr(X,nb=2L,complete=full))
   stopifnot(norm(b$Q%*%b$R-X,'F')/max(1,norm(X,'F'))<1e-10)
  }
  for(pivot in c(FALSE,TRUE)){
   f<-fastQR::qr_fast(X,pivot=pivot)
   q<-fastQR::qr_Q_full(f$qr,f$qraux)
   qa<-suppressWarnings(fastQR::qr_Q(f$qr,f$qraux,complete=TRUE))
   r<-suppressWarnings(fastQR::qr_R(f$qr,complete=TRUE))
   target<-if(pivot)X[,f$pivot,drop=FALSE]else X
   stopifnot(norm(q-qa,'F')<1e-10,norm(q%*%r-target,'F')/max(1,norm(X,'F'))<1e-10,
     norm(crossprod(q)-diag(n),'F')<1e-10,
     norm(fastQR::qr_Qty(f$qr,f$qraux,y)-drop(crossprod(q,y)),'2')<1e-10,
     norm(fastQR::qr_Qy(f$qr,f$qraux,y)-drop(q%*%y),'2')<1e-10)
   stopifnot(norm(fastQR::qr_lse_Qty(X,y)-drop(crossprod(fastQR::qr_Q_full(fastQR::qr_fast(X)$qr,fastQR::qr_fast(X)$qraux),y)),'2')<1e-10)
   rnk<-if(pivot)f$rank else n
   qr<-suppressWarnings(fastQR::qr_Q(f$qr,f$qraux,rank=rnk,complete=FALSE))
   rr<-fastQR::qr_R(f$qr,rank=rnk)
   stopifnot(norm(qr%*%rr-target,'F')/max(1,norm(X,'F'))<1e-10)
   if(pivot)stopifnot(norm(fastQR::qr_X(q,r,pivot=f$pivot)-X,'F')/max(1,norm(X,'F'))<1e-10)
   for(fun in list(function()fastQR::qr_coef(f$qr,f$qraux,y,rank=n),
                   function()fastQR::qr_fitted(f$qr,f$qraux,y),
                   function()fastQR::qr_resid(f$qr,f$qraux,y)))expect_error(fun())
   expect_error(fastQR::qr_Q_full(f$qr,numeric(0)))
   checks<-checks+1L
  }
  Y<-cbind(y,2*y)
  for(type in c('QR','R')){
   expect_error(fastQR::qrls(y,X,type=type))
   expect_error(fastQR::qrridge(y,X,lambda=0,type=type))
   expect_error(fastQR::qrmls(Y,X,type=type))
   expect_error(fastQR::qrmridge(Y,X,lambda=0,type=type))
   expect_error(fastQR::qrsolve(X,y,type=type))
   expect_error(fastQR::qrridge_cv(y,X,lambda=c(0,1),k=2L,type=type))
   expect_error(fastQR::qrmridge_cv(Y,X,lambda=c(0,1),k=2L,type=type))
  }
  expect_error(fastQR::qr_lm(y,X))
  expect_error(fastQR::qr_lse_coef(X,y));expect_error(fastQR::qr_lse_fitted(X,y));expect_error(fastQR::qr_lse_resid(X,y))
  expect_error(fastQR::qrchol(X));expect_error(fastQR::qrchol(X,nb=2L));expect_error(fastQR::rchol(X))
  for(fast in c(FALSE,TRUE)){
   for(type in c('row','column')){
    U<-matrix(1,if(type=='row')p else n,1)
    expect_error(fastQR::qrupdate(a$Q,a$R,k=1L,U=U,type=type,fast=fast))
    expect_error(fastQR::qrdowndate(a$Q,a$R,k=1L,type=type,fast=fast))
    expect_error(fastQR::rupdate(X,a$R,U,fast=fast,type=type))
   }
   expect_error(fastQR::rdowndate(a$R,k=1L,fast=fast))
  }
  stopifnot(identical(snapshot,serialize(X,NULL)))
 }
}
# Reject additions that would cross from a tall to a wide design.
X<-matrix(rnorm(6*3),6,3);a<-fastQR::qr(X,complete=TRUE)
for(fast in c(FALSE,TRUE)){
 expect_error(fastQR::qrupdate(a$Q,a$R,k=1L,U=matrix(1,6,4),type='column',fast=fast))
 expect_error(fastQR::rupdate(X,a$R[1:3,,drop=FALSE],matrix(1,6,4),type='column',fast=fast))
}
# Complete Q products accept length-n responses for tall, square and wide X.
for(d in list(c(9L,4L),c(4L,4L),c(4L,7L))){
 X<-matrix(rnorm(prod(d)),d[1],d[2]);y<-rnorm(d[1]);f<-fastQR::qr_fast(X)
 q<-fastQR::qr_Q_full(f$qr,f$qraux)
 stopifnot(length(fastQR::qr_lse_Qty(X,y))==d[1],length(fastQR::qr_lse_Qy(X,y))==d[1],
   norm(fastQR::qr_lse_Qty(X,y)-drop(crossprod(q,y)),'2')<1e-10,
   norm(fastQR::qr_lse_Qy(X,y)-drop(q%*%y),'2')<1e-10)
 expect_error(fastQR::qr_lse_Qy(X,numeric(d[1]+1L)))
 expect_error(fastQR::qr_lse_Qty(X,numeric(d[1]+1L)))
}
cat(checks,'wide design checks passed, plus complete Q-product identities\n')
# A zero penalty still requires non-wide full-rank training folds.
set.seed(711);X<-matrix(rnorm(12*9),12,9);y<-rnorm(12);Y<-cbind(y,2*y)
expect_error(fastQR::qrridge_cv(y,X,lambda=c(0,1),k=3L))
expect_error(fastQR::qrmridge_cv(Y,X,lambda=c(0,1),k=3L))
for(fun in list(fastQR::qr,fastQR::qr_thin,fastQR::qr_fast))
 expect_error(fun(matrix(numeric(),0,3)))
cat(checks,'total checks including wide training folds and zero-row input\n')
# The ridge R-only augmented blocks stay within their allocated p rows.
set.seed(715);X<-matrix(rnorm(20*4),20,4);y<-rnorm(20);Y<-cbind(y,2*y+rnorm(20));xt<-X[1:2,,drop=FALSE]
for(lambda in c(.1,1))for(prediction in c(FALSE,TRUE)){
 a<-fastQR::qrridge(y,X,lambda,X_test=if(prediction)xt else NULL,type='R')
 b<-fastQR::qrmridge(Y,X,lambda,X_test=if(prediction)xt else NULL,type='R')
 target<-crossprod(X)+nrow(X)*lambda*diag(ncol(X))
 stopifnot(all(is.finite(a$coeff)),all(is.finite(b$coeff)),
    norm(crossprod(a$R)-target,'F')/norm(target,'F')<1e-10,
    norm(crossprod(b$R)-target,'F')/norm(target,'F')<1e-10)
}
