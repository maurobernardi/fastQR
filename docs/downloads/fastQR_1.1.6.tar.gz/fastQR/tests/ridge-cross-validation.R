library(fastQR)
ref<-function(X,Y,lambda){
 Y<-as.matrix(Y);p<-ncol(X)
 unname(base::qr.coef(base::qr(rbind(X,sqrt(nrow(X)*lambda)*diag(p))),rbind(Y,matrix(0,p,ncol(Y)))))
}
close<-function(a,b)stopifnot(length(a)==length(b),max(abs(a-b))<1e-8*max(1,max(abs(b))))
cases<-0L
for(d in list(c(12L,3L),c(17L,4L),c(9L,2L))){
 n<-d[1];p<-d[2];set.seed(970+n);X<-matrix(rnorm(n*p),n,p);X[,1]<-1
 Y<-matrix(rnorm(n*3),n,3);test<-X[1:2,,drop=FALSE];grid<-c(1,.01,0,.4)
 before<-serialize(list(X,Y,grid),NULL)
 for(k in c(3L,0L))for(scalar in c(FALSE,TRUE))for(type in c('QR','R'))for(pred in c(FALSE,TRUE)){
  response<-if(scalar)Y[,1]else Y
  fun<-if(scalar)fastQR::qrridge_cv else fastQR::qrmridge_cv
  a<-suppressWarnings(fun(response,X,grid,k=k,seed=42L,type=type,X_test=if(pred)test else NULL))
  ids<-a$foldid;stopifnot(length(ids)==n,!anyNA(ids),length(unique(ids))==if(k==0)n else k)
  expected<-vapply(grid,function(lam){
   mean(vapply(sort(unique(ids)),function(i){
    train<-which(ids!=i);hold<-which(ids==i)
    yy<-as.matrix(response);coef<-ref(X[train,,drop=FALSE],yy[train,,drop=FALSE],lam)
    mean((yy[hold,,drop=FALSE]-X[hold,,drop=FALSE]%*%coef)^2)
   },0.0))
  },0.0)
  close(a$mse,expected);index<-which.min(expected)
  close(a$lambda_min,grid[index]);stopifnot(a$mse_min_ind==index-1L)
  final<-ref(X,response,grid[index]);close(a$coeff,final);close(a$fitted,X%*%final)
  if(pred)close(a$predicted,test%*%final)
  if(type=='R')stopifnot(!('Q'%in%names(a)))else stopifnot(is.matrix(a[['Q']]))
  if(!scalar){close(a$XTY,crossprod(X,as.matrix(response)));close(a$XTy,a$XTY)}
  stopifnot(!anyDuplicated(names(a)),identical(before,serialize(list(X,Y,grid),NULL)))
  cases<-cases+1L
 }
 # seed argument gives the same folds despite unrelated changes in R's RNG state.
 a<-fastQR::qrridge_cv(Y[,1],X,grid,k=3L,seed=75L,type='QR')
 set.seed(123);runif(10)
 b<-fastQR::qrridge_cv(Y[,1],X,grid,k=3L,seed=75L,type='R')
 stopifnot(identical(a$foldid,b$foldid));close(a$mse,b$mse);close(a$coeff,b$coeff)
}
# Degenerate deletions have a safe recomputation fallback.
for(X in list(matrix(0,12,3),rbind(diag(3),matrix(0,9,3)))){
 Y<-cbind(1:12,12:1)
 a<-fastQR::qrmridge_cv(Y,X,c(.1,1),k=3L,seed=5L)
 close(a$coeff,ref(X,Y,a$lambda_min))
}
expect_error<-function(expr)stopifnot(inherits(tryCatch({force(expr);NULL},error=identity),'error'))
X<-matrix(rnorm(12*3),12,3);y<-rnorm(12)
for(grid in list(numeric(),c(.1,NA),c(.1,-1),Inf))expect_error(fastQR::qrridge_cv(y,X,grid,k=3L))
for(k in c(1L,13L,NA_integer_))expect_error(fastQR::qrridge_cv(y,X,.1,k=k))
expect_error(fastQR::qrridge_cv(y,X,.1,k=3L,seed=NA_integer_))
expect_error(fastQR::qrridge_cv(y,X,.1,k=3L,type='typo'))
cat(cases,'ridge CV curves and final fits match independent foldwise references\n')
# The default fold count adapts to small n; one-response matrix input remains multivariate.
X<-matrix(c(1,2,3,4,5,6),6,1);Y<-matrix(c(3,1,4,1,5,9),6,1)
a<-fastQR::qrmridge_cv(Y,X,c(.1,1),seed=12L,type='R')
stopifnot(length(unique(a$foldid))==6L,identical(dim(a$coeff),c(1L,1L)))
close(a$coeff,ref(X,Y,a$lambda_min))
