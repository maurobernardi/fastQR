library(fastQR)
results<-list()
for(d in list(c(9L,1L),c(12L,3L),c(10L,4L),c(8L,6L))) {
 n<-d[1];p<-d[2];set.seed(500+n);X<-matrix(rnorm(n*p),n,p)
 for(method in c('householder','givens','recursive')){
  f<-if(method=='recursive')fastQR::qr(X,nb=2L,complete=TRUE)else fastQR::qr(X,type=method,complete=TRUE)
  before<-serialize(f,NULL)
  for(m in seq_len(n-p))for(k in seq_len(n-m+1L))for(full in c(FALSE,TRUE))for(fast in c(FALSE,TRUE)){
   a<-fastQR::qrdowndate(f$Q,f$R,k=k,m=m,type='row',complete=full,fast=fast)
   target<-X[-seq.int(k,length.out=m),,drop=FALSE];nr<-n-m;cols<-if(full)nr else p
   rec<-norm(a$Q%*%a$R-target,'F')/max(1,norm(target,'F'))
   ort<-norm(crossprod(a$Q)-diag(cols),'F')/sqrt(cols)
   stopifnot(identical(dim(a$Q),c(nr,cols)),identical(dim(a$R),c(cols,p)),
     rec<1e-10,ort<1e-10,all(a$R[lower.tri(a$R)]==0),identical(before,serialize(f,NULL)))
   results[[length(results)+1L]]<-data.frame(n=n,p=p,m=m,k=k,method=method,complete=full,fast=fast,reconstruction=rec,orthogonality=ort)
  }
 }
 f<-fastQR::qr(X,complete=TRUE)
 for(fast in c(FALSE,TRUE))for(pair in list(c(1L,0L),c(1L,-1L),c(1L,n-p+1L),c(0L,1L),c(n+1L,1L),c(n,2L),c(1L,NA_integer_))){
  err<-tryCatch(fastQR::qrdowndate(f$Q,f$R,k=pair[1],m=pair[2],type='row',fast=fast),error=identity)
  stopifnot(inherits(err,'error'))
 }
 # A square result remains valid for subsequent QR column deletion.
 a<-fastQR::qrdowndate(f$Q,f$R,k=1L,m=n-p,type='row',complete=TRUE)
 target<-X[(n-p+1L):n,,drop=FALSE]
 if(p>1L){
  b<-fastQR::qrdowndate(a$Q,a$R,k=p,type='column',complete=FALSE)
  stopifnot(norm(b$Q%*%b$R-target[,-p,drop=FALSE],'F')<1e-10)
 }
}
# Loss of rank after deletion still has a valid QR representation.
X<-rbind(diag(3),matrix(0,5,3));f<-fastQR::qr(X,complete=TRUE)
a<-fastQR::qrdowndate(f$Q,f$R,k=1L,m=5L,type='row',complete=TRUE)
stopifnot(norm(a$Q%*%a$R-X[6:8,,drop=FALSE],'F')<1e-12,
 norm(crossprod(a$Q)-diag(3),'F')<1e-12)
report<-do.call(rbind,results)
path<-Sys.getenv('FASTQR_ROW_COUNT_REPORT');if(nzchar(path))write.csv(report,path,row.names=FALSE)
cat(nrow(report),'row count cases passed, plus invalid-block, reuse and rank-loss checks\n')
