library(fastQR)
set.seed(981)
rel<-function(a,b)norm(as.matrix(a-b),'F')/max(1,norm(as.matrix(b),'F'))
# Above the BLAS-dispatch threshold; independent augmented-design LS reference.
for(d in list(c(257L,17L),c(400L,40L))){
 n<-d[1];p<-d[2];X<-matrix(rnorm(n*p),n,p);saved<-serialize(X,NULL)
 Y<-matrix(rnorm(n*3),n,3);lambda<-.2
 A<-rbind(X,sqrt(n*lambda)*diag(p));B<-rbind(Y,matrix(0,p,3))
 ref<-base::qr.coef(base::qr(A),B)
 for(type in c('QR','R')){
  f<-fastQR::qrmridge(Y,X,lambda,type=type)
  stopifnot(rel(f$coeff,ref)<1e-11,rel(f$XTX,crossprod(X))<1e-12)
  g<-fastQR::qrridge(Y[,1],X,lambda,type=type)
  stopifnot(rel(g$coeff,ref[,1])<1e-11)
 }
 for(kind in c('thin','recursive','recursive_full')){
  f<-switch(kind,thin=fastQR::qr_thin(X),recursive=fastQR::qr(X,nb=16L),
   recursive_full=fastQR::qr(X,nb=16L,complete=TRUE))
  stopifnot(rel(f$Q%*%f$R,X)<1e-12,
   norm(crossprod(f$Q)-diag(ncol(f$Q)),'F')/sqrt(ncol(f$Q))<1e-12)
 }
 f<-fastQR::qr_fast(X,pivot=FALSE)
 q<-fastQR::qr_Q(f$qr,f$qraux,rank=p,complete=FALSE);r<-fastQR::qr_R(f$qr,rank=p,complete=FALSE)
 stopifnot(rel(q%*%r,X)<1e-12,identical(serialize(X,NULL),saved))
 U<-matrix(rnorm(n*4),n,4);f<-fastQR::qr_lapack(X,'full')
 z<-fastQR::qrupdate(f$Q,f$R,k=p+1L,U=U,type='column',complete=FALSE)
 stopifnot(rel(z$Q%*%z$R,cbind(X,U))<1e-12)
 r<-fastQR::rupdate(X,f$R[seq_len(p),,drop=FALSE],U,type='column')
 stopifnot(rel(crossprod(r),crossprod(cbind(X,U)))<1e-12)
}
cat('Shared BLAS/LAPACK backend: large products, packed reflectors, recursive full Q and ridge references passed.\n')
