library(fastQR)
rows<-list()
check_row<-function(f,X,k,m,complete,fast,label){
 before<-serialize(f,NULL)
 target<-X[-seq.int(k,length.out=m),,drop=FALSE]
 z<-fastQR::qrdowndate(f$Q,f$R,k=k,m=m,type="row",complete=complete,fast=fast)
 n<-nrow(target);p<-ncol(X);q<-if(complete)n else p
 stopifnot(is.list(z),identical(names(z),c("Q","R")),
   is.matrix(z$Q),is.matrix(z$R),typeof(z$Q)=="double",typeof(z$R)=="double",
   identical(dim(z$Q),c(n,q)),identical(dim(z$R),c(q,p)),
   all(is.finite(z$Q)),all(is.finite(z$R)),identical(before,serialize(f,NULL)))
 rec<-norm(z$Q%*%z$R-target,"F")/max(norm(target,"F"),.Machine$double.xmin)
 ort<-norm(crossprod(z$Q)-diag(q),"F")/sqrt(q)
 stopifnot(rec<1e-10,ort<1e-10,all(z$R[lower.tri(z$R)]==0))
 rows[[length(rows)+1L]]<<-data.frame(label=label,n=n,p=p,k=k,m=m,
   complete=complete,fast=fast,reconstruction=rec,orthogonality=ort)
 invisible(z)
}
# Every currently supported row block, including first and final rows.
# The separate m<p restriction is intentionally unchanged in this item.
for(seed in c(13L,37L))for(d in list(c(18L,5L),c(12L,3L),c(9L,4L))){
 set.seed(seed);n<-d[1];p<-d[2];X<-matrix(rnorm(n*p),n,p)
 for(type in c("householder","givens")){
  f<-fastQR::qr(X,type=type,complete=TRUE)
  for(m in seq_len(min(p-1L,n-p-1L)))for(k in seq_len(n-m+1L))
   for(complete in c(FALSE,TRUE))for(fast in c(FALSE,TRUE))
    check_row(f,X,k,m,complete,fast,paste(seed,type,n,p,sep="/"))
 }
}
# Complete recursive factors are valid inputs to both row kernels.
set.seed(79);X<-matrix(rnorm(24*6),24,6)
for(nb in c(1L,2L,4L,12L)){
 f<-fastQR::qr(X,nb=nb,complete=TRUE)
 for(m in c(1L,2L))for(k in c(1L,7L,24L-m+1L))for(complete in c(FALSE,TRUE))
  check_row(f,X,k,m,complete,FALSE,paste("recursive",nb))
}
# Reuse the returned complete basis in later row and column operations.
f<-fastQR::qr(X,complete=TRUE)
for(m in c(1L,2L))for(k in c(1L,7L,24L-m+1L)){
 z<-check_row(f,X,k,m,TRUE,FALSE,"reusable")
 xt<-X[-seq.int(k,length.out=m),,drop=FALSE]
 z<-unserialize(serialize(z,NULL));gc()
 u<-matrix(rnorm(ncol(xt)),ncol(xt),1)
 a<-fastQR::qrupdate(z$Q,z$R,k=nrow(xt)+1L,U=u,type="row",complete=TRUE)
 target<-rbind(xt,t(u))
 stopifnot(norm(a$Q%*%a$R-target,"F")/norm(target,"F")<1e-10,
  norm(crossprod(a$Q)-diag(nrow(target)),"F")/sqrt(nrow(target))<1e-10)
 check_row(z,xt,1L,1L,TRUE,FALSE,"repeated")
 c<-fastQR::qrdowndate(z$Q,z$R,k=2L,m=2L,type="column",complete=TRUE)
 target<-xt[,-(2:3),drop=FALSE]
 stopifnot(norm(c$Q%*%c$R-target,"F")/norm(target,"F")<1e-10,
  norm(crossprod(c$Q)-diag(nrow(xt)),"F")/sqrt(nrow(xt))<1e-10)
}
# Integer complete inputs remain supported without mutation.
f<-list(Q=matrix(as.integer(diag(8)),8,8),R=matrix(0L,8,3))
f$R[1:3,]<-matrix(c(4L,0L,0L,2L,5L,0L,1L,3L,6L),3,3)
X<-f$Q%*%f$R
for(m in c(1L,2L))for(complete in c(FALSE,TRUE))
 check_row(f,X,5L,m,complete,FALSE,"integer")
report<-do.call(rbind,rows)
path<-Sys.getenv("FASTQR_ROW_R_REPORT",unset="")
if(nzchar(path))write.csv(report,path,row.names=FALSE)
cat(nrow(report),"row-deletion cases plus complete-basis ownership/reuse checks passed.\n")
