library(fastQR)
rows<-list()
check_full<-function(X,nb,label){
 snap<-serialize(X,NULL)
 f<-fastQR::qr(X,nb=nb,complete=TRUE)
 n<-nrow(X);p<-ncol(X)
 stopifnot(is.list(f),identical(names(f),c("Q","R")),
   is.matrix(f$Q),is.matrix(f$R),typeof(f$Q)=="double",typeof(f$R)=="double",
   identical(dim(f$Q),c(n,n)),identical(dim(f$R),c(n,p)),
   all(is.finite(f$Q)),all(is.finite(f$R)),identical(snap,serialize(X,NULL)))
 rec<-norm(f$Q%*%f$R-X,"F")/max(norm(X,"F"),.Machine$double.xmin)
 ort<-norm(crossprod(f$Q)-diag(n),"F")/sqrt(max(1L,n))
 ort2<-norm(tcrossprod(f$Q)-diag(n),"F")/sqrt(max(1L,n))
 low<-norm(f$R*lower.tri(f$R),"F")
 stopifnot(rec<1e-10,ort<1e-10,ort2<1e-10,low==0)
 if(n>p)stopifnot(all(f$R[(p+1L):n,,drop=FALSE]==0))
 rows[[length(rows)+1L]]<<-data.frame(label=label,n=n,p=p,nb=nb,
    reconstruction=rec,orthogonality=ort)
 invisible(f)
}
# Tall and square, one column, odd/even splits, nb below/equal/above p.
for(seed in c(5L,19L,73L))for(d in list(c(2L,1L),c(20L,1L),c(20L,6L),c(23L,7L),c(8L,8L),c(60L,19L))){
 set.seed(seed);X<-matrix(rnorm(prod(d)),d[1],d[2])
 for(nb in unique(c(1L,2L,3L,4L,d[2],d[2]+1L)))
   check_full(X,nb,paste("random",seed,paste(d,collapse="x"),sep="/"))
}
# Prescribed singular-value condition numbers; reconstruction and Q
# orthogonality should not be confused with coefficient forward sensitivity.
for(cond in c(1,1e2,1e4,1e6,1e8,1e12)){
 set.seed(91);n<-40L;p<-6L
 U<-base::qr.Q(base::qr(matrix(rnorm(n*p),n,p),LAPACK=TRUE))
 V<-base::qr.Q(base::qr(matrix(rnorm(p*p),p,p),LAPACK=TRUE))
 X<-sweep(U,2,exp(seq(0,-log(cond),length.out=p)),"*")%*%t(V)
 for(nb in c(1L,2L,3L,4L,6L,12L))check_full(X,nb,paste("condition",cond))
}
# Zero panels, dependent columns and exact coordinate matrices.
matrices<-list(zero=matrix(0,12,6),coordinate=diag(12)[,c(4,6,8,9,10,12)],
 diagonal=rbind(diag(c(1,2,0,4,0,6)),matrix(0,6,6)))
set.seed(103);a<-matrix(rnorm(12*3),12,3)
matrices$dependent<-cbind(a,a[,2],a[,1]+a[,3],0)
for(name in names(matrices))for(nb in c(1L,2L,3L,4L,12L))
 check_full(matrices[[name]],nb,name)
# The empty-column problem is represented by I_n and an n x 0 R.
for(n in c(0L,1L,8L))check_full(matrix(numeric(),n,0),2L,"empty_columns")
# Concrete R ownership and downstream full-factor updates and downdates.
set.seed(117);X<-matrix(rnorm(40*7),40,7)
for(nb in c(1L,2L,4L,12L)){
 f<-check_full(X,nb,"reusable_initial")
 f<-unserialize(serialize(f,NULL));gc()
 U<-matrix(rnorm(7*2),7,2)
 a<-fastQR::qrupdate(f$Q,f$R,k=41L,U=U,type="row",complete=TRUE)
 target<-rbind(X,t(U))
 stopifnot(norm(a$Q%*%a$R-target,"F")/norm(target,"F")<1e-10,
 norm(crossprod(a$Q)-diag(42),"F")/sqrt(42)<1e-10)
 d<-fastQR::qrdowndate(f$Q,f$R,k=3L,m=2L,type="row",complete=TRUE)
 target<-X[-(3:4),,drop=FALSE]
 stopifnot(norm(d$Q%*%d$R-target,"F")/norm(target,"F")<1e-10,
 norm(crossprod(d$Q)-diag(38),"F")/sqrt(38)<1e-10)
 U<-matrix(rnorm(40*2),40,2)
 a<-fastQR::qrupdate(f$Q,f$R,k=8L,U=U,type="column",complete=TRUE)
 target<-cbind(X,U)
 stopifnot(norm(a$Q%*%a$R-target,"F")/norm(target,"F")<1e-10,
 norm(crossprod(a$Q)-diag(40),"F")/sqrt(40)<1e-10)
 for(k in c(1L,3L,6L)){
  d<-fastQR::qrdowndate(f$Q,f$R,k=k,m=2L,type="column",complete=TRUE)
  target<-X[,-seq.int(k,length.out=2),drop=FALSE]
  stopifnot(norm(d$Q%*%d$R-target,"F")/norm(target,"F")<1e-10,
   norm(crossprod(d$Q)-diag(40),"F")/sqrt(40)<1e-10)
 }
}
# Existing wide-input fallback is preserved rather than relabelled recursive QR.
set.seed(125);X<-matrix(rnorm(6*9),6,9);warnings<-character()
f<-withCallingHandlers(fastQR::qr(X,nb=2L,complete=TRUE),warning=function(w){
 warnings<<-c(warnings,conditionMessage(w));invokeRestart("muffleWarning")})
stopifnot(length(warnings)>=1L,identical(dim(f$Q),c(6L,6L)),
 identical(dim(f$R),c(6L,9L)),norm(f$Q%*%f$R-X,"F")/norm(X,"F")<1e-10)
# Invalid complete-recursion parameters and nonfinite data fail clearly.
expect_error<-function(expr,pattern){
 msg<-tryCatch({force(expr);NULL},error=function(e)conditionMessage(e))
 stopifnot(!is.null(msg),grepl(pattern,msg,fixed=TRUE))
}
expect_error(fastQR::qr(matrix(1,4,2),nb=-1L,complete=TRUE),"nb must be positive")
for(value in c(NA_real_,NaN,Inf,-Inf)){
 X<-diag(4)[,1:2];X[1,1]<-value
 expect_error(fastQR::qr(X,nb=2L,complete=TRUE),"finite")
}
report<-do.call(rbind,rows)
path<-Sys.getenv("FASTQR_RECURSIVE_REPORT",unset="")
if(nzchar(path))write.csv(report,path,row.names=FALSE)
cat(nrow(report),"recursive complete-factor cases plus reuse, fallback and invalid-input checks passed.\n")
