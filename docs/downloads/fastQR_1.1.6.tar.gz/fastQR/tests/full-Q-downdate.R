library(fastQR)
relative <- function(a,b) norm(as.matrix(a-b),"F")/max(norm(as.matrix(b),"F"),.Machine$double.xmin)
metrics <- list()
check_factors <- function(f,X,complete,label){
 n<-nrow(X);p<-ncol(X);q<-if(complete)n else p
 stopifnot(is.list(f),identical(names(f),c("Q","R")),
   is.matrix(f$Q),is.matrix(f$R),typeof(f$Q)=="double",typeof(f$R)=="double",
   identical(dim(f$Q),c(n,q)),identical(dim(f$R),c(q,p)),
   all(is.finite(f$Q)),all(is.finite(f$R)))
 rec<-relative(f$Q%*%f$R,X)
 ort<-norm(crossprod(f$Q)-diag(q),"F")/sqrt(q)
 lower<-norm(f$R*lower.tri(f$R),"F")
 stopifnot(rec<1e-10,ort<1e-10,lower<1e-10)
 if(complete)stopifnot(norm(tcrossprod(f$Q)-diag(n),"F")/sqrt(n)<1e-10)
 metrics[[length(metrics)+1L]]<<-data.frame(label=label,complete=complete,reconstruction=rec,orthogonality=ort)
 invisible(f)
}
# Every admissible consecutive block, including the last one and p-1 columns.
for(seed in c(13L,29L)){
 set.seed(seed);n<-24L;p<-6L;X<-matrix(rnorm(n*p),n,p)
 for(initial_type in c("householder","givens")){
  f<-fastQR::qr(X,type=initial_type,complete=TRUE)
  input_snapshot<-serialize(f,NULL)
  for(m in seq_len(p-1L))for(k in seq_len(p-m+1L)){
   target<-X[,-seq.int(k,length.out=m),drop=FALSE]
   for(fast in c(FALSE,TRUE))for(complete in c(FALSE,TRUE)){
    d<-fastQR::qrdowndate(f$Q,f$R,k=k,m=m,type="column",fast=fast,complete=complete)
    check_factors(d,target,complete,paste(seed,initial_type,k,m,fast,sep="/"))
    stopifnot(identical(serialize(f,NULL),input_snapshot))
   }
  }
 }
}
# Reuse complete output after first, interior and terminal deletions.
set.seed(51);n<-40L;p<-8L;X<-matrix(rnorm(n*p),n,p)
f<-fastQR::qr(X,complete=TRUE)
for(m in c(1L,3L))for(k in c(1L,3L,p-m+1L)){
 xt<-X[,-seq.int(k,length.out=m),drop=FALSE]
 d<-fastQR::qrdowndate(f$Q,f$R,k=k,m=m,type="column",complete=TRUE,fast=FALSE)
 for(size in c(1L,2L)){
  u<-matrix(rnorm(ncol(xt)*size),ncol(xt),size)
  add<-fastQR::qrupdate(d$Q,d$R,k=nrow(xt)+1L,U=u,type="row",complete=TRUE,fast=FALSE)
  check_factors(add,rbind(xt,t(u)),TRUE,"reuse/add_rows")
  del<-fastQR::qrdowndate(d$Q,d$R,k=2L,m=size,type="row",complete=TRUE,fast=FALSE)
  check_factors(del,xt[-seq.int(2L,length.out=size),,drop=FALSE],TRUE,"reuse/delete_rows")
  u<-matrix(rnorm(nrow(xt)*size),nrow(xt),size)
  add<-fastQR::qrupdate(d$Q,d$R,k=ncol(xt)+1L,U=u,type="column",complete=TRUE,fast=FALSE)
  check_factors(add,cbind(xt,u),TRUE,"reuse/add_columns")
 }
 # Consecutive complete column downdates must remain reusable.
 again<-fastQR::qrdowndate(d$Q,d$R,k=ncol(xt),m=1L,type="column",complete=TRUE,fast=FALSE)
 check_factors(again,xt[,-ncol(xt),drop=FALSE],TRUE,"reuse/delete_last_column")
}
# A serialized round trip checks the concrete R matrices, not Eigen views.
z<-fastQR::qrdowndate(f$Q,f$R,k=3L,m=3L,type="column",complete=TRUE)
z<-unserialize(serialize(z,NULL));gc()
check_factors(z,X[,-(3:5),drop=FALSE],TRUE,"R/serialization_roundtrip")
report<-do.call(rbind,metrics)
out<-Sys.getenv("FASTQR_TEST_REPORT",unset="")
if(nzchar(out))write.csv(report,out,row.names=FALSE)
cat(nrow(report),"factorization/output/reuse checks passed.\n")
