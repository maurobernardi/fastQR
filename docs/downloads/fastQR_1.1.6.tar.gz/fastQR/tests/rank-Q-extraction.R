library(fastQR)
records<-list()
# Independent explicit product of the stored Householder transformations.
reference_Q<-function(qr,tau){
 n<-nrow(qr);count<-min(n,ncol(qr));out<-diag(n)
 for(j in seq_len(count)){
  v<-numeric(n);v[j]<-1
  if(j<n)v[(j+1L):n]<-qr[(j+1L):n,j]
  out<-out-(tau[j]*(out%*%v))%*%t(v)
 }
 out
}
for(seed in c(17L,47L))for(d in list(c(14L,6L),c(6L,6L),c(9L,4L),c(7L,1L))){
 n<-d[1];p<-d[2]
 for(rank in 0:p){
  set.seed(seed+rank)
  if(rank==0L)X<-matrix(0,n,p)else{
   U<-base::qr.Q(base::qr(matrix(rnorm(n*rank),n,rank),LAPACK=TRUE))
   V<-base::qr.Q(base::qr(matrix(rnorm(p*rank),p,rank),LAPACK=TRUE))
   X<-sweep(U,2,seq(1,.5,length.out=rank),"*")%*%t(V)
  }
  f<-fastQR::qr_fast(X,pivot=TRUE,tol=1e-10)
  stopifnot(f$rank==rank)
  reference<-reference_Q(f$qr,f$qraux)
  snapshot<-serialize(f,NULL)
  for(full in c(FALSE,TRUE)){
   q<-suppressWarnings(fastQR::qr_Q(f$qr,f$qraux,rank=rank,complete=full))
   columns<-if(full && rank==p)n else rank
   expected<-reference[,seq_len(columns),drop=FALSE]
   stopifnot(is.matrix(q),typeof(q)=="double",identical(dim(q),c(n,columns)),
     all(is.finite(q)),identical(snapshot,serialize(f,NULL)))
   err<-norm(q-expected,"F")/sqrt(max(1L,columns))
   ort<-norm(crossprod(q)-diag(columns),"F")/sqrt(max(1L,columns))
   stopifnot(err<1e-11,ort<1e-11)
   # Isolate Q extraction from qr_R(), whose rank-policy is a later item.
   r<-f$qr[seq_len(rank),,drop=FALSE];r[lower.tri(r)]<-0
   if(full && rank==p)r<-rbind(r,matrix(0,n-rank,p))
   xp<-X[,f$pivot,drop=FALSE]
   rec<-norm(q%*%r-xp,"F")/max(norm(xp,"F"),.Machine$double.xmin)
   stopifnot(rec<1e-10)
   records[[length(records)+1L]]<-data.frame(n=n,p=p,rank=rank,complete=full,
     reference_error=err,orthogonality=ort,reconstruction=rec)
   z<-unserialize(serialize(q,NULL));stopifnot(identical(z,q))
  }
 }
}
# Full-rank extraction without pivoting remains the same transformation.
set.seed(71);X<-matrix(rnorm(20*6),20,6);f<-fastQR::qr_fast(X,pivot=FALSE)
ref<-reference_Q(f$qr,f$qraux)
for(full in c(FALSE,TRUE)){
 q<-fastQR::qr_Q(f$qr,f$qraux,rank=6L,complete=full)
 stopifnot(norm(q-ref[,seq_len(if(full)20L else 6L),drop=FALSE],"F")<1e-11)
}
# Reduced extraction needs only its r coefficients; full extraction needs all.
q<-fastQR::qr_Q(f$qr,f$qraux[1:3],rank=3L,complete=FALSE)
stopifnot(norm(q-ref[,1:3],"F")<1e-11)
expect_error<-function(expr){
 msg<-suppressWarnings(tryCatch({force(expr);NULL},error=function(e)conditionMessage(e)))
 stopifnot(!is.null(msg))
}
stopifnot(identical(suppressWarnings(fastQR::qr_Q(f$qr,f$qraux[1:3],rank=3L,complete=TRUE)), q))
for(rank in c(-1L,NA_integer_,7L))
 expect_error(fastQR::qr_Q(f$qr,f$qraux,rank=rank,complete=FALSE))
expect_error(fastQR::qr_Q(f$qr,f$qraux[1:2],rank=3L,complete=FALSE))
expect_error(fastQR::qr_Q(matrix(0,2,4),numeric(4),rank=3L,complete=TRUE))
# The zero-rank reduced basis has zero columns; no reflector is accessed.
q<-suppressWarnings(fastQR::qr_Q(f$qr,numeric(),rank=0L,complete=FALSE))
stopifnot(identical(dim(q),c(20L,0L)))
q<-fastQR::qr_Q(matrix(numeric(),5,0),numeric(),rank=0L,complete=TRUE)
stopifnot(identical(q,diag(5)))
# Missing-rank/complete behavior is deliberately not changed in this item.
expect_error(fastQR::qr_Q(f$qr,f$qraux,complete=FALSE))
report<-do.call(rbind,records)
path<-Sys.getenv("FASTQR_RANK_Q_REPORT",unset="")
if(nzchar(path))write.csv(report,path,row.names=FALSE)
cat(nrow(report),"rank-sensitive Q extractions plus coefficient/ownership/bounds checks passed.\n")
