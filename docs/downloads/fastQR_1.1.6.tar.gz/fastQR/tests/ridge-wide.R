library(fastQR)
set.seed(188)
rel<-function(a,b)norm(as.matrix(a-b),'F')/max(1,norm(as.matrix(b),'F'))
for(d in list(c(1L,4L),c(8L,15L),c(20L,30L))){
 n<-d[1];p<-d[2];X<-matrix(rnorm(n*p),n,p);X[,p]<-X[,1]
 Y<-matrix(rnorm(n*2),n,2);xt<-matrix(rnorm(3*p),3,p)
 for(lambda in c(.01,.3,2)){
  A<-rbind(X,sqrt(n*lambda)*diag(p));B<-rbind(Y,matrix(0,p,2))
  ref<-base::qr.coef(base::qr(A),B)
  for(type in c('QR','R')){
   f<-qrridge(Y[,1],X,lambda,X_test=xt,type=type)
   g<-qrmridge(Y,X,lambda,X_test=xt,type=type)
   stopifnot(rel(f$coeff,ref[,1])<1e-10,rel(g$coeff,ref)<1e-10,
    rel(f$predicted,xt%*%ref[,1])<1e-10,rel(g$predicted,xt%*%ref)<1e-10,
    is.na(f$df),is.na(g$df),is.na(f$sigma2_hat),all(is.na(g$Sigma_hat)))
  }
 }
}
# CV must use each training sample's own nt*lambda penalty.
n<-15L;p<-25L;X<-matrix(rnorm(n*p),n,p);Y<-matrix(rnorm(n*2),n,2)
grid<-c(.1,.5)
for(type in c('QR','R')){
 a<-qrridge_cv(Y[,1],X,lambda=grid,k=3L,seed=91L,type=type)
 b<-qrmridge_cv(Y,X,lambda=grid,k=3L,seed=91L,type=type)
 ids<-a$foldid
 calc<-function(j,multi){
  vals<-sapply(sort(unique(ids)),function(f){
   tr<-which(ids!=f);te<-which(ids==f);nt<-length(tr)
   A<-rbind(X[tr,,drop=FALSE],sqrt(nt*grid[j])*diag(p))
   yy<-if(multi)Y else Y[,1,drop=FALSE]
   coef<-base::qr.coef(base::qr(A),rbind(yy[tr,,drop=FALSE],matrix(0,p,ncol(yy))))
   mean((yy[te,,drop=FALSE]-X[te,,drop=FALSE]%*%coef)^2)
  });mean(vals)
 }
 stopifnot(max(abs(a$mse-sapply(seq_along(grid),calc,multi=FALSE)))<1e-10,
 max(abs(b$mse-sapply(seq_along(grid),calc,multi=TRUE)))<1e-10)
}
cat('Wide ridge fits, predictions, diagnostics and foldwise CV references passed.\n')
