\name{qr_lapack}
\alias{qr_lapack}
\title{Unpivoted QR decomposition using R's LAPACK libraries}
\usage{qr_lapack(X, output = c("thin", "full", "R", "compact"))}
\arguments{
\item{X}{A nonempty finite real numeric matrix, including tall, square or wide inputs.}
\item{output}{The requested factor representation.}}
\description{Calls DGEQRF explicitly and DORGQR when an explicit orthogonal factor is requested.}
\value{For \code{"thin"}, a list with Q of size n by min(n,p) and R of size min(n,p) by p. For \code{"full"}, Q is n by n and R is n by p. For \code{"R"}, R alone is returned with min(n,p) rows. For \code{"compact"}, a list with the packed DGEQRF matrix \code{qr} and Householder coefficients \code{tau}; this is not a base R \code{qr} object or a \code{qr_fast} object.}
\details{No pivoting or numerical rank estimation is performed. Rank-deficient inputs retain the same output dimensions. Factor signs are not standardized. The input is not modified. Uses the LAPACK and BLAS libraries selected by R; LAPACKE is not required.}
\examples{
set.seed(1)
X <- matrix(rnorm(40), 10, 4)
f <- qr_lapack(X)
max(abs(f$Q \%*\% f$R - X))
qr_lapack(X, output = "R")
}
