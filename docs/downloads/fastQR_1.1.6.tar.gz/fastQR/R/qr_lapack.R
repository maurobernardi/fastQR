#' Unpivoted QR decomposition using R's LAPACK libraries
#'
#' Calls DGEQRF explicitly, followed by DORGQR only when an explicit
#' orthogonal factor is requested. No numerical rank is estimated.
#' @param X A nonempty finite real numeric matrix; tall, square and wide
#'   matrices are supported.
#' @param output Representation to return: "thin", "full", "R", or "compact".
#' @return For "thin", a list with Q of size n by min(n,p) and R of size
#'   min(n,p) by p. For "full", Q is n by n and R is n by p.
#'   For "R", the triangular or trapezoidal matrix R alone is returned.
#'   For "compact", a list containing the DGEQRF packed matrix qr and
#'   Householder coefficients tau is returned. This compact list is not
#'   a base R qr object or a fastQR::qr_fast object.
#' @details Factor signs are not standardized. Rank-deficient inputs retain
#'   the same output dimensions. The input is not modified. The backend uses
#'   LAPACK and BLAS selected by R, without requiring the LAPACKE C interface.
#' @examples
#' set.seed(1)
#' X <- matrix(rnorm(40), 10, 4)
#' f <- qr_lapack(X)
#' max(abs(f$Q %*% f$R - X))
#' qr_lapack(X, output = "R")
#' @export
qr_lapack <- function(X, output = c("thin", "full", "R", "compact")) {
    output <- match.arg(output)
    if (!is.matrix(X) || !is.numeric(X) || is.complex(X))
        stop("X must be a real numeric matrix.")
    storage.mode(X) <- "double"
    ans <- qr_lapack_impl(X, output)
    if (output == "R") ans$R else ans
}
