#ifndef FASTQR_NUMERIC_BACKEND_H
#define FASTQR_NUMERIC_BACKEND_H
#include <RcppEigen.h>
namespace fastqr_backend {
using ConstMatrix = Eigen::Ref<const Eigen::MatrixXd>;
using ConstVector = Eigen::Ref<const Eigen::VectorXd>;
Eigen::MatrixXd product(ConstMatrix a, ConstMatrix b, bool ta=false, bool tb=false);
Eigen::VectorXd matvec(ConstMatrix a, ConstVector b, bool transpose=false);
struct PackedQR { Eigen::MatrixXd qr; Eigen::VectorXd tau; };
PackedQR factor(ConstMatrix x);
Eigen::MatrixXd form_q(const PackedQR& f, int columns);
Eigen::MatrixXd apply_q(const PackedQR& f, ConstMatrix b, bool transpose, bool right=false);
Rcpp::List thin_qr(ConstMatrix x);
}
#endif
