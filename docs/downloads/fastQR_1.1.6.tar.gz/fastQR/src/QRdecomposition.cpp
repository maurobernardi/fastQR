// :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: //
// ::::::::::::::::::::                        :::::::::::::::::::: //
// ::::::::::::::::::::    QR decomposition    :::::::::::::::::::: //
// ::::::::::::::::::::                        :::::::::::::::::::: //
// :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: //

// Utility routines

// Authors:
//           Bernardi Mauro, University of Padova
//           Last update: october 7, 2024

// [[Rcpp::depends(RcppArmadillo)]]
#include "QRdecomposition.h"
#include <time.h>
#include <vector>
#include "numeric_backend.h"

// Reduced factors are formed by replaying the original transformations on
// the first p identity columns, without allocating an n by n matrix.
static Rcpp::List householderQR_red(const Eigen::MatrixXd& X) {
  const int n = X.rows(), p = X.cols();
  Eigen::MatrixXd R = X;
  Eigen::MatrixXd vectors = Eigen::MatrixXd::Zero(n, p);
  Eigen::VectorXd coefficients(p);
  for (int i = 0; i < p; ++i) {
    Eigen::VectorXd tmp = householder(R.block(i, i, n-i, 1));
    Eigen::VectorXd v = tmp.head(n-i);
    const double beta = tmp(n-i);
    vectors.col(i).tail(n-i) = v;
    coefficients(i) = beta;
    R(i, i) = tmp(n-i+1);
    R.block(i+1, i, n-i-1, 1).setZero();
    if (i < p-1)
      R.block(i, i+1, n-i, p-i-1) -=
        (beta * v) * (v.transpose() * R.block(i, i+1, n-i, p-i-1));
  }
  Eigen::MatrixXd Q = Eigen::MatrixXd::Identity(n, p);
  for (int i = p-1; i >= 0; --i) {
    const Eigen::VectorXd v = vectors.col(i).tail(n-i);
    Q.bottomRows(n-i) -=
      (coefficients(i) * v) * (v.transpose() * Q.bottomRows(n-i));
  }
  return Rcpp::List::create(Rcpp::Named("Q") = Q,
                            Rcpp::Named("R") = R.topRows(p));
}

static Rcpp::List givensQR_red(const Eigen::MatrixXd& X) {
  const int n = X.rows(), p = X.cols();
  struct Rotation { int row; double c, s; };
  std::vector<Rotation> rotations;
  rotations.reserve(static_cast<std::size_t>(p) * (2*n-p-1) / 2);
  Eigen::MatrixXd R = X;
  for (int j = 0; j < p; ++j) {
    for (int i = n-1; i > j; --i) {
      const Eigen::Vector2d tmp = givens(R(i-1, j), R(i, j));
      Eigen::Matrix2d G;
      G << tmp(0), tmp(1), -tmp(1), tmp(0);
      R.block(i-1, j, 2, p-j) = G.transpose() * R.block(i-1, j, 2, p-j);
      rotations.push_back(Rotation{i-1, tmp(0), tmp(1)});
    }
  }
  Eigen::MatrixXd Q = Eigen::MatrixXd::Identity(n, p);
  for (auto it = rotations.rbegin(); it != rotations.rend(); ++it) {
    Eigen::Matrix2d G;
    G << it->c, it->s, -it->s, it->c;
    Q.middleRows(it->row, 2) = G * Q.middleRows(it->row, 2);
  }
  R.triangularView<Eigen::StrictlyLower>().setZero();
  return Rcpp::List::create(Rcpp::Named("Q") = Q,
                            Rcpp::Named("R") = R.topRows(p));
}


// ::::::::::::::::::::::::::::::::::::::::::::::::::
// QR: householder reflections
// function to compute QR factorization of X with Householder rotations
// X matrix m x n to be factorized
Rcpp::List householderQR (const Eigen::MatrixXd& X,
                          int complete) {
  if (!complete && X.rows() > X.cols()) return householderQR_red(X);
  
  int i, n = X.rows(), p = X.cols();
  double beta = 0.0, mu = 0.0;
  Eigen::MatrixXd R = X;
  Eigen::MatrixXd Q(n, n); Q.setIdentity();
  
  if (n > p) {
    Eigen::VectorXd v(n-1); v.setZero();
    VectorXd tmp(n+2); tmp.setZero();
    
    for (i = 0; i < p; i++) {
      // Householder rotation
      tmp.resize(n-i+2);
      tmp  = householder(R.block(i, i, n-i, 1));
      v    = tmp.head(n-i);
      beta = tmp(n-i);
      mu   = tmp(n-i+1);
      
      // update R
      R(i, i) = mu;
      R.block(i+1, i, n-i-1, 1).setZero();
      if (i < p-1)
        R.block(i, i+1, n-i, p-i-1) -= (beta * v) * (v.transpose() * R.block(i, i+1, n-i, p-i-1));
      
      // update Q
      Q.block(0, i, Q.rows(), n-i) -= beta * (Q.block(0, i, Q.rows(), n-i) * v) * v.transpose();
    }
    
    if (complete == 0) {
      Eigen::MatrixXd Q1(n, R.cols()); Q1.setZero();
      Q1 = Q.leftCols(R.cols());
      /* Return output      */
      return Rcpp::List::create(Rcpp::Named("Q") = Q1,
                                Rcpp::Named("R") = R.topRows(R.cols()));
    } else {
      return Rcpp::List::create(Rcpp::Named("Q") = Q,
                                Rcpp::Named("R") = R);
    }
  } else {
    Eigen::VectorXd v(n-1); v.setZero();
    VectorXd tmp(n+2); tmp.setZero();
    
    for (i = 0; i < n-1; i++) {
      // Householder rotation
      tmp.resize(n-i+2);
      tmp = householder(R.block(i, i, n-i, 1));
      v = tmp.head(n-i);
      beta = tmp(n-i);
      mu = tmp(n-i+1);
      
      // update R
      R(i, i) = mu;
      R.block(i+1, i, n-i-1, 1).setZero();
      if (i < n-1)
        R.block(i, i+1, n-i, p-i-1) -= (beta * v) * (v.transpose() * R.block(i, i+1, n-i, p-i-1));
      
      // update Q
      Q.block(0, i, Q.rows(), n-i) -= beta * (Q.block(0, i, Q.rows(), n-i) * v) * v.transpose();
    }
    return Rcpp::List::create(Rcpp::Named("Q") = Q,
                              Rcpp::Named("R") = R);
  }
}

// ::::::::::::::::::::::::::::::::::::::::::::::::::
// QR: givens rotations
// function to compute QR decomposition with givens rotations
// X matrix m x n to be factorized
Rcpp::List givensQR (const Eigen::MatrixXd& X,
                     int complete) {
  if (!complete && X.rows() > X.cols()) return givensQR_red(X);
  // function to compute QR decomposition with givens rotations
  // X matrix m x n to be factorized
  
  int i, j, n = X.rows(), p = X.cols();
  double cc = 0.0, ss = 0.0;
  Eigen::MatrixXd R = X;
  Eigen::MatrixXd Q(n, n); Q.setIdentity();
  Eigen::MatrixXd Givens(2, 2); Givens.setZero();
  Eigen::Vector2d tmp; tmp.setZero();
  
  if (n > p) {
    for (j = 0; j < p; j++) {
      for (i = n-1; i > j; i--) {
        
        // Givens rotation
        tmp = givens(R(i-1, j), R(i, j));
        cc  = tmp(0);
        ss  = tmp(1);
        Givens << cc, ss, -ss, cc;
        
        // update A and Q
        R.block(i-1, j, 2, p-1-j+1)  = Givens.transpose() * R.block(i-1, j, 2, p-1-j+1);
        Q.block(0, i-1, Q.rows(), 2) = Q.block(0, i-1, Q.rows(), 2) * Givens;
      }
    }
    
    // output
    R.triangularView<Eigen::StrictlyLower>().setZero();
    
    if (complete == 0) {
      Eigen::MatrixXd Q1(n, R.cols()); Q1.setZero();
      Q1 = Q.leftCols(R.cols());
      /* Return output      */
      return Rcpp::List::create(Rcpp::Named("Q") = Q1,
                                Rcpp::Named("R") = R.topRows(R.cols()));
    } else {
      return Rcpp::List::create(Rcpp::Named("Q") = Q,
                                Rcpp::Named("R") = R);
    }
  } else {
    for (j = 0; j < n-1; j++) {
      for (i = n-1; i > j; i--) {
        
        // Givens rotation
        tmp = givens(R(i-1, j), R(i, j));
        cc = tmp(0);
        ss = tmp(1);
        Givens << cc, ss, -ss, cc;
        
        // update A and Q
        R.block(i-1, j, 2, p-1-j+1) = Givens.transpose() * R.block(i-1, j, 2, p-1-j+1);
        Q.block(0, i-1, Q.rows(), 2) = Q.block(0, i-1, Q.rows(), 2) * Givens;
      }
    }
    
    // output
    R.triangularView<Eigen::StrictlyLower>().setZero();
    return Rcpp::List::create(Rcpp::Named("Q") = Q,
                              Rcpp::Named("R") = R);
  }
}

// ::::::::::::::::::::::::::::::::::::::::::::::::::
// QR: recursive block 
// function to compute thin QR decomposition with block recursion
// X matrix m x n to be factorized
// nb number of blocks
// Complete-output recursion. All panels act on the trailing design and
// accumulate their Householder transformations into one full Q. No dense
// product between two complete orthogonal matrices is required.
static void rbQR_complete_step(Eigen::MatrixXd& Q,
                               Eigen::MatrixXd& R,
                               const Eigen::Index offset,
                               const Eigen::Index width,
                               const int nb) {
  if (width == 0) return;
  if (width > 1 && width >= nb) {
    const Eigen::Index left_width = width / 2;
    rbQR_complete_step(Q, R, offset, left_width, nb);
    rbQR_complete_step(Q, R, offset + left_width,
                       width - left_width, nb);
    return;
  }

  const Eigen::Index rows = R.rows() - offset;
  const Eigen::Index trailing_cols = R.cols() - offset - width;
  const Eigen::MatrixXd panel = R.block(offset, offset, rows, width);
  const fastqr_backend::PackedQR factor = fastqr_backend::factor(panel);

  // The left block has been factorized: transform every remaining column
  // before recursively factorizing its residual (lower) block.
  if (trailing_cols > 0) {
    const Eigen::MatrixXd trailing =
      R.block(offset, offset + width, rows, trailing_cols);
    R.block(offset, offset + width, rows, trailing_cols) =
      fastqr_backend::apply_q(factor, trailing, true);
  }
  const Eigen::MatrixXd upper_panel =
    factor.qr.template triangularView<Eigen::Upper>();
  R.block(offset, offset, rows, width) = upper_panel;

  // Accumulate on the right, including the orthogonal complement.
  // The temporary avoids aliasing the input and output block.
  const Eigen::MatrixXd basis = Q.rightCols(rows);
  Q.rightCols(rows) = fastqr_backend::apply_q(factor, basis, false, true);
}

static Rcpp::List rbQR_complete(const Eigen::MatrixXd& X,
                               const int nb) {
  if (nb < 1) {
    Rcpp::stop("* fastQR: nb must be positive for recursive complete QR.");
  }
  if (X.rows() < X.cols()) {
    Rcpp::stop("* fastQR: recursive complete QR requires nrow(X) >= ncol(X).");
  }
  if (!X.allFinite()) {
    Rcpp::stop("* fastQR: X must contain only finite values.");
  }
  Eigen::MatrixXd Q = Eigen::MatrixXd::Identity(X.rows(), X.rows());
  Eigen::MatrixXd R = X;
  rbQR_complete_step(Q, R, 0, X.cols(), nb);
  R.triangularView<Eigen::StrictlyLower>().setZero();
  return Rcpp::List::create(Rcpp::Named("Q") = Q,
                            Rcpp::Named("R") = R);
}

Rcpp::List rbQR (const Eigen::MatrixXd& X,
                 const int& nb,
                 const int& complete) {
  // Keep the established reduced-output algorithm unchanged.
  if (complete) {
    return rbQR_complete(X, nb);
  }
  // With nb < 2, a one-column panel never reaches the reduced leaf.
  if (nb < 2) {
    Rcpp::stop("* fastQR: recursive reduced QR requires nb >= 2.");
  }

  Eigen::MatrixXd As = X;
  const int m  = As.rows(), n = As.cols();
  const int n1 = std::floor(n / 2);
  Eigen::MatrixXd Q(m, n);              Q.setZero();
  Eigen::MatrixXd R(n, n);              R.setZero();
  Eigen::MatrixXd thinQ(m, n);          thinQ.setZero();
  Eigen::MatrixXd Q1(m, n1);            Q1.setZero();
  Eigen::MatrixXd Q2(m, n1);            Q2.setZero();
  Eigen::MatrixXd R11(n1, n1);          R11.setZero();
  Eigen::MatrixXd R12(n1, n-n1);        R12.setZero();
  Eigen::MatrixXd R22(n-n1, n-n1);      R22.setZero();
  
  if (n < nb) {
    const fastqr_backend::PackedQR qr = fastqr_backend::factor(As);
    Q = fastqr_backend::form_q(qr, n);
    R = qr.qr.template triangularView<Eigen::Upper>();
    
    /* Return output      */
    if (complete == 0) {
      Eigen::MatrixXd Q1(n, R.cols()); Q1.setZero();
      Q1 = Q.leftCols(R.cols());
      return Rcpp::List::create(Rcpp::Named("Q") = Q1,
                                Rcpp::Named("R") = R.topRows(R.cols()));
    } else {
      return Rcpp::List::create(Rcpp::Named("Q") = Q,
                                Rcpp::Named("R") = R);
    }
  } else {
    // QR left half
    Rcpp::List tmp(2);
    tmp = rbQR(As.leftCols(n1), nb, complete);
    Q1  = tmp(0);
    R11 = tmp(1);
    
    // QR right half
    R12                 = fastqr_backend::product(Q1, As.rightCols(n-n1), true);
    As.rightCols(n-n1) -= fastqr_backend::product(Q1, R12);
    tmp                 = rbQR(As.rightCols(n-n1), nb, complete);
    Q2                  = tmp(0);
    R22                 = tmp(1);
    
    // return
    Q.leftCols(n1)              = Q1;
    Q.rightCols(n-n1)           = Q2;
    R.block(0, 0, n1, n1)       = R11;
    R.block(0, n1, n1, n-n1)    = R12;
    R.block(n1, n1, n-n1, n-n1) = R22;
    R.triangularView<Eigen::StrictlyLower>().setZero();
    
    /* Return output      */
    if (complete == 0) {
      Eigen::MatrixXd Q1(n, R.cols()); Q1.setZero();
      Q1 = Q.leftCols(R.cols());
      return Rcpp::List::create(Rcpp::Named("Q") = Q1,
                                Rcpp::Named("R") = R.topRows(R.cols()));
    } else {
      return Rcpp::List::create(Rcpp::Named("Q") = Q,
                                Rcpp::Named("R") = R);
    }
  }
}

Eigen::MatrixXd householderR (const Eigen::MatrixXd& X) {
  
  int i = 0, n = X.rows(), p = X.cols();
  double beta = 0.0, mu = 0.0;
  Eigen::MatrixXd R = X;
  
  if (n >= p) {
    Eigen::VectorXd v(n-1); v.setZero();
    VectorXd tmp(n+2); tmp.setZero();
    
    for (i = 0; i < p; i++) {
      // Householder rotation
      tmp.resize(n-i+2);
      tmp  = householder(R.block(i, i, n-i, 1));
      v    = tmp.head(n-i);
      beta = tmp(n-i);
      mu   = tmp(n-i+1);
      
      // update R
      R(i, i) = mu;
      R.block(i+1, i, n-i-1, 1).setZero();
      if (i < p-1)
        R.block(i, i+1, n-i, p-i-1) -= (beta * v) * (v.transpose() * R.block(i, i+1, n-i, p-i-1));
    }
  } else {
    Rcpp::stop("* fastQR : if n is smaller than p the Cholesky factorization can not be computed!\n");
  }
  return R.topRows(R.cols());
}






// end file
