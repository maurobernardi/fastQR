// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::: //
// ::::::::::::::::::::                 :::::::::::::::::::: //
// ::::::::::::::::::::    QR wrap      :::::::::::::::::::: //
// ::::::::::::::::::::                 :::::::::::::::::::: //
// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::: //

#include "QRdecomposition.h"
#include "QRupdate.h"


// [[Rcpp::plugins("cpp11")]]
// [[Rcpp::depends(RcppEigen)]]
// [[Rcpp::depends(Rcpp)]]
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace Eigen;
using namespace arma;

//' @name qr
//' @usage qr(X, complete = NULL, type = NULL, nb = NULL)
//' @title The QR factorization of a matrix
//' @description qr provides the QR factorization of the matrix \eqn{X\in\mathbb{R}^{n\times p}} with \eqn{n>p}. The QR factorization of the matrix \eqn{X} returns the matrices \eqn{Q\in\mathbb{R}^{n\times n}} and \eqn{R\in\mathbb{R}^{n\times p}} such that \eqn{X=QR}. See Golub and Van Loan (2013) for further details on the method.
//' @param X a \eqn{n\times p} matrix.
//' @param type either "givens" or "householder".
//' @param nb integer terminal column-width threshold for recursive QR. NULL or zero selects the non-recursive algorithm. For reduced output use nb >= 2; complete output also supports nb = 1 (single-column terminal panels).
//' @param complete logical expression of length 1. Indicates whether an arbitrary orthogonal completion of the \eqn{Q} matrix is to be made, or whether the \eqn{R} matrix is to be completed by binding zero-value rows beneath the square upper triangle.
//' @return A named list containing \describe{
//' \item{Q}{the Q matrix.}
//' \item{R}{the R matrix.}
//' }
//'
//' @details
//' When nb is positive and complete is TRUE, recursive Householder panel
//' transformations are applied to the trailing design and accumulated in the
//' full Q matrix. The returned matrices have dimensions n by n and n by p.
//' No orthogonal completion of a separately computed thin basis is used.
//' The recursive reduced-output algorithm is unchanged. Recursive complete QR supports
//' tall and square inputs; for a wide input the existing non-recursive fallback
//' is used with a warning.
//' 
//' For tall inputs with complete = FALSE, the non-recursive Householder and
//' Givens methods form only the n by p Q factor. Their stored transformations
//' are applied in reverse order to the first p columns of the identity,
//' without constructing a complete n by n Q. Rounding in Q can differ from
//' the complete-output path; the R factor uses the same transformations.
//' 
//' @examples
//' ## generate sample data
//' set.seed(1234)
//' n <- 10
//' p <- 6
//' X <- matrix(rnorm(n * p, 1), n, p)
//'
//' ## QR factorization via Givens rotation
//' output <- qr(X, type = "givens", complete = TRUE)
//' Q      <- output$Q
//' R      <- output$R
//'
//' ## check
//' round(Q %*% R - X, 5)
//' max(abs(Q %*% R - X))
//'
//' ## QR factorization via Householder rotation
//' output <- qr(X, type = "householder", complete = TRUE)
//' Q      <- output$Q
//' R      <- output$R
//'
//' ## check
//' round(Q %*% R - X, 5)
//' max(abs(Q %*% R - X))
//'
//' @references
//' \insertRef{golub_van_loan.2013}{fastQR}
//'
//' \insertRef{bjorck.2015}{fastQR}
//'
//' \insertRef{bjorck.2024}{fastQR}
//'
//' \insertRef{bernardi_etal.2024}{fastQR}
//'

//' @note Wide designs (p > n) use Q of size n by n and R of size n by p for either value of complete. Recursive QR falls back to the non-recursive method with a warning. Matrices with a nonzero column count must have at least one row.
// [[Rcpp::export]]
Rcpp::List qr(const Eigen::MatrixXd& X,
              Rcpp::Nullable<bool> complete = R_NilValue,
              Rcpp::Nullable<std::string> type = R_NilValue,
              Rcpp::Nullable<int> nb = R_NilValue) {
  if (X.rows() == 0) {
    if (X.cols() == 0) return Rcpp::List::create(
      Rcpp::Named("Q") = Eigen::MatrixXd(0, 0),
      Rcpp::Named("R") = Eigen::MatrixXd(0, 0));
    Rcpp::stop("* qr: a matrix with columns must have at least one row.");
  }

  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  Rcpp::List output;
  int nb_ = 0;
  bool complete_ = false;
  std::string type_ = "householder";
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                                  */
  const int n = X.rows();
  const int p = X.cols();

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   check for NULL:                                    */
  if (nb.isNotNull()) {
    nb_ = Rcpp::as<int>(nb);
    /* recursive block update is a valid option only when n>p */
    if (p > n) {
      nb_ = 0;
      warning("* fastQR : the parameter nb is set to NULL if p > n!\n");
    }
  } else {
    nb_ = 0;
  }
  if (type.isNotNull()) {
    type_ = Rcpp::as<std::string>(type);
  } else {
    type_ = "householder";
  }
  if (complete.isNotNull()) {
    complete_ = Rcpp::as<bool>(complete);
  } else {
    complete_ = false;
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   QR factorization                                   */
  if (nb_ == 0) {
    if (type_ == "householder") {
      //Rcpp::Rcout << "QR decomposition using Householder reflections.\n";
      output = householderQR(X, complete_);
    } else if (type_ == "givens") {
      //Rcpp::Rcout << "QR decomposition using Givens rotations.\n";
      output = givensQR(X, complete_);
    }
  } else {
    //Rcpp::Rcout << "Recursive block QR decomposition.\n";
    output = rbQR(X, nb_, complete_);
  }

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return output;
}

//' @name qrupdate
//' @title Fast updating of the QR factorization
//' @description qrupdate provides the update of the QR factorization after the addition of \eqn{m>1} rows or columns to the matrix \eqn{X\in\mathbb{R}^{n\times p}} with \eqn{n>p}. The QR factorization of the matrix \eqn{X} returns the matrices \eqn{Q\in\mathbb{R}^{n\times n}} and \eqn{R\in\mathbb{R}^{n\times p}} such that \eqn{X=QR}. The \eqn{Q} and \eqn{R} matrices are factorized as \eqn{Q=\begin{bmatrix}Q_1&Q_2\end{bmatrix}} and \eqn{R=\begin{bmatrix}R_1\\R_2\end{bmatrix}}, with \eqn{Q_1\in\mathbb{R}^{n\times p}}, \eqn{Q_2\in\mathbb{R}^{n\times (n-p)}} such that \eqn{Q_1^{\top}Q_2=Q_2^\top Q_1=0} and \eqn{R_1\in\mathbb{R}^{p\times p}} upper triangular matrix and \eqn{R_2\in\mathbb{R}^{(n-p)\times p}}. qrupdate accepts in input the matrices \eqn{Q} and either the complete matrix \eqn{R} or the reduced one, \eqn{R_1}. See Golub and Van Loan (2013) for further details on the method.
//' @param Q a \eqn{n\times p} matrix.
//' @param R a \eqn{p\times p} upper triangular matrix.
//' @param k position where the columns or the rows are added.
//' @param U either a \eqn{n\times m} matrix or a \eqn{p\times m} matrix of columns or rows to be added.
//' @param type either 'row' of 'column', for adding rows or columns. Default is 'column'.
//' @param fast fast mode: disable to check whether the provided matrices are valid inputs. Default is FALSE.
//' @param complete logical expression of length 1. Indicates whether an arbitrary orthogonal completion of the \eqn{Q} matrix is to be made, or whether the \eqn{R} matrix is to be completed by binding zero-value rows beneath the square upper triangle.
//' @return A named list containing \describe{
//' \item{Q}{the updated Q matrix.}
//' \item{R}{the updated R matrix.}
//' }
//'
//' @examples
//' ## Add one column
//' ## generate sample data
//' set.seed(1234)
//' n <- 12
//' p <- 5
//' X <- matrix(rnorm(n * p, 1), n, p)
//'
//' ## get the initial QR factorization
//' output <- qr(X, complete = TRUE)
//' Q      <- output$Q
//' R      <- output$R
//'
//' ## create column u to be added
//' k  <- p+1
//' u  <- matrix(rnorm(n), n, 1)
//' X1 <- cbind(X, u)
//'
//' ## update the QR decomposition
//'out <- fastQR::qrupdate(Q = Q, R = R,
//'                        k = k, U = u,
//'                        type = "column",
//'                        fast = FALSE,
//'                        complete = TRUE)
//'
//' ## check
//' round(out$Q %*% out$R - X1, 5)
//' max(abs(out$Q %*% out$R - X1))
//'
//' ## Add m columns
//' ## create data: n > p
//' set.seed(1234)
//' n <- 10
//' p <- 5
//' X <- matrix(rnorm(n * p, 1), n, p)
//'
//' ## get the initial QR factorization
//' output <- fastQR::qr(X, complete = TRUE)
//' Q      <- output$Q
//' R      <- output$R
//'
//' ## create the matrix of two columns to be added
//' ## in position 2
//' k  <- 2
//' m  <- 2
//' U  <- matrix(rnorm(n*m), n, m)
//' X1 <- cbind(X[,1:(k-1)], U, X[,k:p])
//'
//' # update the QR decomposition
//' out <- fastQR::qrupdate(Q = Q, R = R,
//'                         k = k, U = U, type = "column",
//'                        fast = FALSE, complete = TRUE)
//'
//' ## check
//' round(out$Q %*% out$R - X1, 5)
//' max(abs(out$Q %*% out$R - X1))
//'
//' ## Add one row
//' ## create data: n > p
//' set.seed(1234)
//' n <- 12
//' p <- 5
//' X <- matrix(rnorm(n * p, 1), n, p)
//'
//' ## get the initial QR factorization
//' output <- fastQR::qr(X, complete = TRUE)
//' Q      <- output$Q
//' R      <- output$R
//' R1     <- R[1:p,]
//'
//' ## create the row u to be added
//' u  <- matrix(data = rnorm(p), p, 1)
//' k  <- n+1
//' if (k<=n) {
//'   X1 <- rbind(rbind(X[1:(k-1), ], t(u)), X[k:n, ])
//' } else {
//'   X1 <- rbind(rbind(X, t(u)))
//' }
//'
//' ## update the QR decomposition
//' out <- fastQR::qrupdate(Q = Q, R = R,
//'                         k = k, U = u,
//'                         type = "row",
//'                         complete = TRUE)
//'
//' ## check
//' round(out$Q %*% out$R - X1, 5)
//' max(abs(out$Q %*% out$R - X1))
//'
//' ## Add m rows
//' ## create data: n > p
//' set.seed(1234)
//' n <- 12
//' p <- 5
//' X <- matrix(rnorm(n * p, 1), n, p)
//'
//' ## get the initial QR factorization
//' output <- fastQR::qr(X, complete = TRUE)
//' Q      <- output$Q
//' R      <- output$R
//' R1     <- R[1:p,]
//'
//' ## create the matrix of rows U to be added:
//' ## two rows in position 5
//' m  <- 2
//' U  <- matrix(data = rnorm(p*m), p, m)
//' k  <- 5
//' if (k<=n) {
//'   X1 <- rbind(rbind(X[1:(k-1), ], t(U)), X[k:n, ])
//' } else {
//'   X1 <- rbind(rbind(X, t(U)))
//' }
//'
//' ## update the QR decomposition
//' out <- fastQR::qrupdate(Q = Q, R = R,
//'                         k = k, U = U,
//'                         type = "row",
//'                         complete = FALSE)
//'
//' ## check
//' round(out$Q %*% out$R - X1, 5)
//' max(abs(out$Q %*% out$R - X1))
//'
//' @references
//' \insertRef{golub_van_loan.2013}{fastQR}
//'
//' \insertRef{bjorck.2015}{fastQR}
//'
//' \insertRef{bjorck.2024}{fastQR}
//'
//' \insertRef{bernardi_etal.2024}{fastQR}
//'
//' @note Wide input factors and column additions producing more columns than rows are rejected even in fast mode.
// [[Rcpp::export]]
Rcpp::List qrupdate(const Eigen::MatrixXd& Q,
                    const Eigen::MatrixXd& R,
                    const int k,
                    const Eigen::MatrixXd& U,
                    Rcpp::Nullable<std::string> type = R_NilValue,
                    Rcpp::Nullable<bool> fast = R_NilValue,
                    Rcpp::Nullable<bool> complete = R_NilValue) {
  if (R.cols() > Q.rows() || R.cols() > R.rows())
    Rcpp::stop("* qrupdate: wide factors are not supported; require p <= n.");

  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  Rcpp::List output, res;
  bool complete_ = false, fast_ = false;
  std::string type_ = "column";
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                                  */
  const int Q_nrow = Q.rows();
  const int Q_ncol = Q.cols();
  const int R_nrow = R.rows();
  const int R_ncol = R.cols();                // p
  const int m      = U.cols();                // m
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   check for NULL:                                    */
  if (type.isNotNull()) {
    type_ = Rcpp::as<std::string>(type);
    if ((type_ != "column") && (type_ != "row")) {
      type_ = "column";
    }
  } else {
    type_ = "column";
  }
  if (fast.isNotNull()) {
    fast_ = Rcpp::as<bool>(fast);
  } else {
    fast_ = false;
  }
  if (complete.isNotNull()) {
    complete_ = Rcpp::as<bool>(complete);
  } else {
    complete_ = false;
  }
  
  if (type_ == "column" && R_ncol + m > Q_nrow)
    Rcpp::stop("* qrupdate: adding these columns would produce a wide design (p+m > n).");
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   Pre-processing: m and p                          */
  if (!fast_) {
    if (type_ == "column") {
      if (m >= (Q_nrow - R_ncol)) {
        stop("* qrupdate : adding too many columns.");
      }
    }
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   Pre-processing: Q, R and U matrices:            */
  if (!fast_) {
    if (Q_ncol <= R_ncol) {
      stop("* qrupdate : p is greater than n.");
    }
    if (R_nrow == R_ncol) {
      stop("* qrupdate : the input 'R' is not the 'complete' R matrix.");
    }
    if (Q_nrow != Q_ncol) {
      stop("* qrupdate : the input 'Q' is not a square matrix.");
    }
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vectors and matrices declaration                    */
  Eigen::MatrixXd Qin;
  Eigen::MatrixXd Rin;
  Eigen::MatrixXd Qs;
  Eigen::MatrixXd Rs;
  Eigen::MatrixXd Q_;
  Eigen::MatrixXd R_;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   Update the QR matrix: adding one or more columns:     */
  if (type_ == "column") {
  
    // resize Q_ and R_
    
    // resize the input matrices:
    // le due righe seguenti le ho cambiate il 3 settembre 2025
    //Qin = Q;
    //Rin = R.topLeftCorner(R_ncol, R_ncol);
    
    // modifica da fare:
    Rin = R.topLeftCorner(R_ncol, R_ncol);
    Qin = Q;
    
    // get the dimension of the matrix U
    if (!fast_) {
      if (U.rows() != Q_nrow) {
        stop("* qrupdate : two inputs 'Q' and 'U' have non-matching dimensions.");
      }
    }
    if (m == 1) {
      // perform add one column
      res = qraddcol(Qin, Rin, k, U.col(0));
    } else {
      // perform add m columns
      res = qraddmcols(Qin, Rin, k, U);
    }
    
    // Output
    Q_ = res["Q"];
    R_ = res["R"];
    if (complete_) {
      Qs.resize(Q_nrow, Q_nrow);
      Rs.resize(Q_nrow, R_ncol+m);
      Rs.setZero();
      Qs                                 = Q_.block(0, 0, Qs.rows(), Qs.cols());
      Rs.block(0, 0, R_ncol+m, R_ncol+m) = R_;
      output = Rcpp::List::create(Rcpp::Named("Q") = Qs,
                                  Rcpp::Named("R") = Rs);
    } else {
      Qs.resize(Q_nrow, R_ncol+m);
      Qs     = Q_.block(0, 0, Qs.rows(), Qs.cols());
      output = Rcpp::List::create(Rcpp::Named("Q") = Qs,
                                  Rcpp::Named("R") = R_);
    }
  }

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   Update the QR matrix: adding one or more rows:     */
  if (type_ == "row") {
    
    // resize Q_ and R_: add one row returns a Q (n+1, n+1) and a R(p, p)
        
    // resize the input matrices: delete rows requires the reduced QR factorization
    Qin = Q;
    Rin = R.topLeftCorner(R_ncol, R_ncol);
    
    // get the dimension of the matrix U
    if (!fast_) {
      if (U.rows() != R_ncol) {
        stop("* QRupdate : two inputs 'Q' and 'U' have non-matching dimensions.");
      }
    }
    if (m == 1) {
      // perform add one row
      res = qraddrow(Qin, Rin, k, U.col(0).transpose());
      Q_  = res["Q"];
      R_  = res["R"];
    } else {
      // perform add m rows
      res = qraddmrows(Qin, Rin, k, U.transpose());
    }
    
    // Output
    Q_ = res["Q"];
    R_ = res["R"];
    if (complete_) {
      Rs.resize(Q_nrow+m, R_ncol);
      Rs.setZero();
      Rs.block(0, 0, R_ncol, R_ncol) = R_;
      output                         = Rcpp::List::create(Rcpp::Named("Q") = Q_,
                                                          Rcpp::Named("R") = Rs);
    } else {
      Qs.resize(Q_nrow+m, R_ncol);
      Qs     = Q_.block(0, 0, Q_nrow+m, R_ncol);
      output = Rcpp::List::create(Rcpp::Named("Q") = Qs,
                                  Rcpp::Named("R") = R_);
    }
  }
  
  /* return output          */
  return output;
}

//' @name qrdowndate
//' @title Fast downdating of the QR factorization
//' @description qrdowndate provides the update of the QR factorization after the deletion of \eqn{m>1} rows or columns to the matrix \eqn{X\in\mathbb{R}^{n\times p}} with \eqn{n>p}. The QR factorization of the matrix \eqn{X\in\mathbb{R}^{n\times p}} returns the matrices \eqn{Q\in\mathbb{R}^{n\times n}} and \eqn{R\in\mathbb{R}^{n\times p}} such that \eqn{X=QR}. The \eqn{Q} and \eqn{R} matrices are factorized as \eqn{Q=\begin{bmatrix}Q_1&Q_2\end{bmatrix}} and \eqn{R=\begin{bmatrix}R_1\\R_2\end{bmatrix}}, with \eqn{Q_1\in\mathbb{R}^{n\times p}}, \eqn{Q_2\in\mathbb{R}^{n\times (n-p)}} such that \eqn{Q_1^{\top}Q_2=Q_2^\top Q_1=0} and \eqn{R_1\in\mathbb{R}^{p\times p}} upper triangular matrix and \eqn{R_2\in\mathbb{R}^{(n-p)\times p}}. qrdowndate accepts in input the matrices \eqn{Q} and either the complete matrix \eqn{R} or the reduced one, \eqn{R_1}. See Golub and Van Loan (2013) for further details on the method.
//' @param Q a complete \eqn{n\times n} orthogonal matrix, or a thin \eqn{n\times p} matrix for column deletion with reduced output.
//' @param R the complete \eqn{n\times p} upper trapezoidal factor, or its \eqn{p\times p} upper triangular block for column deletion with reduced output.
//' @param k position where the columns or the rows are removed.
//' @param m number of columns or rows to be removed. Default is \eqn{m=1}.
//' @param type either 'row' of 'column', for deleting rows or columns. Default is 'column'.
//' @param fast fast mode: disable to check whether the provided matrices are valid inputs. Default is FALSE.
//' @param complete logical expression of length 1. Indicates whether an arbitrary orthogonal completion of the \eqn{Q} matrix is to be made, or whether the \eqn{R} matrix is to be completed by binding zero-value rows beneath the square upper triangle.
//' @return A named list containing \describe{
//' \item{Q}{the updated Q matrix.}
//' \item{R}{the updated R matrix.}
//' }
//'
//' @details
//' For column deletion with complete = FALSE, Q and R may independently be
//' complete or thin factors. Only the first p columns of Q and the leading
//' p by p block of R are used. The input matrices are unchanged and the output
//' has dimensions n by (p-m) and (p-m) by (p-m). The reduced path avoids
//' internal n by n factor allocations; double R matrices are read through
//' non-owning views before the required thin blocks are copied. Integer inputs
//' may require coercion to double. Structural dimension and index checks remain
//' active in fast mode; finite-value checks on the used blocks are skipped.
//' For complete output or row deletion, complete input factors are still required.
//' For row deletion, require 1 <= m <= n-p and 1 <= k <= n-m+1.
//' Deleting n-p rows is allowed and produces square factors. These bounds
//' are checked even in fast mode.
//' The reduced output can be supplied directly to another reduced column deletion.
//'
//' @examples
//' ## Remove one column
//' ## generate sample data
//' set.seed(10)
//' n      <- 10
//' p      <- 6
//' X      <- matrix(rnorm(n * p, 1), n, p)
//'
//' ## get the initial QR factorization
//' output <- fastQR::qr(X, type = "householder",
//'                      nb = NULL,
//'                      complete = TRUE)
//' Q      <- output$Q
//' R      <- output$R
//'
//' ## select the column to be deleted
//' ## from X and update X
//' k  <- 2
//' X1 <- X[, -k]
//'
//' ## downdate the QR decomposition
//' out <- fastQR::qrdowndate(Q = Q, R = R,
//'                           k = k, m = 1,
//'                           type = "column",
//'                           fast = FALSE,
//'                           complete = TRUE)
//'
//' ## check
//' round(out$Q %*% out$R - X1, 5)
//' max(abs(out$Q %*% out$R - X1))
//'
//' ## Remove m columns
//' ## generate sample data
//' set.seed(10)
//' n      <- 10
//' p      <- 6
//' X      <- matrix(rnorm(n * p, 1), n, p)
//'
//' ## get the initial QR factorization
//' output <- fastQR::qr(X, type = "householder",
//'                      nb = NULL,
//'                      complete = TRUE)
//' Q      <- output$Q
//' R      <- output$R
//'
//' ## select the column to be deleted from X
//' ## and update X
//' m  <- 2
//' k  <- 2
//' X1 <- X[, -c(k,k+m-1)]
//'
//' ## downdate the QR decomposition
//' out <- fastQR::qrdowndate(Q = Q, R = R,
//'                           k = k, m = 2,
//'                           type = "column",
//'                           fast = TRUE,
//'                           complete = FALSE)
//'
//' ## check
//' round(out$Q %*% out$R - X1, 5)
//' max(abs(out$Q %*% out$R - X1))
//'
//' ## Remove one row
//' ## generate sample data
//' set.seed(10)
//' n      <- 10
//' p      <- 6
//' X      <- matrix(rnorm(n * p, 1), n, p)
//'
//' ## get the initial QR factorization
//' output <- fastQR::qr(X, type = "householder",
//'                      nb = NULL,
//'                      complete = TRUE)
//' Q      <- output$Q
//' R      <- output$R
//'
//' ## select the row to be deleted from X and update X
//' k  <- 5
//' X1 <- X[-k,]
//'
//' ## downdate the QR decomposition
//' out <- fastQR::qrdowndate(Q = Q, R = R,
//'                           k = k, m = 1,
//'                           type = "row",
//'                           fast = FALSE,
//'                           complete = TRUE)
//'
//' ## check
//' round(out$Q %*% out$R - X1, 5)
//' max(abs(out$Q %*% out$R - X1))
//'
//' ## Remove m rows
//' ## generate sample data
//' set.seed(10)
//' n      <- 10
//' p      <- 6
//' X      <- matrix(rnorm(n * p, 1), n, p)
//'
//' ## get the initial QR factorization
//' output <- fastQR::qr(X, type = "householder",
//'                      nb = NULL,
//'                      complete = TRUE)
//' Q      <- output$Q
//' R      <- output$R
//'
//' ## select the rows to be deleted from X and update X
//' k  <- 5
//' m  <- 2
//' X1 <- X[-c(k,k+1),]
//'
//' ## downdate the QR decomposition
//' out <- fastQR::qrdowndate(Q = Q, R = R,
//'                           k = k, m = m,
//'                           type = "row",
//'                           fast = FALSE,
//'                           complete = TRUE)
//'
//' ## check
//' round(out$Q %*% out$R - X1, 5)
//' max(abs(out$Q %*% out$R - X1))
//'
//' @references
//' \insertRef{golub_van_loan.2013}{fastQR}
//'
//' \insertRef{bjorck.2015}{fastQR}
//'
//' \insertRef{bjorck.2024}{fastQR}
//'
//' \insertRef{bernardi_etal.2024}{fastQR}
//'
//' @note Wide input factors are not supported and are rejected even in fast mode.
// [[Rcpp::export]]
Rcpp::List qrdowndate(const Rcpp::NumericMatrix& Q,
                      const Rcpp::NumericMatrix& R,
                      const int k,
                      Rcpp::Nullable<int> m = R_NilValue,
                      Rcpp::Nullable<std::string> type = R_NilValue,
                      Rcpp::Nullable<bool> fast = R_NilValue,
                      Rcpp::Nullable<bool> complete = R_NilValue) {
  if (R.ncol() > Q.nrow() || R.ncol() > R.nrow())
    Rcpp::stop("* qrdowndate: wide factors are not supported; require p <= n.");

  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  Rcpp::List output, res;
  bool complete_ = false, fast_ = false;
  std::string type_ = "column";
  int m_ = 1;

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                                  */
  const int Q_nrow = Q.nrow();
  const int Q_ncol = Q.ncol();
  const int R_nrow = R.nrow();
  const int R_ncol = R.ncol();                // p
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   check for NULL:                                    */
  if (type.isNotNull()) {
    type_ = Rcpp::as<std::string>(type);
    if ((type_ != "column") && (type_ != "row")) {
      type_ = "column";
    }
  } else {
    type_ = "column";
  }
  if (fast.isNotNull()) {
    fast_ = Rcpp::as<bool>(fast);
  } else {
    fast_ = false;
  }
  if (complete.isNotNull()) {
    complete_ = Rcpp::as<bool>(complete);
  } else {
    complete_ = false;
  }
  if (m.isNotNull()) {
    m_ = Rcpp::as<int>(m);
  } else {
    m_ = 1;
  }
  
  // Map double R matrices without first creating full Eigen copies.
  const Eigen::Map<const Eigen::MatrixXd> Q_view(Q.begin(), Q_nrow, Q_ncol);
  const Eigen::Map<const Eigen::MatrixXd> R_view(R.begin(), R_nrow, R_ncol);

  // Return before allocating any complete factors. Only the first p columns
  // of Q and the leading p x p block of R are needed for column deletion.
  if (type_ == "column" && !complete_) {
    const int p = R_ncol;
    if (p < 2 || Q_nrow < p ||
        (Q_ncol != p && Q_ncol != Q_nrow) ||
        (R_nrow != p && R_nrow != Q_nrow)) {
      Rcpp::stop("* qrdowndate: reduced column deletion requires compatible full or thin factors.");
    }
    // Bounds are structural safety checks even in fast mode.
    if (m_ < 1 || m_ >= p || k < 1 || k > p-m_+1) {
      Rcpp::stop("* qrdowndate: invalid column deletion position or count.");
    }
    const Eigen::MatrixXd Q_red = Q_view.leftCols(p);
    const Eigen::MatrixXd R_red = R_view.topLeftCorner(p, p);
    if (!fast_ && (!Q_red.allFinite() || !R_red.allFinite())) {
      Rcpp::stop("* qrdowndate: the active Q and R blocks must contain finite values.");
    }
    if (m_ == 1) {
      return qrdeletecol_red(Q_red, R_red, k);
    }
    return qrdeletemcols_adj_red(Q_red, R_red, k, m_);
  }

  // Row deletion needs complete input factors and at least p surviving rows.
  // Keep structural bounds active even in fast mode.
  if (type_ == "row") {
    if (R_ncol < 1 || Q_nrow <= R_ncol || Q_ncol != Q_nrow || R_nrow != Q_nrow) {
      stop("* qrdowndate: row deletion requires complete Q and R with n > p.");
    }
    if (m_ < 1 || m_ > Q_nrow-R_ncol || k < 1 || k > Q_nrow-m_+1) {
      stop("* qrdowndate: invalid row block; require m >= 1, n-m >= p, and 1 <= k <= n-m+1.");
    }
  }

  // Preserve the established complete-output and row-deletion paths.
  const Eigen::MatrixXd Q_owned = Q_view;
  const Eigen::MatrixXd R_owned = R_view;

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   Pre-processing: m and p                          */
  if (!fast_) {
    if (type_ == "column") {
      if (R_ncol < 2) {
        stop("* qrdowndate : there is only one column.");
      }
      if (m_ >= R_ncol) {
        stop("* qrdowndate : removing too many columns.");
      }
    } else {
      if (Q_nrow < 2) {
        stop("* qrdowndate : there is only one row.");
      }
    }
  }

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   Pre-processing: Q_owned, R_owned matrices:                   */
  if (!fast_) {
    if (Q_ncol <= R_ncol) {
      stop("* qrdowndate : p is greater than n.");
    }
    if (R_nrow == R_ncol) {
      stop("* qrdowndate : the input 'R' is not the 'complete' R_owned matrix.");
    }
    if (Q_ncol != R_nrow) {
      stop("* qrdowndate : two inputs 'Q' and 'R' have non-matching dimensions.");
    }
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vectors and matrices declaration                    */
  Eigen::MatrixXd Qin;
  Eigen::MatrixXd Rin;
  Eigen::MatrixXd Qs;
  Eigen::MatrixXd Rs;
  Eigen::MatrixXd Q_;
  Eigen::MatrixXd R_;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   Downdate the QR matrix: removing one or more columns:     */
  if (type_ == "column") {
    // resize Q_ and R_
    
    // resize the input matrices: delete rows requires the reduced QR factorization
    Qin = Q_owned;
    Rin = R_owned.topLeftCorner(R_ncol, R_ncol);
  
    if (m_ == 1) {
      // perform add one column
      res = complete_ ? qrdeletecol_complete(Qin, Rin, k)
                      : qrdeletecol(Qin, Rin, k);
    } else {
      // perform add m column
      res = complete_ ? qrdeletemcols_adj_complete(Qin, Rin, k, m_)
                      : qrdeletemcols_adj(Qin, Rin, k, m_);
    }
    
    // Output
    Q_ = res["Q"];
    R_ = res["R"];
    if (complete_) {
      Rs.resize(Q_nrow, R_ncol-m_);
      Rs.setZero();
      // Q_ already contains the transformed full orthogonal basis.
      // Zero padding is valid for R_owned below, but never for Q_owned.
      Qs = Q_;
      Rs.block(0, 0, R_ncol-m_, R_ncol-m_) = R_;
      output                               = Rcpp::List::create(Rcpp::Named("Q") = Qs,
                                                                Rcpp::Named("R") = Rs);
    } else {
      Rs.resize(R_ncol-m_, R_ncol-m_);
      Rs.setZero();
      Qs.resize(Q_nrow, R_ncol-m_);
      Qs.block(0, 0, Q_nrow, R_ncol-m_)    = Q_.block(0, 0, Q_nrow, R_ncol-m_);
      Rs.block(0, 0, R_ncol-m_, R_ncol-m_) = R_;
      output                               = Rcpp::List::create(Rcpp::Named("Q") = Qs,
                                                                Rcpp::Named("R") = Rs);
    }
  }

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   Downdate the QR matrix: removing one or more rows:     */
  if (type_ == "row") {
    
    // resize Q_ and R_
    
    // Row-deletion kernels consume the square triangular factor, not the
    // complete n x p R supplied at the R interface.
    Rin = R_owned.topLeftCorner(R_ncol, R_ncol);
    if (m_ == 1) {
      // remove one row
      res = qrdeleterow(Q_owned, Rin, k);
    } else {
      // remove a consecutive block of rows
      res = qrdeletemrows(Q_owned, Rin, k, m_);
    }
    
    // Output
    Q_ = res["Q"];
    R_ = res["R"];
    
    if (complete_) {
      Qs.resize(Q_nrow-m_, Q_nrow-m_);
      Rs.resize(Q_nrow-m_, R_ncol);
      Rs.setZero();
      Qs.block(0, 0, Q_nrow-m_, Q_ncol-m_) = Q_;
      Rs.block(0, 0, R_ncol, R_ncol)       = R_;
      output                               = Rcpp::List::create(Rcpp::Named("Q") = Qs,
                                                                Rcpp::Named("R") = Rs);
    } else {
      Qs.resize(Q_nrow-m_, R_ncol);
      Rs.resize(R_ncol, R_ncol);
      Qs     = Q_.block(0, 0, Qs.rows(), Qs.cols());
      Rs     = R_.block(0, 0, Rs.rows(), Rs.cols());
      output = Rcpp::List::create(Rcpp::Named("Q") = Qs,
                                  Rcpp::Named("R") = Rs);
    }
  }

  /* return output          */
  return output;
}


  
