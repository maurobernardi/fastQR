#include <Rcpp.h>
#include <R_ext/Lapack.h>
#include <climits>
#include <cmath>
#include <algorithm>

namespace {
int qr_workspace(double query) {
  if (!R_FINITE(query) || query < 1 || query > INT_MAX)
    Rcpp::stop("Invalid LAPACK workspace size.");
  return static_cast<int>(std::ceil(query));
}
}

// [[Rcpp::export]]
Rcpp::List qr_lapack_impl(Rcpp::NumericMatrix X, std::string output) {
  const int m = X.nrow(), p = X.ncol(), k = std::min(m, p);
  if (m < 1 || p < 1) Rcpp::stop("X must have positive dimensions.");
  for (R_xlen_t i = 0; i < X.size(); ++i)
    if (!R_FINITE(X[i])) Rcpp::stop("X must contain only finite values.");
  if (output != "thin" && output != "full" && output != "R" && output != "compact")
    Rcpp::stop("Invalid output specification.");
  int lda = std::max(1, m), info = 0, lwork = -1;
  double query = 0;
  Rcpp::NumericMatrix packed = Rcpp::clone(X);
  Rcpp::NumericVector tau(k);
  F77_CALL(dgeqrf)(&m, &p, packed.begin(), &lda, tau.begin(), &query, &lwork, &info);
  if (info != 0) Rcpp::stop("DGEQRF workspace query failed (info=%d).", info);
  lwork = qr_workspace(query);
  Rcpp::NumericVector work(lwork);
  F77_CALL(dgeqrf)(&m, &p, packed.begin(), &lda, tau.begin(), work.begin(), &lwork, &info);
  if (info != 0) Rcpp::stop("DGEQRF failed (info=%d).", info);
  if (output == "compact")
    return Rcpp::List::create(Rcpp::Named("qr") = packed, Rcpp::Named("tau") = tau);
  const int nr = output == "full" ? m : k;
  Rcpp::NumericMatrix R(nr, p);
  for (int j = 0; j < p; ++j)
    for (int i = 0; i < std::min(k, j + 1); ++i) R(i, j) = packed(i, j);
  if (output == "R") return Rcpp::List::create(Rcpp::Named("R") = R);
  const int nq = output == "full" ? m : k;
  Rcpp::NumericMatrix Q(m, nq);
  for (int j = 0; j < k; ++j)
    for (int i = 0; i < m; ++i) Q(i, j) = packed(i, j);
  lwork = -1;
  F77_CALL(dorgqr)(&m, &nq, &k, Q.begin(), &lda, tau.begin(), &query, &lwork, &info);
  if (info != 0) Rcpp::stop("DORGQR workspace query failed (info=%d).", info);
  lwork = qr_workspace(query);
  Rcpp::NumericVector qwork(lwork);
  F77_CALL(dorgqr)(&m, &nq, &k, Q.begin(), &lda, tau.begin(), qwork.begin(), &lwork, &info);
  if (info != 0) Rcpp::stop("DORGQR failed (info=%d).", info);
  return Rcpp::List::create(Rcpp::Named("Q") = Q, Rcpp::Named("R") = R);
}
