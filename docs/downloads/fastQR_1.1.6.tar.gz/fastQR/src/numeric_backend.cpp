// Keep R's Fortran declarations isolated from Armadillo's declarations.
#include "numeric_backend.h"
#include <R_ext/BLAS.h>
#include <R_ext/Lapack.h>
#include <cmath>
#include <climits>
namespace fastqr_backend {
static int workspace(double query) {
 if (!R_FINITE(query) || query < 1 || query > INT_MAX) Rcpp::stop("Invalid LAPACK workspace size.");
 return static_cast<int>(std::ceil(query));
}
Eigen::MatrixXd product(ConstMatrix a, ConstMatrix b, bool ta, bool tb) {
 const int m=ta?a.cols():a.rows(), k=ta?a.rows():a.cols();
 const int kb=tb?b.cols():b.rows(), n=tb?b.rows():b.cols();
 if(k!=kb) Rcpp::stop("Internal BLAS product dimension mismatch.");
 Eigen::MatrixXd c=Eigen::MatrixXd::Zero(m,n);
 if(m==0 || n==0 || k==0) return c;
 // Small products retain Eigen's inlined kernels; avoid Fortran call overhead.
 if(static_cast<double>(m)*n*k < 4096) {
  if(ta && tb) c.noalias()=a.transpose()*b.transpose();
  else if(ta) c.noalias()=a.transpose()*b;
  else if(tb) c.noalias()=a*b.transpose();
  else c.noalias()=a*b;
  return c;
 }
 const char transa=ta?'T':'N',transb=tb?'T':'N';
 const int lda=a.outerStride(),ldb=b.outerStride(),ldc=m;
 const double one=1,zero=0;
 F77_CALL(dgemm)(&transa,&transb,&m,&n,&k,&one,a.data(),&lda,b.data(),&ldb,&zero,c.data(),&ldc FCONE FCONE);
 return c;
}
Eigen::VectorXd matvec(ConstMatrix a, ConstVector b, bool transpose) {
 const int m=a.rows(),n=a.cols(),out=transpose?n:m,inner=transpose?m:n;
 if(b.size()!=inner) Rcpp::stop("Internal BLAS matrix-vector dimension mismatch.");
 Eigen::VectorXd c=Eigen::VectorXd::Zero(out);
 if(out==0 || inner==0) return c;
 if(static_cast<double>(m)*n <4096) {
  if(transpose) c.noalias()=a.transpose()*b; else c.noalias()=a*b;
  return c;
 }
 const char tr=transpose?'T':'N'; const int lda=a.outerStride(),inc=1;
 const double one=1,zero=0;
 F77_CALL(dgemv)(&tr,&m,&n,&one,a.data(),&lda,b.data(),&inc,&zero,c.data(),&inc FCONE);
 return c;
}
PackedQR factor(ConstMatrix x) {
 PackedQR f;f.qr=x;
 const int m=x.rows(),n=x.cols(),k=std::min(m,n),lda=std::max(1,m);
 f.tau.resize(k);if(k==0)return f;
 int info=0,lwork=-1;double query;
 F77_CALL(dgeqrf)(&m,&n,f.qr.data(),&lda,f.tau.data(),&query,&lwork,&info);
 if(info) Rcpp::stop("DGEQRF workspace query failed.");
 lwork=workspace(query);Eigen::VectorXd work(lwork);
 F77_CALL(dgeqrf)(&m,&n,f.qr.data(),&lda,f.tau.data(),work.data(),&lwork,&info);
 if(info) Rcpp::stop("DGEQRF failed.");return f;
}
Eigen::MatrixXd form_q(const PackedQR& f,int columns) {
 const int m=f.qr.rows(),k=f.tau.size(),lda=std::max(1,m);
 if(columns<k || columns>m) Rcpp::stop("Invalid explicit-Q dimensions.");
 Eigen::MatrixXd q=Eigen::MatrixXd::Zero(m,columns);
 if(k==0)return Eigen::MatrixXd::Identity(m,columns);
 q.leftCols(k)=f.qr.leftCols(k);
 int info=0,lwork=-1;double query;
 F77_CALL(dorgqr)(&m,&columns,&k,q.data(),&lda,f.tau.data(),&query,&lwork,&info);
 if(info)Rcpp::stop("DORGQR workspace query failed.");
 lwork=workspace(query);Eigen::VectorXd work(lwork);
 F77_CALL(dorgqr)(&m,&columns,&k,q.data(),&lda,f.tau.data(),work.data(),&lwork,&info);
 if(info)Rcpp::stop("DORGQR failed.");return q;
}
Eigen::MatrixXd apply_q(const PackedQR& f,ConstMatrix b,bool transpose,bool right) {
 const int m=b.rows(),n=b.cols(),k=f.tau.size(),lda=std::max(1,int(f.qr.rows())),ldc=std::max(1,m);
 if((right?n:m)!=f.qr.rows()) Rcpp::stop("Internal orthogonal-product dimension mismatch.");
 Eigen::MatrixXd c=b;if(!m || !n || !k)return c;
 const char side=right?'R':'L',trans=transpose?'T':'N';int info=0,lwork=-1;double query;
 F77_CALL(dormqr)(&side,&trans,&m,&n,&k,f.qr.data(),&lda,f.tau.data(),c.data(),&ldc,&query,&lwork,&info FCONE FCONE);
 if(info)Rcpp::stop("DORMQR workspace query failed.");
 lwork=workspace(query);Eigen::VectorXd work(lwork);
 F77_CALL(dormqr)(&side,&trans,&m,&n,&k,f.qr.data(),&lda,f.tau.data(),c.data(),&ldc,work.data(),&lwork,&info FCONE FCONE);
 if(info)Rcpp::stop("DORMQR failed.");return c;
}
Rcpp::List thin_qr(ConstMatrix x) {
 PackedQR f=factor(x);const int k=std::min(x.rows(),x.cols());
 Eigen::MatrixXd r=f.qr.topRows(k).triangularView<Eigen::Upper>();
 return Rcpp::List::create(Rcpp::Named("Q")=form_q(f,k),Rcpp::Named("R")=r);
}
}
