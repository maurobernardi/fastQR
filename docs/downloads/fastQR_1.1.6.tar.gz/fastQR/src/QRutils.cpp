// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: //
// ::::::::::::::::::::                                         :::::::::::::::::::: //
// ::::::::::::::::::::    QR, thin QR and L utils function     :::::::::::::::::::: //
// ::::::::::::::::::::                                         :::::::::::::::::::: //
// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: //

// Utility routines

// Authors:
//           Bernardi Mauro, University of Padova
//           Last update: october 7, 2024

// [[Rcpp::depends(RcppArmadillo)]]
#include "QRutils.h"
#include "numeric_backend.h"

// ::::::::::::::::::::::::::::::::::::::::::::::
// Cholesky factorization via QR factorization
// ::::::::::::::::::::::::::::::::::::::::::::::
Eigen::MatrixXd QRchol (const Eigen::MatrixXd& X) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  Rcpp::List output;

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                                  */
  const int n = X.rows();
  const int p = X.cols();

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vectors and matrices declaration                    */
  Eigen::MatrixXd R(p, p);          R.setZero();        // full R matrix
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (p > n) {
    Rcpp::stop("* qrchol : the number of columns of X is larger than the number of rows!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   QR factorization                                   */
  output = householderQR(X, false);
  R      = output["R"];
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return R;
}

Eigen::MatrixXd rbQRchol (const Eigen::MatrixXd& X,
                          const int& nb) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  Rcpp::List output;

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                                  */
  const int n = X.rows();
  const int p = X.cols();

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vectors and matrices declaration                    */
  Eigen::MatrixXd R(p, p);          R.setZero();        // full R matrix
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (p > n) {
    Rcpp::stop("* rbqrchol : the number of columns of X is larger than the number of rows!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   QR factorization                                   */
  //output = householderQR(X, false);
  output = rbQR(X, nb, false);
  R      = output["R"];
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return R;
}

// ::::::::::::::::::::::::::::::::::::::::::::::
// Solution of the system of equations Ax=b wrt x
// ::::::::::::::::::::::::::::::::::::::::::::::

Eigen::VectorXd QRsolve (const Eigen::MatrixXd& A,
                         const Eigen::VectorXd& b) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  Rcpp::List output;

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                                  */
  const int n = A.rows();
  const int p = A.cols();
  const int q = b.size();

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vectors and matrices declaration                    */
  Eigen::MatrixXd Q(n, p);          Q.setZero();          // full Q matrix
  Eigen::MatrixXd R(p, p);          R.setZero();          // full R matrix
  Eigen::VectorXd x(p);             x.setZero();          // full x vector
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (n < p) {
    //Rcpp::stop("* qrsolve : A must be a square matrix!\n");
    Rcpp::stop("* qrsolve : the number of rows of A should be larger or equal to the number of columns of A!\n");
  }
  if (n != q) {
    Rcpp::stop("* qrsolve : the number of rows of A is not equal to the number of elements of b!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   QR factorization                                   */
  output = householderQR(A, false);
  Q      = output["Q"];
  R      = output["R"];
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   QR factorization                                   */
  x = R.triangularView<Upper>().solve(Q.transpose() * b);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return x;
}

Eigen::VectorXd rbQRsolve (const Eigen::MatrixXd& A,
                           const Eigen::VectorXd& b,
                           const int& nb) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  Rcpp::List output;

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                                  */
  const int n = A.rows();
  const int p = A.cols();
  const int q = b.size();

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vectors and matrices declaration                    */
  Eigen::MatrixXd Q(n, p);          Q.setZero();          // full Q matrix
  Eigen::MatrixXd R(p, p);          R.setZero();          // full R matrix
  Eigen::VectorXd x(p);             x.setZero();          // full x vector
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (n < p) {
    //Rcpp::stop("* qrsolve : A must be a square matrix!\n");
    Rcpp::stop("* qrsolve : the number of rows of A should be larger or equal to the number of columns of A!\n");
  }
  if (n != q) {
    Rcpp::stop("* qrsolve : the number of rows of A is not equal to the number of elements of b!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   QR factorization                                   */
  output = rbQR(A, nb, false);
  Q      = output["Q"];
  R      = output["R"];
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   QR factorization                                   */
  x = R.triangularView<Upper>().solve(Q.transpose() * b);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return x;
}

Eigen::VectorXd Rsolve (const Eigen::MatrixXd& A,
                        const Eigen::VectorXd& b) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                                  */
  const int n = A.rows();
  const int p = A.cols();
  const int q = b.size();

  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vectors and matrices declaration                    */
  Eigen::MatrixXd R(p, p);          R.setZero();          // full R matrix
  Eigen::VectorXd x(p);             x.setZero();          // full x vector
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (n < p) {
    Rcpp::stop("* rsolve : the number of rows of A should be larger or equal to the number of columns of A!\n");
  }
  if (n != q) {
    Rcpp::stop("* rsolve : the number of rows of A is not equal to the number of elements of b!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   QR factorization                                   */
  R = householderR(A);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   QR factorization                                   */
  x = R.triangularView<Upper>().solve(A.transpose() * b);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return x;
}

// ::::::::::::::::::::::::::::::::::::::::::::::
// Least squares:
// solution of the OLS normal equations
// ::::::::::::::::::::::::::::::::::::::::::::::
Rcpp::List qrls_pred1 (const Eigen::VectorXd& y,
                       const Eigen::MatrixXd& X) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  unsigned int n = 0, p = 0, q = 0;
  double res2 = 0.0, y_norm2 = 0.0, y_mean = 0.0;
  Rcpp::List output, res;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                  */
  n = X.rows();
  p = X.cols();
  q = y.size();
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (n < p) {
    Rcpp::stop("* qrls_pred : the number of rows of X is less than the number of columns of X!\n");
  }
  if (n != q) {
    Rcpp::stop("* qrls_pred : the number of rows of X is not equal to the number of elements of y!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vector and matrices declaration                       */
  Eigen::MatrixXd XTX(p, p);                    XTX.setZero();
  Eigen::VectorXd XTy(p);                       XTy.setZero();
  Eigen::VectorXd regp(p);                      regp.setZero();
  Eigen::VectorXd resid(p);                     resid.setZero();
  Eigen::VectorXd fitted(n);                    fitted.setZero();
  Eigen::VectorXd b(p);                         b.setZero();
  Eigen::MatrixXd Q(p, p);                      Q.setZero();          // full Q matrix
  Eigen::MatrixXd R(p, p);                      R.setZero();          // full R matrix
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Get relevant quantities                              */
  XTX = fastqr_backend::product(X, X, true) / (double)n;
  XTy = fastqr_backend::matvec(X, y, true) / (double)n;
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Perform QR update of XTX                  */
  res = householderQR(XTX, false);
  Q   = res["Q"];
  R   = res["R"];
  b   = Q.transpose() * XTy;
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Compute the vector of regression parameters     */
  regp = R.triangularView<Upper>().solve(b);  // enable fast mode

  /* :::::::::::::::::::::::::::::::::::::::::
   Get output                        */
  fitted  = X * regp;
  resid   = y - fitted;
  res2    = resid.norm();
  y_mean  = y.mean();
  y_norm2 = y.transpose() * y - n * std::pow(y_mean, 2);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get output                                           */
  output = Rcpp::List::create(Rcpp::Named("coeff")           = regp,
                              Rcpp::Named("fitted")          = fitted,
                              Rcpp::Named("residuals")       = resid,
                              Rcpp::Named("residuals_norm2") = res2,
                              Rcpp::Named("y_norm2")         = y_norm2,
                              Rcpp::Named("XTX")             = (double)n * XTX,
                              Rcpp::Named("XTy")             = (double)n * XTy,
                              Rcpp::Named("sigma2_hat")      = res2 / (n - p),
                              Rcpp::Named("df")              = n-p,
                              Rcpp::Named("Q")               = (double)n * Q,
                              Rcpp::Named("R")               = (double)n * R,
                              Rcpp::Named("QXTy")            = b,
                              Rcpp::Named("R2")              = 1.0 - (res2 / y_norm2));
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return output;
}

Rcpp::List qrls_pred2 (const Eigen::VectorXd& y,
                       const Eigen::MatrixXd& X,
                       const Eigen::MatrixXd& X_test) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  unsigned int n = 0, p = 0, q = 0, n0 = 0, p0 = 0;
  double res2 = 0.0, y_norm2 = 0.0, y_mean = 0.0;
  Rcpp::List output, res;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                  */
  n  = X.rows();
  p  = X.cols();
  q  = y.size();
  n0 = X_test.rows();
  p0 = X_test.cols();
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (n < p) {
    Rcpp::stop("* qrls_pred : the number of rows of X is less than the number of columns of X!\n");
  }
  if (n != q) {
    Rcpp::stop("* qrls_pred : the number of rows of X is not equal to the number of elements of y!\n");
  }
  if (p0 != p) {
    Rcpp::stop("* qrls_pred : dimension of X and X_test not conformable!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vector and matrices declaration                       */
  Eigen::MatrixXd XTX(p, p);                    XTX.setZero();
  Eigen::VectorXd XTy(p);                       XTy.setZero();
  Eigen::VectorXd regp(p);                      regp.setZero();
  Eigen::VectorXd resid(p);                     resid.setZero();
  Eigen::VectorXd fitted(n);                    fitted.setZero();
  Eigen::VectorXd b(p);                         b.setZero();
  Eigen::MatrixXd Q(p, p);                      Q.setZero();          // full Q matrix
  Eigen::MatrixXd R(p, p);                      R.setZero();          // full R matrix
  Eigen::VectorXd predicted(n0);                predicted.setZero();
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Get relevant quantities                              */
  XTX = fastqr_backend::product(X, X, true) / (double)n;
  XTy = fastqr_backend::matvec(X, y, true) / (double)n;
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Perform QR update of XTX                  */
  res = householderQR(XTX, false);
  Q   = res["Q"];
  R   = res["R"];
  b   = Q.transpose() * XTy;
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Compute the vector of regression parameters     */
  regp = R.triangularView<Upper>().solve(b);  // enable fast mode

  /* :::::::::::::::::::::::::::::::::::::::::
   Get output                        */
  fitted    = X * regp;
  resid     = y - fitted;
  res2      = resid.norm();
  y_mean    = y.mean();
  y_norm2   = y.transpose() * y - n * std::pow(y_mean, 2);
  predicted = X_test * regp;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get output                                           */
  output = Rcpp::List::create(Rcpp::Named("coeff")           = regp,
                              Rcpp::Named("fitted")          = fitted,
                              Rcpp::Named("residuals")       = resid,
                              Rcpp::Named("residuals_norm2") = res2,
                              Rcpp::Named("y_norm2")         = y_norm2,
                              Rcpp::Named("XTX")             = (double)n * XTX,
                              Rcpp::Named("XTy")             = (double)n * XTy,
                              Rcpp::Named("sigma2_hat")      = res2 / (n - p),
                              Rcpp::Named("df")              = n-p,
                              Rcpp::Named("Q")               = (double)n * Q,
                              Rcpp::Named("R")               = (double)n * R,
                              Rcpp::Named("QXTy")            = b,
                              Rcpp::Named("R2")              = 1.0 - (res2 / y_norm2),
                              Rcpp::Named("predicted")       = predicted);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return output;
}

Rcpp::List rls_pred1 (const Eigen::VectorXd& y,
                      const Eigen::MatrixXd& X) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  unsigned int n = 0, p = 0, q = 0;
  double res2 = 0.0, y_norm2 = 0.0, y_mean = 0.0;
  Rcpp::List output;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                  */
  n  = X.rows();
  p  = X.cols();
  q  = y.size();
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (n < p) {
    Rcpp::stop("* rls_pred : the number of rows of X is less than the number of columns of X!\n");
  }
  if (n != q) {
    Rcpp::stop("* rls_pred : the number of rows of X is not equal to the number of elements of y!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vector and matrices declaration                       */
  Eigen::VectorXd regp(p);                      regp.setZero();
  Eigen::VectorXd resid(p);                     resid.setZero();
  Eigen::VectorXd fitted(n);                    fitted.setZero();
  Eigen::VectorXd b(p);                         b.setZero();
  Eigen::MatrixXd R(p, p);                      R.setZero();          // full R matrix
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Perform QR update of XTX                  */
  R = householderR(X);
  b = fastqr_backend::matvec(X, y, true);
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Compute the vector of regression parameters     */
  regp = R.triangularView<Upper>().solve(b);  // enable fast mode

  /* :::::::::::::::::::::::::::::::::::::::::
   Get output                        */
  fitted    = X * regp;
  resid     = y - fitted;
  res2      = resid.norm();
  y_mean    = y.mean();
  y_norm2   = y.transpose() * y - n * std::pow(y_mean, 2);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get output                                           */
  output = Rcpp::List::create(Rcpp::Named("coeff")           = regp,
                              Rcpp::Named("fitted")          = fitted,
                              Rcpp::Named("residuals")       = resid,
                              Rcpp::Named("residuals_norm2") = res2,
                              Rcpp::Named("y_norm2")         = y_norm2,
                              Rcpp::Named("XTX")             = fastqr_backend::product(R, R, true),
                              Rcpp::Named("sigma2_hat")      = res2 / (n - p),
                              Rcpp::Named("df")              = n-p,
                              Rcpp::Named("R")               = R,
                              Rcpp::Named("QTy")             = b,
                              Rcpp::Named("R2")              = 1.0 - (res2 / y_norm2));
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return output;
}

Rcpp::List rls_pred2 (const Eigen::VectorXd& y,
                      const Eigen::MatrixXd& X,
                      const Eigen::MatrixXd& X_test) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  unsigned int n = 0, p = 0, q = 0, n0 = 0, p0 = 0;
  double res2 = 0.0, y_norm2 = 0.0, y_mean = 0.0;
  Rcpp::List output, res;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                  */
  n  = X.rows();
  p  = X.cols();
  q  = y.size();
  n0 = X_test.rows();
  p0 = X_test.cols();
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (n < p) {
    Rcpp::stop("* rls_pred : the number of rows of X is less than the number of columns of X!\n");
  }
  if (n != q) {
    Rcpp::stop("* rls_pred : the number of rows of X is not equal to the number of elements of y!\n");
  }
  if (p0 != p) {
    Rcpp::stop("* rls_pred : dimension of X and X_test not conformable!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vector and matrices declaration                       */
  Eigen::VectorXd regp(p);                      regp.setZero();
  Eigen::VectorXd resid(p);                     resid.setZero();
  Eigen::VectorXd fitted(n);                    fitted.setZero();
  Eigen::VectorXd b(p);                         b.setZero();
  Eigen::MatrixXd R(p, p);                      R.setZero();          // full R matrix
  Eigen::VectorXd predicted(n0);                predicted.setZero();
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Perform QR update of XTX                  */
  R = householderR(X);
  b = fastqr_backend::matvec(X, y, true);
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Compute the vector of regression parameters     */
  regp = R.triangularView<Upper>().solve(b);  // enable fast mode

  /* :::::::::::::::::::::::::::::::::::::::::
   Get output                        */
  fitted    = X * regp;
  resid     = y - fitted;
  res2      = resid.norm();
  y_mean    = y.mean();
  y_norm2   = y.transpose() * y - n * std::pow(y_mean, 2);
  predicted = X_test * regp;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get output                                           */
  output = Rcpp::List::create(Rcpp::Named("coeff")           = regp,
                              Rcpp::Named("fitted")          = fitted,
                              Rcpp::Named("residuals")       = resid,
                              Rcpp::Named("residuals_norm2") = res2,
                              Rcpp::Named("y_norm2")         = y_norm2,
                              Rcpp::Named("XTX")             = fastqr_backend::product(R, R, true),
                              Rcpp::Named("sigma2_hat")      = res2 / (n - p),
                              Rcpp::Named("df")              = n-p,
                              Rcpp::Named("R")               = R,
                              Rcpp::Named("QTy")             = b,
                              Rcpp::Named("R2")              = 1.0 - (res2 / y_norm2),
                              Rcpp::Named("predicted")       = predicted);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return output;
}

// ::::::::::::::::::::::::::::::::::::::::::::::
// RIDGE:
// solution of the RIDGE normal equations
// ::::::::::::::::::::::::::::::::::::::::::::::
// Shared normalized ridge fit: ||Y-XB||_F^2/n + lambda*||B||_F^2.
// fixed_R is supplied by CV after removing held-out observation rows.
static Rcpp::List ridge_fit_impl(const Eigen::MatrixXd& Y,
                                const Eigen::MatrixXd& X,
                                const double lambda,
                                const bool qr_backend,
                                const bool scalar,
                                const Eigen::MatrixXd* X_test = nullptr,
                                const Eigen::MatrixXd* fixed_R = nullptr) {
  const int n = X.rows(), p = X.cols(), q = Y.cols();
  if (n < 1 || p < 1 || q < 1 || Y.rows() != n)
    Rcpp::stop("* ridge: require n >= 1, p >= 1 and matching nonempty response rows.");
  if (!X.allFinite() || !Y.allFinite())
    Rcpp::stop("* ridge: X and the response must contain only finite values.");
  if (!std::isfinite(lambda) || lambda < 0 || !std::isfinite(n*lambda))
    Rcpp::stop("* ridge: lambda must be finite, nonnegative and safely scaled by n.");
  if (X_test && (X_test->cols() != p || !X_test->allFinite()))
    Rcpp::stop("* ridge: X_test must have p columns and finite values.");
  if (lambda == 0 && Eigen::ColPivHouseholderQR<Eigen::MatrixXd>(X).rank() < p)
    Rcpp::stop("* ridge: lambda=0 requires full column rank.");

  Eigen::MatrixXd cross = fastqr_backend::product(X, Y, true);
  Eigen::MatrixXd XTX, Q, R, transformed, coeff;
  if (qr_backend) {
    XTX = fastqr_backend::product(X, X, true);
    Eigen::MatrixXd system = XTX / static_cast<double>(n);
    system.diagonal().array() += lambda;
    Rcpp::List factor = householderQR(system, false);
    Q = Rcpp::as<Eigen::MatrixXd>(factor["Q"]);
    R = Rcpp::as<Eigen::MatrixXd>(factor["R"]);
    transformed = Q.transpose() * (cross / static_cast<double>(n));
  } else {
    if (fixed_R) {
      if (fixed_R->rows() != p || fixed_R->cols() != p || !fixed_R->allFinite())
        Rcpp::stop("* ridge: invalid supplied triangular factor.");
      R = *fixed_R;
      XTX = fastqr_backend::product(R, R, true);
      XTX.diagonal().array() -= n*lambda;
    } else {
      Eigen::MatrixXd augmented = Eigen::MatrixXd::Zero(n+p,p);
      augmented.topRows(n) = X;
      augmented.bottomRows(p).diagonal().array() = std::sqrt(n*lambda);
      R = householderR(augmented);
      XTX = fastqr_backend::product(X, X, true);
    }
    transformed = R.transpose().triangularView<Eigen::Lower>().solve(cross);
  }
  if (!R.allFinite() || (R.diagonal().array() == 0).any())
    Rcpp::stop("* ridge: singular or non-finite penalized system.");
  coeff = R.triangularView<Eigen::Upper>().solve(transformed);
  if (!coeff.allFinite()) Rcpp::stop("* ridge: non-finite coefficients.");
  const Eigen::MatrixXd fitted = fastqr_backend::product(X, coeff);
  const Eigen::MatrixXd residuals = Y-fitted;
  const double sse = residuals.squaredNorm();
  const Eigen::MatrixXd centered = Y.rowwise()-Y.colwise().mean();
  const double total = centered.squaredNorm();
  const double r2 = total > 0 ? 1-sse/total : NA_REAL;
  Rcpp::List out;
  if (scalar) {
    out = Rcpp::List::create(
      Rcpp::Named("coeff") = coeff.col(0).eval(),
      Rcpp::Named("fitted") = fitted.col(0).eval(),
      Rcpp::Named("residuals") = residuals.col(0).eval(),
      Rcpp::Named("residuals_norm2") = sse,
      Rcpp::Named("y_norm2") = total,
      Rcpp::Named("XTX") = XTX,
      Rcpp::Named("XTy") = cross.col(0).eval(),
      Rcpp::Named("sigma2_hat") = n > p ? sse/(n-p) : NA_REAL,
      Rcpp::Named("df") = n >= p ? static_cast<double>(n-p) : NA_REAL,
      Rcpp::Named("R") = R,
      Rcpp::Named("R2") = r2);
    if (qr_backend) {
      out["Q"] = Q;
      out["QXTy"] = transformed.col(0).eval();
    } else out["QTy"] = transformed.col(0).eval();
    if (X_test) out["predicted"] = ((*X_test)*coeff).col(0).eval();
  } else {
    Eigen::MatrixXd covariance = residuals.transpose()*residuals;
    if (n > p) covariance /= n-p;
    else covariance.setConstant(NA_REAL);
    out = Rcpp::List::create(
      Rcpp::Named("coeff") = coeff,
      Rcpp::Named("fitted") = fitted,
      Rcpp::Named("residuals") = residuals,
      Rcpp::Named("XTX") = XTX,
      Rcpp::Named("XTY") = cross,
      Rcpp::Named("XTy") = cross, // Backward-compatible spelling, without duplicate names.
      Rcpp::Named("Sigma_hat") = covariance,
      Rcpp::Named("df") = n >= p ? static_cast<double>(q*(n-p)) : NA_REAL,
      Rcpp::Named("R") = R,
      Rcpp::Named("R2") = r2);
    if (qr_backend) {
      out["Q"] = Q;
      out["QXTY"] = transformed;
      out["QXTy"] = transformed;
    } else out["QTY"] = transformed;
    if (X_test) out["predicted"] = ((*X_test)*coeff).eval();
  }
  return out;
}

Rcpp::List qrridge_pred1 (const Eigen::VectorXd& y,
                          const Eigen::MatrixXd& X,
                          const double lambda) {
  return ridge_fit_impl(Eigen::MatrixXd(y), X, lambda, true, true);
}

Rcpp::List qrridge_pred2 (const Eigen::VectorXd& y,
                          const Eigen::MatrixXd& X,
                          const Eigen::MatrixXd& X_test,
                          const double lambda) {
  return ridge_fit_impl(Eigen::MatrixXd(y), X, lambda, true, true, &X_test);
}

Eigen::MatrixXd rridge_R (const Eigen::MatrixXd& X,
                          const double lambda) {
  if (X.rows() < 1 || X.cols() < 1 || !X.allFinite() ||
      !std::isfinite(lambda) || lambda < 0 || !std::isfinite(X.rows()*lambda))
    Rcpp::stop("* rridge_R: invalid design or lambda.");
  Eigen::MatrixXd augmented = Eigen::MatrixXd::Zero(X.rows()+X.cols(),X.cols());
  augmented.topRows(X.rows()) = X;
  augmented.bottomRows(X.cols()).diagonal().array() = std::sqrt(X.rows()*lambda);
  return householderR(augmented);
}

Rcpp::List rridge_pred1 (const Eigen::VectorXd& y,
                         const Eigen::MatrixXd& X,
                         const double lambda) {
  return ridge_fit_impl(Eigen::MatrixXd(y), X, lambda, false, true);
}

Rcpp::List rridge_pred2 (const Eigen::VectorXd& y,
                         const Eigen::MatrixXd& X,
                         const Eigen::MatrixXd& X_test,
                         const double lambda) {
  return ridge_fit_impl(Eigen::MatrixXd(y), X, lambda, false, true, &X_test);
}

Rcpp::List rridge_downdate (const Eigen::VectorXd& y,
                            const Eigen::MatrixXd& X,
                            const Eigen::VectorXd& y_test,
                            const Eigen::MatrixXd& X_test,
                            const double lambda,
                            const Eigen::MatrixXd& R,
                            const Eigen::MatrixXd& U) {
  const int p = X.cols();
  if (R.rows() != p || R.cols() != p || U.rows() != p || U.cols() != X_test.rows() ||
      !R.allFinite() || !U.allFinite()) Rcpp::stop("* ridge CV: incompatible factors or held-out rows.");
  Eigen::MatrixXd updated = thinqrdeletemrows(R,U.transpose());
  const Eigen::MatrixXd target = fastqr_backend::product(R, R, true) - fastqr_backend::product(U, U, false, true);
  const double tolerance = 1e-10 * std::max(1.0,target.norm());
  if (!updated.allFinite() || (updated.transpose()*updated-target).norm() > tolerance) {
    Eigen::MatrixXd augmented = Eigen::MatrixXd::Zero(X.rows()+p,p);
    augmented.topRows(X.rows()) = X;
    augmented.bottomRows(p).diagonal().array() = std::sqrt(X.rows()*lambda);
    updated = householderR(augmented);
  }
  Rcpp::List out = ridge_fit_impl(Eigen::MatrixXd(y), X, lambda, false, true, &X_test, &updated);
  Eigen::VectorXd prediction = Rcpp::as<Eigen::VectorXd>(out["predicted"]);
  if (y_test.size() != prediction.size() || !y_test.allFinite()) Rcpp::stop("* ridge CV: invalid held-out response.");
  out["PMSE"] = (prediction-y_test).squaredNorm()/prediction.size();
  return out;
}

// ::::::::::::::::::::::::::::::::::::::::::::::
// Multivariate least squares:
// solution of the OLS normal equations
// ::::::::::::::::::::::::::::::::::::::::::::::

double multivariateR2 (const Eigen::MatrixXd& Y,
                       const Eigen::MatrixXd& X,
                       const Eigen::MatrixXd& B) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  double trace_T = 0.0, trace_E = 0.0, R2 = 0.0;
  int n = 0, q = 0;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                  */
  n = X.rows();
  q = Y.cols();
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vector and matrices declaration                       */
  Eigen::MatrixXd Y_centered(n, q);             Y_centered.setZero();
  Eigen::MatrixXd Y_HAT(n, q);                  Y_HAT.setZero();
  Eigen::RowVectorXd Y_mean(q);                 Y_mean.setZero();
  Eigen::MatrixXd E(n, q);                      E.setZero();
  Eigen::MatrixXd T_sscp(q, q);                 T_sscp.setZero();
  Eigen::MatrixXd E_sscp(q, q);                 E_sscp.setZero();
  
  // Compute column means of Y
  Y_mean = Y.colwise().mean();
  
  // Center Y around its mean
  Y_centered = Y.rowwise() - Y_mean;
  
  // Total sum of squares and cross-products (SSCP) matrix (T)
  T_sscp = Y_centered.transpose() * Y_centered;
  
  // Compute fitted values: Y_hat = X * B
  Y_HAT = X * B;
  
  // Compute residuals: E = Y - Y_hat
  E = Y - Y_HAT;
  
  // residuals sum of squares and cross-products SSCP matrix (E)
  E_sscp = E.transpose() * E;
  
  // Compute R^2 = 1 - trace(E) / trace(T)
  trace_T = T_sscp.trace();
  trace_E = E_sscp.trace();
  R2      = 1.0 - (trace_E / trace_T);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return R2;
}

double multivariatePMSE (const Eigen::MatrixXd& Y,
                         const Eigen::MatrixXd& X,
                         const Eigen::MatrixXd& B) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  double pmse = 0.0;
  int n = 0, q = 0;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                  */
  n = X.rows();
  q = Y.cols();
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vector and matrices declaration                       */
  Eigen::MatrixXd Y_pred(n, q);                 Y_pred.setZero();
  Eigen::MatrixXd residuals(n, q);              residuals.setZero();
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   compute predictive MSE                     */
  
  // Step 1: Predict responses for the test set
  Y_pred = X * B;

  // Step 2: Compute residuals
  residuals = Y - Y_pred;

  // Step 4: Compute MSE
  pmse = (residuals.array().square().sum()) / (n * q);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return pmse;
}

Rcpp::List qrmls_pred1 (const Eigen::MatrixXd& Y,
                        const Eigen::MatrixXd& X) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  unsigned int n = 0, p = 0, q = 0, N = 0;
  double R2 = 0.0;
  Rcpp::List output, res;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                  */
  n = X.rows();
  p = X.cols();
  N = Y.rows();
  q = Y.cols();
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (n < p) {
    Rcpp::stop("* qrmls_pred : the number of rows of X is less than the number of columns of X!\n");
  }
  if (N != n) {
    Rcpp::stop("* qrmls_pred : the number of rows of X is not equal to those of Y!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vector and matrices declaration                       */
  Eigen::MatrixXd XTX(p, p);                    XTX.setZero();
  Eigen::MatrixXd XTY(p, q);                    XTY.setZero();
  Eigen::MatrixXd regp(p, q);                   regp.setZero();
  Eigen::MatrixXd B(p, q);                      B.setZero();
  Eigen::MatrixXd Q(p, p);                      Q.setZero();          // full Q matrix
  Eigen::MatrixXd R(p, p);                      R.setZero();          // full R matrix
  Eigen::MatrixXd resid(p, q);                  resid.setZero();
  Eigen::MatrixXd fitted(n, q);                 fitted.setZero();
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Get relevant quantities                              */
  XTX = fastqr_backend::product(X, X, true) / (double)n;
  XTY = fastqr_backend::product(X, Y, true) / (double)n;
    
  /* :::::::::::::::::::::::::::::::::::::::::
   Perform QR update of XTX                  */
  res = householderQR(XTX, false);
  Q   = res["Q"];
  R   = res["R"];
  B   = Q.transpose() * XTY;
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Compute the vector of regression parameters     */
  regp = R.triangularView<Upper>().solve(B);  // enable fast mode

  /* :::::::::::::::::::::::::::::::::::::::::
   Get output                        */
  fitted = X * regp;
  resid  = Y - fitted;
  R2     = multivariateR2(Y, X, regp);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get output                                           */
  output = Rcpp::List::create(Rcpp::Named("coeff")     = regp,
                              Rcpp::Named("fitted")    = fitted,
                              Rcpp::Named("residuals") = resid,
                              Rcpp::Named("XTX")       = (double)n * XTX,
                              Rcpp::Named("XTy")       = (double)n * XTY,
                              Rcpp::Named("Sigma_hat") = resid.transpose() * resid / (n - p),
                              Rcpp::Named("df")        = q * (n-p),
                              Rcpp::Named("Q")         = (double)n * Q,
                              Rcpp::Named("R")         = (double)n * R,
                              Rcpp::Named("QXTy")      = B,
                              Rcpp::Named("R2")        = R2);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return output;
}

Rcpp::List qrmls_pred2 (const Eigen::MatrixXd& Y,
                        const Eigen::MatrixXd& X,
                        const Eigen::MatrixXd& X_test) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  unsigned int n = 0, p = 0, q = 0, N = 0, p0 = 0, n0 = 0;
  double R2 = 0.0;
  Rcpp::List output, res;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                  */
  n  = X.rows();
  p  = X.cols();
  N  = Y.rows();
  q  = Y.cols();
  n0 = X_test.rows();
  p0 = X_test.cols();
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (n < p) {
    Rcpp::stop("* qrmls_pred : the number of rows of X is less than the number of columns of X!\n");
  }
  if (N != n) {
    Rcpp::stop("* qrmls_pred : the number of rows of X is not equal to those of Y!\n");
  }
  if (p0 != p) {
    Rcpp::stop("* qrls_pred : dimension of X and X_test not conformable!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vector and matrices declaration                       */
  Eigen::MatrixXd XTX(p, p);                    XTX.setZero();
  Eigen::MatrixXd XTY(p, q);                    XTY.setZero();
  Eigen::MatrixXd regp(p, q);                   regp.setZero();
  Eigen::MatrixXd B(p, q);                      B.setZero();
  Eigen::MatrixXd Q(p, p);                      Q.setZero();          // full Q matrix
  Eigen::MatrixXd R(p, p);                      R.setZero();          // full R matrix
  Eigen::MatrixXd resid(p, q);                  resid.setZero();
  Eigen::MatrixXd fitted(n, q);                 fitted.setZero();
  Eigen::MatrixXd predicted(n0, q);             predicted.setZero();
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Get relevant quantities                              */
  XTX = fastqr_backend::product(X, X, true) / (double)n;
  XTY = fastqr_backend::product(X, Y, true) / (double)n;
    
  /* :::::::::::::::::::::::::::::::::::::::::
   Perform QR update of XTX                  */
  res = householderQR(XTX, false);
  Q   = res["Q"];
  R   = res["R"];
  B   = Q.transpose() * XTY;
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Compute the vector of regression parameters     */
  regp = R.triangularView<Upper>().solve(B);  // enable fast mode
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Get output                        */
  fitted    = X * regp;
  resid     = Y - fitted;
  R2        = multivariateR2(Y, X, regp);
  predicted = X_test * regp;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get output                                           */
  output = Rcpp::List::create(Rcpp::Named("coeff")     = regp,
                              Rcpp::Named("fitted")    = fitted,
                              Rcpp::Named("residuals") = resid,
                              Rcpp::Named("XTX")       = (double)n * XTX,
                              Rcpp::Named("XTy")       = (double)n * XTY,
                              Rcpp::Named("Sigma_hat") = resid.transpose() * resid / (n - p),
                              Rcpp::Named("df")        = q * (n-p),
                              Rcpp::Named("Q")         = (double)n * Q,
                              Rcpp::Named("R")         = (double)n * R,
                              Rcpp::Named("QXTy")      = B,
                              Rcpp::Named("R2")        = R2,
                              Rcpp::Named("predicted") = predicted);
    
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return output;
}

Rcpp::List rmls_pred1 (const Eigen::MatrixXd& Y,
                       const Eigen::MatrixXd& X) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  unsigned int n = 0, p = 0, q = 0, N = 0;
  double R2 = 0.0;
  Rcpp::List output, res;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                  */
  n = X.rows();
  p = X.cols();
  N = Y.rows();
  q = Y.cols();
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (n < p) {
    Rcpp::stop("* rmls_pred : the number of rows of X is less than the number of columns of X!\n");
  }
  if (N != n) {
    Rcpp::stop("* rmls_pred : the number of rows of X is not equal to those of Y!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vector and matrices declaration                       */
  Eigen::MatrixXd XTX(p, p);                    XTX.setZero();
  Eigen::MatrixXd XTY(p, q);                    XTY.setZero();
  Eigen::MatrixXd regp(p, q);                   regp.setZero();
  Eigen::MatrixXd B(p, q);                      B.setZero();
  Eigen::MatrixXd R(p, p);                      R.setZero();          // full R matrix
  Eigen::MatrixXd resid(p, q);                  resid.setZero();
  Eigen::MatrixXd fitted(n, q);                 fitted.setZero();
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Get relevant quantities                              */
  XTX = fastqr_backend::product(X, X, true) / (double)n;
  XTY = fastqr_backend::product(X, Y, true) / (double)n;
    
  /* :::::::::::::::::::::::::::::::::::::::::
   Perform QR update of XTX                  */
  R = householderR(X);
  B = XTY;
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Compute the vector of regression parameters     */
  regp = R.triangularView<Upper>().solve(B);  // enable fast mode

  /* :::::::::::::::::::::::::::::::::::::::::
   Get output                        */
  fitted = X * regp;
  resid  = Y - fitted;
  R2     = multivariateR2(Y, X, regp);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get output                                           */
  output = Rcpp::List::create(Rcpp::Named("coeff")     = regp,
                              Rcpp::Named("fitted")    = fitted,
                              Rcpp::Named("residuals") = resid,
                              Rcpp::Named("XTX")       = fastqr_backend::product(R, R, true),
                              Rcpp::Named("Sigma_hat") = resid.transpose() * resid / (n - p),
                              Rcpp::Named("df")        = q * (n-p),
                              Rcpp::Named("R")         = R,
                              Rcpp::Named("XTy")       = B,
                              Rcpp::Named("R2")        = R2);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return output;
}

Rcpp::List rmls_pred2 (const Eigen::MatrixXd& Y,
                       const Eigen::MatrixXd& X,
                       const Eigen::MatrixXd& X_test) {
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   variable declaration                                  */
  unsigned int n = 0, p = 0, q = 0, N = 0, n0 = 0, p0 = 0;
  double R2 = 0.0, pmse = 0.0;
  Rcpp::List output, res;
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get dimensions                  */
  n = X.rows();
  p = X.cols();
  N = Y.rows();
  q = Y.cols();
  n0 = X_test.rows();
  p0 = X_test.cols();
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   checks                              */
  if (n < p) {
    Rcpp::stop("* rmls_pred : the number of rows of X is less than the number of columns of X!\n");
  }
  if (N != n) {
    Rcpp::stop("* rmls_pred : the number of rows of X is not equal to those of Y!\n");
  }
  if (p0 != p) {
    Rcpp::stop("* qrls_pred : dimension of X and X_test not conformable!\n");
  }
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   vector and matrices declaration                       */
  Eigen::MatrixXd XTX(p, p);                    XTX.setZero();
  Eigen::MatrixXd XTY(p, q);                    XTY.setZero();
  Eigen::MatrixXd regp(p, q);                   regp.setZero();
  Eigen::MatrixXd B(p, q);                      B.setZero();
  Eigen::MatrixXd R(p, p);                      R.setZero();          // full R matrix
  Eigen::MatrixXd resid(p, q);                  resid.setZero();
  Eigen::MatrixXd fitted(n, q);                 fitted.setZero();
  Eigen::MatrixXd predicted(n0, q);             predicted.setZero();
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Get relevant quantities                              */
  XTX = fastqr_backend::product(X, X, true) / (double)n;
  XTY = fastqr_backend::product(X, Y, true) / (double)n;
    
  /* :::::::::::::::::::::::::::::::::::::::::
   Perform QR update of XTX                  */
  R = householderR(X);
  B = XTY;
  
  /* :::::::::::::::::::::::::::::::::::::::::
   Compute the vector of regression parameters     */
  regp = R.triangularView<Upper>().solve(B);  // enable fast mode

  /* :::::::::::::::::::::::::::::::::::::::::
   Get output                        */
  fitted    = X * regp;
  resid     = Y - fitted;
  R2        = multivariateR2(Y, X, regp);
  predicted = X_test * regp;
  pmse      = multivariatePMSE(Y, X, regp);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   get output                                           */
  output = Rcpp::List::create(Rcpp::Named("coeff")     = regp,
                              Rcpp::Named("fitted")    = fitted,
                              Rcpp::Named("residuals") = resid,
                              Rcpp::Named("XTX")       = fastqr_backend::product(R, R, true),
                              Rcpp::Named("Sigma_hat") = resid.transpose() * resid / (n - p),
                              Rcpp::Named("df")        = q * (n-p),
                              Rcpp::Named("R")         = R,
                              Rcpp::Named("XTy")       = B,
                              Rcpp::Named("R2")        = R2,
                              Rcpp::Named("predicted") = predicted,
                              Rcpp::Named("PMSE")      = pmse);
  
  /* ::::::::::::::::::::::::::::::::::::::::::::::
   return output                                        */
  return output;
}

Rcpp::List qrmridge_pred1 (const Eigen::MatrixXd& Y,
                           const Eigen::MatrixXd& X,
                           const double lambda) {
  return ridge_fit_impl(Y, X, lambda, true, false);
}

Rcpp::List qrmridge_pred2 (const Eigen::MatrixXd& Y,
                           const Eigen::MatrixXd& X,
                           const Eigen::MatrixXd& X_test,
                           const double lambda) {
  return ridge_fit_impl(Y, X, lambda, true, false, &X_test);
}

Rcpp::List rmridge_pred1 (const Eigen::MatrixXd& Y,
                          const Eigen::MatrixXd& X,
                          const double lambda) {
  return ridge_fit_impl(Y, X, lambda, false, false);
}

Rcpp::List rmridge_pred2 (const Eigen::MatrixXd& Y,
                          const Eigen::MatrixXd& X,
                          const Eigen::MatrixXd& X_test,
                          const double lambda) {
  return ridge_fit_impl(Y, X, lambda, false, false, &X_test);
}

Rcpp::List rmridge_downdate (const Eigen::MatrixXd& Y,
                             const Eigen::MatrixXd& X,
                             const Eigen::MatrixXd& Y_test,
                             const Eigen::MatrixXd& X_test,
                             const double lambda,
                             const Eigen::MatrixXd& R,
                             const Eigen::MatrixXd& U) {
  const int p = X.cols();
  if (R.rows() != p || R.cols() != p || U.rows() != p || U.cols() != X_test.rows() ||
      !R.allFinite() || !U.allFinite()) Rcpp::stop("* ridge CV: incompatible factors or held-out rows.");
  Eigen::MatrixXd updated = thinqrdeletemrows(R,U.transpose());
  const Eigen::MatrixXd target = fastqr_backend::product(R, R, true) - fastqr_backend::product(U, U, false, true);
  const double tolerance = 1e-10 * std::max(1.0,target.norm());
  if (!updated.allFinite() || (updated.transpose()*updated-target).norm() > tolerance) {
    Eigen::MatrixXd augmented = Eigen::MatrixXd::Zero(X.rows()+p,p);
    augmented.topRows(X.rows()) = X;
    augmented.bottomRows(p).diagonal().array() = std::sqrt(X.rows()*lambda);
    updated = householderR(augmented);
  }
  Rcpp::List out = ridge_fit_impl(Y, X, lambda, false, false, &X_test, &updated);
  Eigen::MatrixXd prediction = Rcpp::as<Eigen::MatrixXd>(out["predicted"]);
  if (Y_test.rows() != prediction.rows() || Y_test.cols() != prediction.cols() || !Y_test.allFinite())
    Rcpp::stop("* ridge CV: invalid held-out response.");
  out["PMSE"] = (prediction-Y_test).squaredNorm()/prediction.size();
  return out;
}













// end of file
