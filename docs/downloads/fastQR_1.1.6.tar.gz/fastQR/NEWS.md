# Development changes following fastQR 1.1.6

* Added `qr_lapack()` for explicit unpivoted LAPACK QR factorization, with
  thin, full, R-only and compact outputs. Uses R's LAPACK/BLAS libraries.
* Removed late Eigen BLAS/LAPACKE macro definitions; existing QR functions
  retain their implementations and interfaces.
* Added LAPACK reconstruction, orthogonality, packed-reflector, input validation
  and factor-reuse tests, including wide and rank-deficient matrices.


* Route eligible dense matrix and matrix-vector products through a shared
  backend calling R's DGEMM/DGEMV. Small products retain Eigen kernels.
  R/BLAS declarations are isolated from Armadillo headers; no global
  EIGEN_USE_BLAS or EIGEN_USE_LAPACKE macro is required.
* Use explicit DGEQRF/DORGQR in thin and unpivoted packed QR, and
  DGEQRF/DORMQR in recursive QR panels. Pivoted rank criteria and the
  custom Givens/Householder update algorithms are retained.

* Ridge fits and ridge cross-validation now support p > n for strictly
  positive penalties. Zero-penalty fits still require full column rank.
  Legacy residual df and variance diagnostics are unavailable (NA) when p > n;
  they are not effective ridge degrees of freedom.
