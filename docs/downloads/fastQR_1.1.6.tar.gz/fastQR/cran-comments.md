## Update from version 1.1.5

This is a maintenance update addressing numerical correctness and input
validation. Although version 1.1.5 was released recently, an early update
is warranted because the fixes affect returned QR factors, ridge estimates,
and cross-validation results.

The changes correct complete-Q output after downdates, orthogonal
completion, recursive QR factorization, and reduced-factor extraction.
They also correct ridge penalty scaling and cross-validation calculations,
improve dimension and rank checks, and avoid unnecessary full-Q allocations
in reduced-output paths. Regression tests cover these cases.

## Local testing

## R CMD check results

The final source archive fastQR_1.1.6.tar.gz was checked with
CRAN incoming checks enabled.

0 errors | 0 warnings | 0 notes

